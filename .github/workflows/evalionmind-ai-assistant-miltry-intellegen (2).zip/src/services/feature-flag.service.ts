
import { Injectable, signal } from '@angular/core';

// Define the shape of our feature flags
export interface FeatureFlags {
  generativeToolkit: boolean;
  fullstackEnhancer: boolean;
  videoInterviews: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class FeatureFlagService {
  // Private signal to hold the state of all flags
  private featureFlags = signal<FeatureFlags>({
    generativeToolkit: true, // Enabled for demonstration
    fullstackEnhancer: false, // Disabled by default
    videoInterviews: true,
  });

  /**
   * Checks if a specific feature is enabled.
   * @param key The name of the feature flag to check.
   * @returns A boolean indicating if the feature is active.
   */
  isEnabled(key: keyof FeatureFlags): boolean {
    return this.featureFlags()[key] ?? false;
  }

  /**
   * (For admin/testing purposes) Toggles a feature flag's state.
   * @param key The name of the feature flag to toggle.
   */
  toggleFeature(key: keyof FeatureFlags): void {
    this.featureFlags.update(flags => ({
      ...flags,
      [key]: !flags[key],
    }));
    console.log(`[Feature Flag] Toggled '${key}' to ${this.isEnabled(key)}`);
  }
}
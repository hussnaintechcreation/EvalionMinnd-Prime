
import { Injectable, signal, inject, NgZone } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Type } from '@google/genai';
import { ParsedResume } from '../models/resume.model';
import { PromptService } from './prompt.service';
import { InterviewQuestion } from '../models/interview.model';
import { Observable, from, lastValueFrom, retry, timer, throwError, switchMap } from 'rxjs';
import { GlobalErrorHandlerService } from './global-error-handler.service';
import { CandidateRank } from '../models/evaluation.model';
import { Candidate } from '../models/ats.model';

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private httpClient: HttpClient = inject(HttpClient);
  private ngZone = inject(NgZone);
  private globalErrorHandler = inject(GlobalErrorHandlerService);
  
  private chatSessionId: string | null = null;
  error = signal<string | null>(null);

  constructor(private promptService: PromptService) {}

  /**
   * Universal Retry Logic for RxJS Observables
   */
  private applyRetry<T>(
    observable: Observable<T>, 
    context: string, 
    maxRetries: number = 3, 
    initialDelayMs: number = 1000
  ): Observable<T> {
    return observable.pipe(
      retry({
        count: maxRetries,
        delay: (error: any, retryCount) => {
          // Using type guard to handle HttpErrorResponse safely
          const isNetworkError = error instanceof HttpErrorResponse && 
                                (error.status === 0 || error.status >= 500 || error.status === 429);
          
          if (isNetworkError) {
            const backoffTime = Math.pow(2, retryCount - 1) * initialDelayMs;
            console.warn(`[GeminiService] Transient failure in ${context}. Retrying (${retryCount}/${maxRetries}) in ${backoffTime}ms...`);
            return timer(backoffTime);
          }
          return throwError(() => error);
        }
      })
    );
  }

  private handleApiError(error: unknown, context: string): string {
    let errorMessage: string;

    if (error instanceof HttpErrorResponse) {
        const httpError = error as HttpErrorResponse;
        
        // Prioritize specific backend error message if available
        const backendMessage = (httpError.error && typeof httpError.error === 'object' && 'message' in httpError.error) 
            ? (httpError.error as {message: string}).message 
            : (typeof httpError.error === 'string' ? httpError.error : null);

        if (backendMessage) {
            errorMessage = backendMessage;
        } else {
            // Fallback to more specific, user-friendly status-based messages
            switch (httpError.status) {
                case 0:
                    errorMessage = `Network Connection Lost. Verify uplink and try again.`;
                    break;
                case 400:
                    errorMessage = `AI core rejected the request as invalid. The input may be malformed.`;
                    break;
                case 401:
                case 403:
                    // NOTE: 401 is also handled by the auth interceptor, which will trigger a logout.
                    // This message serves as immediate feedback in the component's context.
                    errorMessage = `Authorization failure. Your session may be invalid.`;
                    break;
                case 429:
                    errorMessage = `AI Core rate limit exceeded. Please wait a moment before trying again.`;
                    break;
                case 500:
                case 502:
                case 503:
                case 504:
                    errorMessage = `The AI core is currently unavailable or experiencing a malfunction. Please try again later.`;
                    break;
                default:
                    errorMessage = `An unexpected communication error occurred with the AI Core (Status: ${httpError.status}).`;
                    break;
            }
        }
    } else if (error instanceof Error) {
        errorMessage = error.message;
    } else {
        errorMessage = `An unknown error occurred during ${context}.`;
    }

    console.error(`[GeminiService] [${context}] Error:`, errorMessage, { originalError: error });
    this.error.set(errorMessage);
    
    // Forward the error to the global handler for consistent UI feedback (e.g., toast)
    this.globalErrorHandler.handleError(error, `AI Core: ${context}`);

    return errorMessage;
  }

  async startChat(): Promise<void> {
    try {
      this.error.set(null);
      // Fix: Added explicit type casting for response from lastValueFrom
      const response = await lastValueFrom(
        this.applyRetry(
          this.httpClient.post<{ chatSessionId: string }>('/api/genai/chat/start', {
            systemInstruction: 'You are Evalion Assistant, professional, tactical, and efficient.',
          }),
          'chat initialization'
        )
      ) as { chatSessionId: string };
      if (response?.chatSessionId) this.chatSessionId = response.chatSessionId;
    } catch (e: unknown) {
      this.handleApiError(e, 'chat initialization');
    }
  }

  async sendMessageStream(
    message: string,
    onChunk: (chunkText: string) => void,
    onComplete: () => void
  ): Promise<void> {
    if (!this.chatSessionId) {
        this.error.set('Tactical session not established.');
        onComplete();
        return;
    }
    
    this.error.set(null);
    const url = `/api/genai/chat/${this.chatSessionId}/message`;
    
    try {
        // Wrapper for stream-based fetch with retry
        const fetchObs = from(fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('evalion_token')}`
            },
            body: JSON.stringify({ message, stream: true }),
        })).pipe(
          switchMap(async (response) => {
            if (!response.ok) {
              const body = await response.json().catch(() => ({}));
              throw new HttpErrorResponse({ status: response.status, error: body, url: url });
            }
            return response;
          })
        );

        const response = await lastValueFrom(this.applyRetry(fetchObs, 'message stream'));
        if (!response.body) throw new Error('Response stream empty.');

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let done = false;

        while (!done) {
            const { value, done: readerDone } = await reader.read();
            done = readerDone;
            const chunk = decoder.decode(value, { stream: true });
            if (chunk) this.ngZone.run(() => onChunk(chunk));
        }
    } catch (e: unknown) {
      this.handleApiError(e, 'message stream');
    } finally {
      this.ngZone.run(() => onComplete());
    }
  }

  async generateWithDeepThought(prompt: string): Promise<string> {
    const notifyId = this.globalErrorHandler.notify('info', 'AI Core: Engaging Deep Thought Protocol...', 0);
    try {
      this.error.set(null);
      // Fix: Added explicit type casting for response from lastValueFrom
      const response = await lastValueFrom(
        this.applyRetry(
          this.httpClient.post<{ responseText: string }>('/api/genai/deep-thought', { prompt }),
          'deep thought generation'
        )
      ) as { responseText: string };
      
      this.globalErrorHandler.clear(notifyId);
      this.globalErrorHandler.notify('success', 'AI Core: Intelligence gathered.', 2000);
      
      return response?.responseText || 'No intelligence gathered.';
    } catch (e: unknown) {
      this.globalErrorHandler.clear(notifyId);
      const msg = this.handleApiError(e, 'deep thought generation');
      return `[SYSTEM ERROR] ${msg}`;
    }
  }
  
  async generateStructuredJson<T>(prompt: string, schema: any): Promise<T | null> {
    try {
      this.error.set(null);
      // Fix: Added explicit type casting to T to resolve unknown assignability
      const response = await lastValueFrom(
        this.applyRetry(
          this.httpClient.post<T>('/api/genai/structured-json', { prompt, schema }),
          'structured data generation'
        )
      ) as T;
      return response || null;
    } catch (e: unknown) {
      this.handleApiError(e, 'structured data generation');
      return null;
    }
  }

  async transcribeAudio(audioBase64: string, mimeType: string): Promise<string> {
    const notifyId = this.globalErrorHandler.notify('info', 'AI Core: Processing Audio Stream...', 0);
    try {
      this.error.set(null);
      // Fix: Added explicit type casting for response from lastValueFrom
      const response = await lastValueFrom(
        this.applyRetry(
          this.httpClient.post<{ transcript: string }>('/api/genai/transcribe-audio', { audioBase64, mimeType }),
          'audio transcription'
        )
      ) as { transcript: string };
      
      this.globalErrorHandler.clear(notifyId);
      return response?.transcript || 'Transcription failed.';
    } catch (e: unknown) {
      this.globalErrorHandler.clear(notifyId);
      const msg = this.handleApiError(e, 'audio transcription');
      return `[TRANSCRIPTION ERROR] ${msg}`;
    }
  }

  async generateVideo(prompt: string, onProgress: (status: string) => void): Promise<string | null> {
    const notifyId = this.globalErrorHandler.notify('info', 'AI Core: Initiating Video Synthesis Handshake...', 3000);
    try {
      this.error.set(null);
      onProgress('Connecting to synthesis engine...');

      // Fix: Added explicit type casting for response from lastValueFrom
      const initial = await lastValueFrom(
        this.applyRetry(
          this.httpClient.post<{ operationId: string }>('/api/genai/generate-video', { prompt }),
          'video generation init'
        )
      ) as { operationId: string };
      
      if (!initial?.operationId) throw new Error('Handshake failed.');

      onProgress('Analyzing prompt context...');
      await new Promise(res => setTimeout(res, 1500));

      onProgress('Allocating computational resources...');
      await new Promise(res => setTimeout(res, 2000));

      let done = false;
      let url: string | undefined;
      let pollCount = 0;
      const maxPolls = 20; // 20 polls * 2s interval = 40s max wait time

      while (!done && pollCount < maxPolls) {
        const progress = Math.min(Math.round((pollCount / maxPolls) * 90), 90);
        onProgress(`Synthesizing frame vectors... [${progress}%]`);
        
        await new Promise(res => setTimeout(res, 2000));
        
        // Fix: Added explicit type casting for poll response from lastValueFrom
        const poll = await lastValueFrom(
          this.applyRetry(
            this.httpClient.get<{ done: boolean, videoUrl?: string }>(`/api/genai/generate-video/${initial.operationId}/status`),
            'polling video status',
            2 // Use fewer retries for polling
          )
        ) as { done: boolean, videoUrl?: string };
        
        if (poll) {
            done = poll.done;
            url = poll.videoUrl;
        }
        pollCount++;
      }

      if (!done) {
        throw new Error('Synthesis timeout. The operation took too long to complete.');
      }

      onProgress('Assembling video stream... [95%]');
      await new Promise(res => setTimeout(res, 1000));
      
      onProgress('Finalizing output... [99%]');
      await new Promise(res => setTimeout(res, 500));

      this.globalErrorHandler.notify('success', 'AI Core: Video synthesis complete.', 3000);
      return url || null;
    } catch (e: unknown) {
      this.globalErrorHandler.clear(notifyId);
      this.handleApiError(e, 'video generation');
      return null;
    }
  }

  async parseResume(resumeText: string): Promise<ParsedResume | null> {
    const notifyId = this.globalErrorHandler.notify('info', 'AI Core: Analyzing Dossier Structure...', 0);
    const prompt = this.promptService.generateResumeParserPrompt(resumeText);
    const schema = {
      type: Type.OBJECT,
      properties: {
        contactInfo: {
          type: Type.OBJECT,
          properties: { name: { type: Type.STRING }, email: { type: Type.STRING }, phone: { type: Type.STRING } },
          required: ['name', 'email'],
        },
        summary: { type: Type.STRING },
        workExperience: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              jobTitle: { type: Type.STRING },
              company: { type: Type.STRING },
              startDate: { type: Type.STRING },
              endDate: { type: Type.STRING },
              responsibilities: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
          },
        },
        skills: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: { name: { type: Type.STRING }, category: { type: Type.STRING } },
          },
        },
      },
      required: ['contactInfo', 'summary', 'workExperience', 'skills'],
    };
    
    try {
      const result = await this.generateStructuredJson<ParsedResume>(prompt, schema);
      this.globalErrorHandler.clear(notifyId);
      if (result) this.globalErrorHandler.notify('success', 'AI Core: Dossier parsed successfully.', 2000);
      return result;
    } catch (error) {
      this.globalErrorHandler.clear(notifyId);
      throw error;
    }
  }

  async generateInterviewQuestions(role: string, totalQuestions: number): Promise<InterviewQuestion[] | null> {
    const notifyId = this.globalErrorHandler.notify('info', 'AI Core: Formulating Interview Strategy...', 0);
    const prompt = this.promptService.generateInterviewQuestionsPrompt(role, totalQuestions);
    const schema = {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: { id: { type: Type.STRING }, text: { type: Type.STRING }, durationSeconds: { type: Type.NUMBER } },
        required: ['id', 'text', 'durationSeconds'],
      },
    };
    
    try {
      const result = await this.generateStructuredJson<InterviewQuestion[]>(prompt, schema);
      this.globalErrorHandler.clear(notifyId);
      return result;
    } catch (error) {
      this.globalErrorHandler.clear(notifyId);
      throw error;
    }
  }

  async processLiveTranscript(transcript: string): Promise<boolean> {
    if (!this.chatSessionId) return false;
    try {
      // Fix: Added explicit type casting for response from lastValueFrom
      const response = await lastValueFrom(
        this.applyRetry(
          this.httpClient.post<{ anomalyDetected: boolean }>('/api/genai/process-live-transcript', {
            chatSessionId: this.chatSessionId,
            transcript: transcript
          }),
          'live monitoring',
          1
        )
      ) as { anomalyDetected: boolean };
      return response?.anomalyDetected || false;
    } catch {
      return false;
    }
  }

  async rankCandidates(jobDescription: string, candidates: Candidate[]): Promise<CandidateRank[] | null> {
    const notifyId = this.globalErrorHandler.notify('info', 'AI Core: Executing Ranking Algorithm...', 0);
    const prompt = this.promptService.generateCandidateRankingPrompt(jobDescription, candidates);
    const schema = {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          candidateId: { type: Type.STRING },
          name: { type: Type.STRING },
          role: { type: Type.STRING },
          rank: { type: Type.NUMBER },
          justification: { type: Type.STRING },
        },
        required: ['candidateId', 'name', 'role', 'rank', 'justification'],
      },
    };
    
    try {
      const response = await this.generateStructuredJson<CandidateRank[]>(prompt, schema);
      this.globalErrorHandler.clear(notifyId);
      if (response) this.globalErrorHandler.notify('success', 'AI Core: Ranking sequence complete.', 2000);
      return response ? response.sort((a, b) => a.rank - b.rank) : null;
    } catch (error) {
      this.globalErrorHandler.clear(notifyId);
      throw error;
    }
  }
}

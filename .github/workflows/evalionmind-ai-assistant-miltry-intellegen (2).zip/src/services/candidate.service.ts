
import { Injectable, signal, computed, inject, effect } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { lastValueFrom } from 'rxjs';
// Removed unused import { mockInitialData } from '../interceptors/mock-backend.interceptor'; // Import the mock initial data

export interface CandidateApplication {
    role: string;
    status: 'applied' | 'pending_interview' | 'review' | 'approved' | 'rejected';
    date: string;
    score: number | null;
}

@Injectable({
    providedIn: 'root'
})
export class CandidateService {
    // FIX: Explicitly type injected HttpClient to resolve 'unknown' type error.
    private httpClient: HttpClient = inject(HttpClient);

    // State
    applications = signal<CandidateApplication[]>([]);

    constructor() {
        // this.loadState(); // REMOVED: This is now handled by APP_INITIALIZER
    }

    /**
     * Initializes the candidate applications directly with pre-fetched data from APP_INITIALIZER.
     * This bypasses HttpClient calls during the critical bootstrap phase.
     * @param data The initial candidate applications data.
     */
    initializeData(data: CandidateApplication[]): void {
      this.applications.set(data);
      console.log('[CandidateService] Applications initialized directly from pre-loaded data.');
    }

    async loadState(): Promise<void> {
        // If data is already initialized (by APP_INITIALIZER), no need to fetch again.
        // This provides a robust fallback if APP_INITIALIZER isn't used or data changes later.
        if (this.applications().length > 0) {
          console.log('[CandidateService] Applications already loaded. Skipping HTTP fetch.');
          return;
        }

        try {
            // Fix: Added explicit type casting for data from lastValueFrom
            const data = await lastValueFrom(this.httpClient.get<CandidateApplication[]>('/api/candidate/applications')) as CandidateApplication[];
            this.applications.set(data);
            console.log('[CandidateService] Applications loaded from backend.');
        } catch (error) {
            console.error('[CandidateService] CRITICAL: Failed to load applications from backend. Application initialization will be halted.', error);
            // Re-throw the error to ensure APP_INITIALIZER fails and stops app bootstrap.
            throw error;
        }
    }

    async addApplication(role: string): Promise<void> {
        try {
            // Post new application to the backend
            await lastValueFrom(this.httpClient.post<CandidateApplication>('/api/candidate/applications', { role }));
            await this.loadState(); // Reload state to reflect the new application
            console.log(`[CandidateService] Added new application for role: ${role} via backend.`);
        } catch (error) {
            console.error(`[CandidateService] Failed to add application for role: ${role}:`, error);
        }
    }

    async updateStatus(role: string, status: CandidateApplication['status'], score?: number): Promise<void> {
        try {
            // Patch application status/score to the backend
            await lastValueFrom(this.httpClient.patch<CandidateApplication>(`/api/candidate/applications/${role}`, { status, score }));
            await this.loadState(); // Reload state to reflect the update
            console.log(`[CandidateService] Updated status for application ${role} to ${status} via backend.`);
        } catch (error) {
            console.error(`[CandidateService] Failed to update status for application ${role}:`, error);
        }
    }
}
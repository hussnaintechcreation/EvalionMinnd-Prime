
import { Injectable, signal } from '@angular/core';
import { UserRole } from '../models/shared.interfaces';

@Injectable({
  providedIn: 'root',
})
export class UiService {
  isAboutModalOpen = signal(false);
  isLoginModalOpen = signal(false);
  preselectedRole = signal<UserRole | null>(null);

  openAbout(): void {
    this.isAboutModalOpen.set(true);
  }

  closeAbout(): void {
    this.isAboutModalOpen.set(false);
  }
  
  openLogin(role?: UserRole): void {
    this.preselectedRole.set(role || null);
    this.isLoginModalOpen.set(true);
  }
  
  closeLogin(): void {
    this.isLoginModalOpen.set(false);
    this.preselectedRole.set(null); // Reset on close
  }
}

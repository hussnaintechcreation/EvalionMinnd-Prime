
import { Injectable, signal, computed, inject, Injector } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { User, UserRole, AuthTokenPayload } from '../models/shared.interfaces';
import { lastValueFrom } from 'rxjs';

export interface RegistrationData {
  email: string;
  name: string;
  avatarUrl?: string;
  licenseNo?: string;
  contactNumber?: string;
  cnic?: string;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private injector = inject(Injector);
  private httpClient: HttpClient = inject(HttpClient);

  // --- State ---
  private _currentUser = signal<User | null>(null);
  private _token = signal<string | null>(null);
  private tokenTimer: any;
  
  // Lazy-loaded Router to break circular dependency (Router -> Guard -> AuthService -> Router)
  private _router: Router | null = null;
  private get router(): Router {
    if (!this._router) {
      this._router = this.injector.get(Router);
    }
    return this._router;
  }

  // --- Selectors ---
  currentUser = computed(() => this._currentUser());
  isAuthenticated = computed(() => !!this._token());
  currentUserRole = computed(() => this._currentUser()?.role || null);

  constructor() {
    this.loadSession();
  }

  // --- Auth Flow ---
  async loginOrSignup(data: RegistrationData, role: UserRole, isSignup: boolean): Promise<void> {
    console.log(`[Auth] Processing auth for ${data.email}... Mode: ${isSignup ? 'Signup' : 'Login'}`);
    
    let url = '';
    let payload: any;

    if (isSignup) {
        url = '/api/auth/signup';
        payload = { ...data, role };
    } else { // Login mode
        url = '/api/auth/login';
        payload = { email: data.email, role }; // Pass role for mock backend logic
    }

    try {
      // Fix: Added explicit type casting for response from lastValueFrom
      const response = await lastValueFrom(this.httpClient.post<{ user: User, token: string }>(url, payload)) as { user: User, token: string };
      
      if (response && typeof response === 'object' && 'user' in response && 'token' in response && response.user && response.token) {
        this.setSession(response.token, response.user);

        const destination = response.user.role === 'company' ? '/company' : '/candidate';
        this.router.navigate([destination]);
        console.log(`[Auth] Authentication successful. Navigating to ${destination}.`);
      } else {
        throw new Error('Authentication failed: Invalid or malformed response from server.');
      }
    } catch (error: any) {
      const errorMessage = error.error?.message || error.message || 'An unexpected authentication error occurred.';
      console.error(`[Auth] Backend authentication error: ${errorMessage}`, { originalError: error });
      
      throw new Error(errorMessage);
    }
  }

  async loginWithOAuth(provider: 'google' | 'microsoft', role: UserRole): Promise<void> {
     const mockName = role === 'company' ? 'Recruiter Operative' : 'Candidate Operative';
     const mockEmail = `user@evalion.${provider}.com`;
     await this.loginOrSignup({ name: mockName, email: mockEmail }, role, false);
  }

  // --- Profile Management ---
  async updateProfile(updates: Partial<User>): Promise<void> {
    const current = this._currentUser();
    if (!current) {
        throw new Error('No authenticated user to update profile.');
    }
    
    console.log('[Auth] Updating profile via API:', updates);
    try {
      // Fix: Added explicit type casting for response from lastValueFrom
      const updatedUser = await lastValueFrom(this.httpClient.patch<{ user: User }>(`/api/auth/profile`, updates)) as { user: User };
      if (updatedUser && updatedUser.user) {
        this._currentUser.set(updatedUser.user);
        localStorage.setItem('evalion_user', JSON.stringify(updatedUser.user));
        console.log('[Auth] User profile updated locally and on backend.');
      } else {
        throw new Error('Profile update failed: Invalid response from server.');
      }
    } catch (error: any) {
        console.error('[Auth] Profile update error:', error);
        throw new Error(error.error?.message || error.message || 'Failed to update profile.');
    }
  }

  // --- Session Management ---
  private setSession(token: string, user: User): void {
    this._token.set(token);
    this._currentUser.set(user);
    localStorage.setItem('evalion_token', token);
    localStorage.setItem('evalion_user', JSON.stringify(user));
    
    const tokenPayload = this.decodeJwt(token);
    const expiresIn = tokenPayload?.exp ? (tokenPayload.exp * 1000 - Date.now()) : (3600 * 1000);
    this.startAuthTimer(expiresIn); 
  }

  private loadSession(): void {
    const token = localStorage.getItem('evalion_token');
    const userStr = localStorage.getItem('evalion_user');

    if (token && userStr) {
      try {
        const user = JSON.parse(userStr);
        const tokenPayload = this.decodeJwt(token);
        if (tokenPayload && tokenPayload.exp * 1000 > Date.now()) {
            this._token.set(token);
            this._currentUser.set(user);
            this.startAuthTimer(tokenPayload.exp * 1000 - Date.now());
            console.log('[Auth] Session restored and validated from localStorage.');
        } else {
            console.warn('[Auth] Stored token is expired. Forcing logout.');
            this.logout();
        }
      } catch (e) {
        console.error('[Auth] Failed to parse user/token from localStorage. Clearing session.', e);
        this.logout();
      }
    }
  }

  logout(): void {
    this._token.set(null);
    this._currentUser.set(null);
    localStorage.removeItem('evalion_token');
    localStorage.removeItem('evalion_user');
    this.stopAuthTimer();
    this.router.navigate(['/']);
    console.log('[Auth] Session Terminated.');
  }

  private startAuthTimer(duration: number) {
    this.stopAuthTimer();
    this.tokenTimer = setTimeout(() => {
      console.warn('[Auth] Token Expired. Logging out.');
      this.logout();
    }, duration);
  }

  private stopAuthTimer() {
    if (this.tokenTimer) {
      clearTimeout(this.tokenTimer);
      this.tokenTimer = null;
    }
  }

  private decodeJwt(token: string): AuthTokenPayload | null {
    try {
      const parts = token.split('.');
      if (parts.length !== 3) {
        throw new Error('Invalid JWT format');
      }
      const payload = JSON.parse(atob(parts[1]));
      return payload as AuthTokenPayload;
    } catch (e) {
      console.error('Error decoding JWT:', e);
      return null;
    }
  }

  hasRole(allowedRoles: UserRole[]): boolean {
    const role = this.currentUserRole();
    return role ? allowedRoles.includes(role) : false;
  }
}

import { Injectable, signal, computed, WritableSignal, OnDestroy, inject, NgZone } from '@angular/core';
import { InterviewQuestion } from '../models/interview.model';
import { AntiCheatPayload, WsEvents, SignalingPayload } from '../models/shared.interfaces';
import { Subject, timer, Subscription, Observable, lastValueFrom } from 'rxjs';
import { webSocket, WebSocketSubject } from 'rxjs/webSocket';
import { EvaluationService } from './evaluation.service';
import { GeminiService } from './gemini.service';
import { HttpClient } from '@angular/common/http';
import { AuthService } from './auth.service';
import { GlobalErrorHandlerService } from './global-error-handler.service'; // Inject GlobalErrorHandlerService

export type InterviewState = 'not-started' | 'in-progress' | 'finished';

@Injectable({
  providedIn: 'root',
})
export class InterviewService implements OnDestroy {
  private evaluationService = inject(EvaluationService);
  private geminiService = inject(GeminiService);
  private httpClient = inject(HttpClient);
  private authService = inject(AuthService);
  private ngZone = inject(NgZone);
  private globalErrorHandler = inject(GlobalErrorHandlerService); // Inject GlobalErrorHandlerService

  // --- WebSocket State ---
  private socket$!: WebSocketSubject<any>;
  private socketSubscription!: Subscription;
  public signaling$ = new Subject<SignalingPayload>();
  
  private timerInterval: any = null;
  // private proctoringSimulationInterval: any = null; // Removed client-side simulation

  // --- Public State ---
  interviewState: WritableSignal<InterviewState> = signal('not-started');
  questions = signal<InterviewQuestion[]>([]);
  currentQuestionIndex = signal(0);
  timeLeft = signal(0);
  interviewTranscript = signal<{ questionId: string, questionText: string, answer: string }[]>([]);
  
  // Track the role being interviewed for to enable role-specific benchmarking
  activeRole = signal<string>('Senior Full-Stack Engineer'); 
  private currentInterviewSessionId: string | null = null; // To store unique session ID from backend

  public antiCheatEvent$ = new Subject<AntiCheatPayload['type']>();

  // --- Computed ---
  readonly totalQuestions = computed(() => this.questions().length);
  readonly currentQuestionNumber = computed(() => this.currentQuestionIndex() + 1);
  readonly currentQuestion = computed(() => {
    if (this.interviewState() === 'in-progress' || this.interviewState() === 'finished') {
      return this.questions()[this.currentQuestionIndex()];
    }
    return null;
  });

  constructor() {
    this.ngZone.runOutsideAngular(() => {
      document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
      window.addEventListener('blur', () => this.ngZone.run(() => this.trackAntiCheatEvent('blur')));
      window.addEventListener('focus', () => this.ngZone.run(() => this.trackAntiCheatEvent('focus')));
    });
  }

  // --- WebSocket Implementation (Client-Side Gateway) ---
  connectToGateway(sessionId: string): void {
    if (this.socket$ && !this.socket$.closed) {
      console.log('[WS] Already connected to Interview Gateway.');
      return;
    }
    
    // Replace with your actual WebSocket backend URL
    const wsUrl = `ws://localhost:3000/interview`; // Assuming NestJS WS gateway on port 3000
    this.socket$ = webSocket(wsUrl);

    this.socketSubscription = this.socket$.subscribe({
      next: msg => this.ngZone.run(() => this.handleWsMessage(msg)), // Ensure messages are processed in Angular zone
      error: err => this.ngZone.run(() => {
        console.error('[WS] WebSocket Error:', err);
        this.globalErrorHandler.handleError(err, 'Interview Gateway'); // Notify global error handler
      }),
      complete: () => this.ngZone.run(() => console.log('[WS] WebSocket connection closed.')),
    });

    // Send join room message with context
    const currentUser = this.authService.currentUser();
    if (currentUser) {
        this.socket$.next({
            event: WsEvents.JOIN_ROOM,
            data: { sessionId: sessionId, userId: currentUser.id, role: currentUser.role }
        });
        console.log(`[WS] Connected and joined room: ${sessionId} for user ${currentUser.id}`);
    } else {
        console.error('[WS] Cannot join room: current user not authenticated.');
    }
  }

  private handleWsMessage(msg: any): void {
    if (msg.event === WsEvents.SIGNAL && msg.data) {
      console.log('[WS] Signal Received:', msg.data.type);
      this.signaling$.next(msg.data);
    } else if (msg.event === WsEvents.ANTI_CHEAT_LOG && msg.data) {
        console.warn('[WS] Server-side Anti-Cheat Event:', msg.data.type);
        this.antiCheatEvent$.next(msg.data.type);
    } else if (msg.event === 'interviewStatus' && msg.data) {
        // Handle backend-driven interview state changes, e.g., next question
        console.log('[WS] Interview Status Update:', msg.data);
        // Implement logic to process next question or end interview if backend dictates
    }
  }

  sendSignal(payload: SignalingPayload): void {
    if (this.socket$) {
      this.socket$.next({ event: WsEvents.SIGNAL, data: payload });
      console.log('[WS] Sending Signal:', payload.type);
    }
  }
  
  // --- Anti-Cheat Logic ---
  private handleVisibilityChange(): void {
    if (document.hidden) {
      this.ngZone.run(() => this.trackAntiCheatEvent('tab_hidden'));
    }
  }

  public trackAntiCheatEvent(type: AntiCheatPayload['type']): void {
    if (this.interviewState() !== 'in-progress' || !this.socket$ || !this.currentInterviewSessionId) return;
    
    // Client-side visual alert
    this.antiCheatEvent$.next(type);

    const currentUser = this.authService.currentUser();
    if (!currentUser) {
        console.error('[Anti-Cheat] Cannot log event: no current user.');
        return;
    }

    const payload: AntiCheatPayload = { 
        sessionId: this.currentInterviewSessionId, 
        chatSessionId: this.geminiService['chatSessionId'], // Access private chatSessionId if available
        type, 
        timestamp: Date.now(),
        // Add confidence if detection logic provides it
    };
    
    // Send anti-cheat event to backend via WebSocket
    this.socket$.next({ event: WsEvents.ANTI_CHEAT_LOG, data: payload });
    console.warn(`[Anti-Cheat] Violation Detected: ${type}. Logging to server via WebSocket.`);
  }

  // Removed startProctoringSimulation and stopProctoringSimulation as client-side simulation is removed.
  // Real proctoring events should come from the backend via WebSocket or server-side analysis.

  // --- Interview Flow Control ---
  async prepareInterview(role: string, totalQuestions: number = 10): Promise<void> {
    this.activeRole.set(role); // Set role context
    console.log(`[InterviewService] Generating ${totalQuestions} questions for role: ${role}...`);
    try {
      // Use the refactored GeminiService to get questions from backend
      const generatedQuestions = await this.geminiService.generateInterviewQuestions(role, totalQuestions);
      if (generatedQuestions && generatedQuestions.length > 0) {
        this.questions.set(generatedQuestions);
        console.log('[InterviewService] AI questions generated successfully via backend.');
      } else {
        console.error('[InterviewService] AI failed to generate questions, using fallback.');
        this.globalErrorHandler.handleError('AI failed to generate questions, using fallback.', 'Question Generation'); // Notify global error handler
        this.useFallbackQuestions();
      }
    } catch (error) {
      console.error('[InterviewService] Error generating questions via backend, using fallback:', error);
      this.globalErrorHandler.handleError(error, 'Question Generation'); // Notify global error handler
      this.useFallbackQuestions();
    }
  }
  
  private useFallbackQuestions(): void {
    this.questions.set([
      { id: 'fb1', text: 'Describe a situation where you had to re-architect a legacy system under strict time constraints. What trade-offs did you accept?', durationSeconds: 90 },
      { id: 'fb2', text: 'Explain the CAP theorem and how you would choose between consistency and availability in a distributed financial ledger.', durationSeconds: 90 },
      { id: 'fb3', text: 'How do you handle a disagreement with a senior stakeholder regarding a critical technical decision that impacts system security?', durationSeconds: 90 },
      { id: 'fb4', text: 'Walk us through your strategy for debugging a memory leak in a production environment with minimal observability tools.', durationSeconds: 90 },
      { id: 'fb5', text: 'Scenario: Your deployment pipeline fails one hour before a critical client demo. Outline your immediate incident response protocol.', durationSeconds: 90 },
    ]);
  }

  async startInterview(candidateId: string): Promise<boolean> {
    if (this.interviewState() !== 'not-started') return false;
    
    // If questions empty, try generating for default role (failsafe)
    if (this.questions().length === 0) {
        await this.prepareInterview(this.activeRole(), 10);
    }
    
    if (this.questions().length === 0) {
        console.error("Interview cannot start, no questions are available.");
        this.globalErrorHandler.handleError("Interview cannot start, no questions are available.", 'Interview Start'); // Notify global error handler
        return false;
    }
    
    // Generate a unique session ID for the interview
    this.currentInterviewSessionId = `interview-${candidateId}-${Date.now()}`;
    this.connectToGateway(this.currentInterviewSessionId); // Connect to WebSocket with this session ID

    this.currentQuestionIndex.set(0);
    this.interviewTranscript.set([]);
    this.interviewState.set('in-progress');
    this.startTimerForCurrentQuestion();
    // this.startProctoringSimulation(); // Removed client-side simulation
    return true;
  }

  nextQuestion(currentAnswer: string): void {
    this.recordAnswerForCurrentQuestion(currentAnswer);
    if (this.currentQuestionIndex() < this.totalQuestions() - 1) {
      this.currentQuestionIndex.update(i => i + 1);
      this.startTimerForCurrentQuestion();
    } else {
      this.endInterview();
    }
  }
  
  private recordAnswerForCurrentQuestion(answer: string): void {
    const currentQ = this.currentQuestion();
    if (currentQ) {
      this.interviewTranscript.update(transcript => [
        ...transcript,
        {
          questionId: currentQ.id,
          questionText: currentQ.text,
          answer: answer.trim() || "The candidate did not provide a substantial answer to this question."
        }
      ]);
    }
  }

  endInterview(finalAnswer?: string): void {
    if(this.interviewState() === 'finished') return;

    this.stopTimer();
    // this.stopProctoringSimulation(); // Removed client-side simulation
    
    // Record the final answer if provided
    if(finalAnswer && this.interviewTranscript().length < this.questions().length) {
        this.recordAnswerForCurrentQuestion(finalAnswer);
    }

    this.interviewState.set('finished');
    if (this.socket$) this.socket$.complete(); // Close WebSocket connection
    
    // Trigger Automated Grading with Role Context
    // Pass the actual candidate ID from the context
    this.evaluationService.processInterview(this.authService.currentUser()?.id || 'unknown_candidate', this.activeRole(), this.interviewTranscript());
  }
  
  private startTimerForCurrentQuestion(): void {
    this.stopTimer();
    const question = this.currentQuestion();
    if (!question) return;

    this.timeLeft.set(question.durationSeconds);
    this.timerInterval = setInterval(() => {
      this.timeLeft.update(t => t - 1);
      if (this.timeLeft() <= 0) {
        // Automatically move to the next question when time is up.
        // The current transcript state will be captured by the calling component.
        this.nextQuestion(''); 
      }
    }, 1000);
  }

  private stopTimer(): void {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  }

  ngOnDestroy(): void {
    this.stopTimer();
    // this.stopProctoringSimulation(); // Removed client-side simulation
    document.removeEventListener('visibilitychange', this.handleVisibilityChange);
    window.removeEventListener('blur', () => this.ngZone.run(() => this.trackAntiCheatEvent('blur')));
    window.removeEventListener('focus', () => this.ngZone.run(() => this.trackAntiCheatEvent('focus')));
    if (this.socketSubscription) this.socketSubscription.unsubscribe();
    if (this.socket$) this.socket$.complete();
  }
}


import { Injectable } from '@angular/core';
import { CandidateProfile } from '../models/candidate.model';
import { ChatMessage } from '../models/chat.model';
import { PerQuestionAnalysis, CandidateRank } from '../models/evaluation.model';
import { Candidate } from '../models/ats.model';

@Injectable({
  providedIn: 'root',
})
export class PromptService {

  /**
   * Generates a context-aware system instruction for the Interview Bot.
   */
  generateInterviewSystemPrompt(candidate: CandidateProfile, roleDescription: string): string {
    return `
      You are an elite technical interviewer for EvalionMind. 
      Candidate Name: ${candidate.name}
      Role Applied: ${candidate.role}
      
      Job Context: ${roleDescription}

      Your Goal: Assess the candidate's technical depth, problem-solving ability, and cultural fit.
      
      Rules:
      1. Ask one question at a time.
      2. If the candidate gives a vague answer, drill down with "Could you elaborate on...".
      3. Maintain a professional, encouraging, yet rigorous tone.
      4. Do not reveal the answer key.
    `.trim();
  }

  /**
   * Generates a prompt to analyze a candidate's answer for a single question.
   * This prompt has been updated to request a more detailed feedback structure.
   */
  generatePerQuestionAnalysisPrompt(question: string, answer: string): string {
    return `
      Analyze the following candidate's answer to a technical interview question. Provide a score from 0-100 for each metric and give detailed, structured feedback.

      Question Asked: "${question}"
      
      Candidate's Answer: "${answer}"
      
      Evaluate the response and provide your analysis in the required JSON format.
      - clarity: How well-structured and easy to understand is the answer?
      - relevance: How well does the answer address the specific question asked?
      - technicalDepth: How accurate and deep is the technical knowledge demonstrated?
      - keywords: Extract key technical terms used.
      - detailedFeedback: Provide a structured object with the following fields. The feedback must be professional, direct, and actionable.
        - technicalAccuracy: Critically evaluate the technical correctness. Be specific. Example: "The candidate correctly identified the use of a hash map for O(1) lookups, but incorrectly stated its collision resolution is always linear probing." Do not be vague.
        - communicationClarity: Analyze the structure and articulation of the answer. Was it logical and easy to follow? Did they use precise terminology? Example: "The candidate explained the concept in a clear, step-by-step manner, but used the term 'variable' interchangeably with 'signal', causing some confusion."
        - problemSolvingApproach: Evaluate the candidate's methodology and thought process. Did they clarify requirements? Consider trade-offs or edge cases? Example: "The candidate immediately jumped to a brute-force solution without first discussing constraints or exploring more optimal approaches."
        - keyStrengths: A bullet-point list of 1-2 specific, positive aspects of this answer. Be concrete. Example: "Effectively used an analogy to explain a complex topic."
        - areasForImprovement: A bullet-point list of 1-2 specific, actionable suggestions for improvement. Example: "Could have improved the answer by mentioning the performance implications of their chosen data structure."
        
      Constraint: Use professional, objective language. Avoid casual tone.
    `.trim();
  }
  
  /**
   * Generates a prompt for a final, holistic summary of the interview.
   */
  generateFinalSummaryPrompt(analyses: PerQuestionAnalysis[]): string {
    const analysisText = analyses.map(a => 
        `Question: "${a.questionText}"\nScores: Clarity(${a.clarity}), Relevance(${a.relevance}), TechDepth(${a.technicalDepth})`
    ).join('\n\n');

    return `
      Based on the following per-question analysis of a candidate's interview, generate a final summary report.
      
      Individual Question Analyses:
      ${analysisText}
      
      Your task is to synthesize this data into a holistic evaluation.
      - Provide an overall summary of the performance.
      - List 2-3 key strengths demonstrated.
      - List 1-2 concrete areas for improvement.
      
      Provide your response in the required JSON format.
    `.trim();
  }

  /**
   * Generates a follow-up question based on conversation history.
   */
  generateFollowUpPrompt(history: ChatMessage[]): string {
    const context = history.slice(-3).map(m => `${m.role.toUpperCase()}: ${m.text}`).join('\n');
    return `
      Based on the recent conversation history below, generate a relevant, deeper follow-up technical question.
      Avoid repeating previous questions.
      
      Conversation:
      ${context}
    `.trim();
  }

  /**
   * Generates a prompt to parse a resume into a structured JSON object.
   */
  generateResumeParserPrompt(resumeText: string): string {
    return `
      You are an expert HR analyst and data extraction AI for the EvalionMind platform.
      Your task is to parse the following resume text and extract the information into a structured JSON format.
      Be precise and handle missing information gracefully by omitting the field or using null.
      
      - Extract name, email, phone, and LinkedIn URL.
      - Synthesize a brief professional summary from the text.
      - Detail all work experience, including titles, companies, dates, and key responsibilities.
      - List all educational qualifications.
      - Extract and categorize all technical and soft skills.

      Resume Text to Analyze:
      ---
      ${resumeText}
      ---

      Return ONLY the JSON object that adheres to the provided schema.
    `.trim();
  }

  /**
   * Generates a prompt to create interview questions for a specific role.
   * Now explicitly requests durationSeconds.
   */
  generateInterviewQuestionsPrompt(role: string, totalQuestions: number): string {
    return `
      You are an elite technical evaluator for EvalionMind.
      Generate a comprehensive set of ${totalQuestions} interview questions for the role of "${role}".

      REQUIREMENTS:
      1. **Categories**: You must generate a mix of questions covering:
         - **Technical Questions (40%)**: Focus on advanced concepts, system design, and language-specific nuances.
         - **Behavioral Questions (30%)**: Target conflict resolution, leadership under pressure, and failure management (STAR method).
         - **Situational Questions (30%)**: Hypothetical scenarios testing critical thinking and decision-making in high-stakes environments.
      2. **Difficulty Level**: Medium to High. Exclude entry-level trivia.
      3. **Duration**: Each question MUST include an estimated 'durationSeconds' for candidate response (e.g., 60, 90, 120 seconds).

      STRICT RULES:
      - **No Repetitive Questions**: Ensure unique domains are covered.
      - **Professional Tone**: Use precise, military-grade or corporate-professional language. No casual slang.
      - **Structure**: Questions must be clear, unambiguous, and challenging.

      Return the response in the required JSON format.
    `.trim();
  }

  /**
   * NEW: Generates a prompt for ranking candidates based on a job description and their profiles/evaluations.
   */
  generateCandidateRankingPrompt(jobDescription: string, candidates: Candidate[]): string {
    const candidateData = candidates.map(c => `
      Candidate ID: ${c.id}
      Name: ${c.name}
      Role Applied: ${c.role}
      Current Status: ${c.status}
      Overall Score (if available): ${c.evaluation?.overallScore || 'N/A'}
      Summary (if available): ${c.evaluation?.summary || 'N/A'}
      Skills (from resume/evaluation): ${c.evaluation?.detailedAnalysis.flatMap(d => d.keywords).join(', ') || 'N/A'}
      ---
    `).join('\n');

    return `
      You are an elite AI-powered candidate ranking system for EvalionMind.
      Your task is to rank the provided candidates for the following job description.

      Job Description:
      ---
      ${jobDescription}
      ---

      Candidates for Ranking:
      ---
      ${candidateData}
      ---

      Rank the candidates from 1 (highest fit) to ${candidates.length} (lowest fit) based on their profiles and alignment with the job description.
      For each candidate, provide a brief, data-driven justification for their assigned rank.
      Return the response in a JSON array format, sorted by rank.
    `.trim();
  }
}
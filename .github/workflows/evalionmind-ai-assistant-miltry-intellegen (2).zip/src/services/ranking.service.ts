
import { Injectable, inject, signal } from '@angular/core';
import { GeminiService } from './gemini.service';
import { PromptService } from './prompt.service';
import { CandidateRank } from '../models/evaluation.model';
import { Candidate } from '../models/ats.model';
import { GlobalErrorHandlerService } from './global-error-handler.service';

@Injectable({
  providedIn: 'root',
})
export class RankingService {
  private geminiService = inject(GeminiService);
  private promptService = inject(PromptService);
  private globalErrorHandler = inject(GlobalErrorHandlerService);

  isLoading = signal(false);
  error = signal<string | null>(null);

  /**
   * Ranks a list of candidates against a given job description using the AI.
   * @param jobDescription The description of the job for which candidates are being ranked.
   * @param candidates The list of candidates to be ranked.
   * @returns A promise that resolves to an array of CandidateRank or null if an error occurs.
   */
  async rankCandidates(jobDescription: string, candidates: Candidate[]): Promise<CandidateRank[] | null> {
    if (!jobDescription.trim()) {
      this.error.set('Job description cannot be empty for ranking.');
      return null;
    }
    if (!candidates || candidates.length === 0) {
      this.error.set('No candidates provided for ranking.');
      return null;
    }

    this.isLoading.set(true);
    this.error.set(null);

    try {
      // The GeminiService now has a dedicated proxy method for ranking
      const rankedResults = await this.geminiService.rankCandidates(jobDescription, candidates);
      
      if (rankedResults) {
        // Update local candidates with their rank for display if needed
        // For simplicity, we just return the ranked list here.
        return rankedResults;
      } else {
        throw new Error(this.geminiService.error() || 'AI failed to generate candidate ranks.');
      }
    } catch (e: any) {
      console.error('[RankingService] Error ranking candidates:', e);
      this.error.set(e.message || 'An unexpected error occurred during ranking.');
      this.globalErrorHandler.handleError(e); // Notify global error handler
      return null;
    } finally {
      this.isLoading.set(false);
    }
  }
}
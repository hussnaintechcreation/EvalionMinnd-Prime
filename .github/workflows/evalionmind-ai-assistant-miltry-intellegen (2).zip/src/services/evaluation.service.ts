
import { Injectable, signal, inject } from '@angular/core';
import { GeminiService } from './gemini.service';
import { PromptService } from './prompt.service';
import { EvaluationReport, PerQuestionAnalysis, RoleBenchmark } from '../models/evaluation.model';
import { Type } from '@google/genai';
import { AtsService } from './ats.service';
import { HttpClient } from '@angular/common/http';
import { lastValueFrom } from 'rxjs';
import { GlobalErrorHandlerService } from './global-error-handler.service'; // Inject GlobalErrorHandlerService

export type EvaluationState = 'idle' | 'processing' | 'complete' | 'error';

// This is the structure we expect from the AI for each question's analysis
interface AiPerQuestionResponse {
  clarity: number;
  relevance: number;
  technicalDepth: number;
  keywords: string[];
  detailedFeedback: {
    technicalAccuracy: string;
    communicationClarity: string;
    problemSolvingApproach: string;
    keyStrengths: string[];
    areasForImprovement: string[];
  };
}

interface AiFinalSummaryResponse {
    summary: string;
    strengths: string[];
    areasForImprovement: string[];
}

@Injectable({
  providedIn: 'root',
})
export class EvaluationService {
  private geminiService = inject(GeminiService);
  private promptService = inject(PromptService);
  private atsService = inject(AtsService);
  // FIX: Explicitly type injected HttpClient to resolve 'unknown' type error.
  private httpClient: HttpClient = inject(HttpClient);
  private globalErrorHandler = inject(GlobalErrorHandlerService); // Inject GlobalErrorHandlerService

  evaluationState = signal<EvaluationState>('idle');
  evaluationReport = signal<EvaluationReport | null>(null);

  async processInterview(candidateId: string, role: string, interviewData: { questionId: string, questionText: string, answer: string }[]): Promise<void> {
    if (!interviewData || interviewData.length === 0) {
        console.warn('[EvaluationService] No interview data to process.');
        this.evaluationState.set('error');
        this.globalErrorHandler.handleError('No interview data to process for evaluation.', 'Evaluation'); // Notify global handler
        return;
    }

    this.evaluationState.set('processing');
    this.evaluationReport.set(null);
    const notifyId = this.globalErrorHandler.notify('info', 'AI Core: Engaging Neural Evaluation Protocol...', 0);

    try {
      const detailedAnalysis: PerQuestionAnalysis[] = [];
      let totalScore = 0;

      // Step 1: Analyze each question-answer pair via backend
      for (const item of interviewData) {
        const analysis = await this.analyzeResponse(item.questionText, item.answer);
        if (analysis) {
          const perQuestionReport: PerQuestionAnalysis = { ...analysis, ...item };
          detailedAnalysis.push(perQuestionReport);
          totalScore += (analysis.clarity + analysis.relevance + analysis.technicalDepth) / 3;
        }
      }

      if(detailedAnalysis.length === 0) {
          throw new Error("AI analysis of individual questions failed.");
      }
      
      const overallScore = Math.round(totalScore / detailedAnalysis.length);

      // Step 2: Generate the final summary via backend
      const finalSummary = await this.generateFinalSummary(detailedAnalysis);
       if (!finalSummary) {
        throw new Error("AI failed to generate a final summary.");
      }

      // Step 3: Assemble the final report
      const report: EvaluationReport = {
        overallScore,
        detailedAnalysis,
        ...finalSummary
      };

      this.evaluationReport.set(report);
      
      // Step 4: Persist Data to Candidate Record via ATS Service
      await this.atsService.updateCandidateEvaluation(candidateId, report); 
      
      this.evaluationState.set('complete');
      this.globalErrorHandler.clear(notifyId);
      this.globalErrorHandler.notify('success', 'AI Core: Neural Evaluation complete. Dossier generated.', 4000);

    } catch (error) {
      console.error('[EvaluationService] Failed to process interview:', error);
      this.evaluationState.set('error');
      this.globalErrorHandler.clear(notifyId);
      this.globalErrorHandler.handleError(error, 'Evaluation'); // Notify global handler
    }
  }

  // --- Benchmarking Logic ---
  async getRoleBenchmark(role: string): Promise<RoleBenchmark> {
    try {
      // Fix: Added explicit type casting for data from lastValueFrom
      const data = await lastValueFrom(this.httpClient.get<RoleBenchmark>(`/api/benchmarks/${role}`)) as RoleBenchmark;
      return data;
    } catch (error) {
      console.error(`[EvaluationService] Failed to load benchmark for role '${role}' from backend, using fallback:`, error);
      this.globalErrorHandler.handleError(`Failed to load benchmark for role '${role}'. Using default data.`, 'Benchmarking'); // Notify global handler
      // Fallback to a default benchmark if backend call fails
      return this.getDefaultBenchmark(role);
    }
  }

  private getDefaultBenchmark(role: string): RoleBenchmark {
    return {
      role: role,
      avgOverallScore: 78,
      avgClarity: 82,
      avgRelevance: 85,
      avgTechnicalDepth: 72,
      sampleSize: 1240 // Simulated industry sample size
    };
  }

  private async analyzeResponse(question: string, answer: string): Promise<AiPerQuestionResponse | null> {
    const prompt = this.promptService.generatePerQuestionAnalysisPrompt(question, answer);
    const schema = {
      type: Type.OBJECT,
      properties: {
        clarity: { type: Type.NUMBER, description: 'Score (0-100) for how clear and understandable the answer was.' },
        relevance: { type: Type.NUMBER, description: 'Score (0-100) for how well the answer addressed the specific question.' },
        technicalDepth: { type: Type.NUMBER, description: 'Score (0-100) for the technical accuracy and depth of knowledge demonstrated.' },
        keywords: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'A list of key technical terms used by the candidate.' },
        detailedFeedback: {
            type: Type.OBJECT,
            properties: {
                technicalAccuracy: { type: Type.STRING, description: "A specific, direct critique of the answer's technical correctness. Example: 'The candidate correctly identified X, but was incorrect about Y.' " },
                communicationClarity: { type: Type.STRING, description: "Feedback on the candidate's articulation and structure. Example: 'The explanation was logical but could have been more concise.' " },
                problemSolvingApproach: { type: Type.STRING, description: "Analysis of the candidate's methodology. Example: 'Good use of the STAR method to frame the response.' " },
                keyStrengths: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A bullet-point list of 1-2 concrete positive aspects. Example: 'Effectively used an analogy to explain a complex topic.'" },
                areasForImprovement: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A bullet-point list of 1-2 actionable suggestions. Example: 'Could have mentioned performance trade-offs.'" },
            },
            required: ['technicalAccuracy', 'communicationClarity', 'problemSolvingApproach', 'keyStrengths', 'areasForImprovement'],
        }
      },
      required: ['clarity', 'relevance', 'technicalDepth', 'keywords', 'detailedFeedback'],
    };
    // Use GeminiService proxy to call backend for structured JSON analysis
    return this.geminiService.generateStructuredJson<AiPerQuestionResponse>(prompt, schema);
  }
  
  private async generateFinalSummary(analyses: PerQuestionAnalysis[]): Promise<AiFinalSummaryResponse | null> {
    const prompt = this.promptService.generateFinalSummaryPrompt(analyses);
     const schema = {
      type: Type.OBJECT,
      properties: {
        summary: { type: Type.STRING, description: 'A holistic summary of the candidate\'s performance.' },
        strengths: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'A list of 2-3 key strengths.' },
        areasForImprovement: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'A list of 1-2 areas for improvement.' },
      },
      required: ['summary', 'strengths', 'areasForImprovement'],
    };
    // Use GeminiService proxy to call backend for structured JSON summary
    return this.geminiService.generateStructuredJson<AiFinalSummaryResponse>(prompt, schema);
  }
}

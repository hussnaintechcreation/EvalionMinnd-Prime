import { Injectable, signal, inject } from '@angular/core';
import { CertificateData } from '../models/certificate.model';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class CertificateService {
  private authService = inject(AuthService);

  // In a real app, this would be fetched from a secure backend API
  // after the company approves the candidate's performance.
  getCertificateData = signal<CertificateData>({
    candidateName: this.authService.currentUser()?.name ?? 'Valued Candidate',
    role: 'AI-Verified Full-Stack Engineer',
    issueDate: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
    certificateId: `EM-CERT-${new Date().getTime()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
    issuingAuthority: 'EvalionMind AI Core',
    issuingAuthorityTitle: 'Chief Evaluation Officer'
  });
}


import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { lastValueFrom } from 'rxjs';
import { GlobalErrorHandlerService } from './global-error-handler.service'; // Inject GlobalErrorHandlerService

// Declare global Stripe object from the loaded script
declare var Stripe: any;

@Injectable({
  providedIn: 'root'
})
export class StripeService {
  // FIX: Explicitly type injected HttpClient to resolve 'unknown' type error.
  private httpClient: HttpClient = inject(HttpClient);
  private globalErrorHandler = inject(GlobalErrorHandlerService); // Inject GlobalErrorHandlerService
  private stripe: any;
  // NOTE: In production, this key must come from environment variables (process.env.STRIPE_PUBLIC_KEY)
  // For this applet, keeping it as a placeholder. In a real Angular app, it might be provided via DI from an environment file.
  private readonly publicKey = 'pk_test_51MzE7qK9...PLACEHOLDER_KEY'; 

  constructor() {
    this.initStripe();
  }

  private initStripe() {
    if (typeof Stripe !== 'undefined') {
      this.stripe = Stripe(this.publicKey);
    } else {
      console.warn('[StripeService] Stripe.js script not loaded. Payment features will run in simulation mode.');
      this.globalErrorHandler.handleError('Stripe.js not loaded. Payment features may be unavailable.', 'Stripe Initialization'); // Notify global error handler
    }
  }

  /**
   * INITIATE CHECKOUT (Billing)
   * Calls the Backend NestJS API to create a secure checkout session.
   * Endpoint: POST /api/v1/billing/create-checkout-session
   */
  async createCheckoutSession(priceId: string): Promise<string> {
    console.log(`[StripeService] Requesting Secure Session for Price: ${priceId}`);
    
    try {
      // Fix: Added explicit type casting for response from lastValueFrom
      const response = await lastValueFrom(this.httpClient.post<{ sessionId: string }>('/api/billing/create-checkout-session', { priceId })) as { sessionId: string };
      if (response && response.sessionId) {
        return response.sessionId;
      } else {
        throw new Error('Backend failed to create Stripe checkout session.');
      }
    } catch (error: any) {
      console.error('[StripeService] Failed to create checkout session:', error);
      this.globalErrorHandler.handleError(error, 'Create Checkout Session'); // Notify global error handler
      throw new Error(error.error?.message || error.message || 'An error occurred when creating checkout session.');
    }
  }

  /**
   * REDIRECT TO STRIPE
   * Hand off control to Stripe's hosted checkout page.
   */
  async redirectToCheckout(sessionId: string): Promise<void> {
    if (!this.stripe) {
      const errorMsg = 'Stripe.js failed to load. Cannot proceed. Please check your network connection or disable ad blockers.';
      console.error('[StripeService]', errorMsg);
      this.globalErrorHandler.handleError(errorMsg, 'Stripe Redirect'); // Notify global error handler
      throw new Error(errorMsg);
    }

    console.log(`[StripeService] Redirecting to Checkout Session: ${sessionId}`);
    
    const { error } = await this.stripe.redirectToCheckout({ sessionId });
    
    if (error) {
      console.error('[StripeService] Stripe redirection failed:', error.message);
      this.globalErrorHandler.handleError(error.message, 'Stripe Redirect'); // Notify global error handler
      throw new Error(error.message);
    }
  }

  /**
   * CONNECT ONBOARDING (Payouts)
   * For the "Stripe Connect" requirement: Handles onboarding users to receive payouts.
   */
  async createConnectAccountLink(userId: string): Promise<string> {
    // This would typically involve a backend call to create an account link
    console.log(`[StripeService] Generating Connect Account Link for User: ${userId} (Simulated)`);
    await new Promise(resolve => setTimeout(resolve, 1000));
    return 'https://connect.stripe.com/setup/s/...mock_link'; // Still a mock link as per original request.
  }

  /**
   * WEBHOOK HANDLER (Simulation)
   * Now makes a call to the backend endpoint to confirm webhook processing.
   */
  async simulateWebhookEvent(sessionId: string): Promise<boolean> {
     console.log(`[Stripe Webhook] Sending confirmation for session ${sessionId} to backend.`);
     try {
       // Fix: Added explicit type casting for response from lastValueFrom
       const response = await lastValueFrom(this.httpClient.post<{ success: boolean }>('/api/billing/webhook-confirm', { sessionId })) as { success: boolean };
       if (response?.success) {
         console.log(`[Stripe Webhook] Backend confirmed webhook processing for session ${sessionId}.`);
         return true;
       } else {
         throw new Error('Backend failed to confirm webhook processing.');
       }
     } catch (error: any) {
       console.error('[StripeService] Simulate webhook error:', error);
       this.globalErrorHandler.handleError(error, 'Webhook Simulation'); // Notify global error handler
       throw new Error(error.error?.message || error.message || 'An error occurred during webhook confirmation.');
     }
  }
}

import { Injectable, signal, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PipelineStage, Candidate, CandidateStatus } from '../models/ats.model';
import { EvaluationReport } from '../models/evaluation.model';
import { lastValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AtsService {
  private httpClient: HttpClient = inject(HttpClient);

  // State
  pipelineStages = signal<PipelineStage[]>([]);

  constructor() {}

  initializeData(data: PipelineStage[]): void {
    this.pipelineStages.set(data);
    console.log('[ATS] Pipeline initialized directly from pre-loaded data.');
  }

  async loadPipeline(): Promise<void> {
    if (this.pipelineStages().length > 0) {
      console.log('[ATS] Pipeline already loaded. Skipping HTTP fetch.');
      return;
    }

    try {
      // Fix: Added explicit type casting for data from lastValueFrom
      const data = await lastValueFrom(this.httpClient.get<PipelineStage[]>('/api/ats/pipeline')) as PipelineStage[];
      this.pipelineStages.set(data);
      console.log('[ATS] Pipeline loaded from backend.');
    } catch (error) {
      console.error('[ATS] CRITICAL: Failed to load pipeline from backend.', error);
      throw error;
    }
  }

  // --- Stage Management ---
  addStage(title: string): void {
    const newStage: PipelineStage = {
      id: `stage-${Date.now()}`,
      title,
      candidates: [],
    };
    this.pipelineStages.update(stages => [...stages, newStage]);
  }

  editStage(id: string, newTitle: string): void {
    this.pipelineStages.update(stages =>
      stages.map(stage => (stage.id === id ? { ...stage, title: newTitle } : stage))
    );
  }

  deleteStage(id: string): void {
    this.pipelineStages.update(stages => stages.filter(stage => stage.id !== id));
  }

  // --- Candidate Management ---
  addCandidate(name: string, role: string, stageId?: string): void {
    const targetStageId = stageId || this.pipelineStages()[0].id;
    const newCandidate: Candidate = {
      id: `cand-${Date.now()}`,
      name,
      role,
      avatarUrl: `https://picsum.photos/seed/${name.replace(/\s+/g, '')}/100`,
      stageId: targetStageId,
      status: 'applied',
    };

    this.pipelineStages.update(stages =>
      stages.map(stage => {
        if (stage.id === targetStageId) {
          return {
            ...stage,
            candidates: [...stage.candidates, newCandidate]
          };
        }
        return stage;
      })
    );
  }

  editCandidate(id: string, stageId: string, updates: Partial<Candidate>): void {
    this.pipelineStages.update(stages =>
      stages.map(stage => {
        if (stage.id === stageId) {
          return {
            ...stage,
            candidates: stage.candidates.map(c =>
              c.id === id ? { ...c, ...updates } : c
            ),
          };
        }
        return stage;
      })
    );
  }

  moveCandidate(candidateId: string, fromStageId: string, toStageId: string): void {
    if (fromStageId === toStageId) return;

    this.pipelineStages.update(stages => {
      const sourceStage = stages.find(s => s.id === fromStageId);
      const targetStage = stages.find(s => s.id === toStageId);
      
      if (!sourceStage || !targetStage) return stages;

      const candidate = sourceStage.candidates.find(c => c.id === candidateId);
      if (!candidate) return stages;

      const updatedCandidate = { ...candidate, stageId: toStageId };

      return stages.map(stage => {
        if (stage.id === fromStageId) {
          return { ...stage, candidates: stage.candidates.filter(c => c.id !== candidateId) };
        }
        if (stage.id === toStageId) {
          return { ...stage, candidates: [...stage.candidates, updatedCandidate] };
        }
        return stage;
      });
    });
  }
  
  deleteCandidate(id: string, stageId: string): void {
    this.pipelineStages.update(stages =>
      stages.map(stage => {
        if (stage.id === stageId) {
          return {
            ...stage,
            candidates: stage.candidates.filter(c => c.id !== id),
          };
        }
        return stage;
      })
    );
  }
  
  // --- Evaluation & Decision Logic ---
  async updateCandidateEvaluation(candidateId: string, report: EvaluationReport): Promise<void> {
    console.log(`[ATS] Updating evaluation for candidate ${candidateId} with score ${report.overallScore}`);
    
    this.pipelineStages.update(stages => {
      return stages.map(stage => ({
        ...stage,
        candidates: stage.candidates.map(c => {
          if (c.id === candidateId) {
            return { 
                ...c, 
                evaluation: report, 
                status: 'review' as CandidateStatus,
                interviewDate: new Date().toISOString().split('T')[0]
            };
          }
          return c;
        })
      }));
    });
  }
  
  makeDecision(candidateId: string, decision: 'approve' | 'reject'): void {
    const newStatus: CandidateStatus = decision === 'approve' ? 'hired' : 'rejected';
    this.pipelineStages.update(stages => {
      return stages.map(stage => ({
        ...stage,
        candidates: stage.candidates.map(c => 
          c.id === candidateId ? { ...c, status: newStatus } : c
        )
      }));
    });
  }
}
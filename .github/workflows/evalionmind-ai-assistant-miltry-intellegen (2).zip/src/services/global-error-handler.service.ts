
import { Injectable, signal } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

export type NotificationType = 'error' | 'success' | 'info' | 'warning';

export interface Notification {
  id: string;
  type: NotificationType;
  message: string;
}

@Injectable({
  providedIn: 'root',
})
export class GlobalErrorHandlerService {
  // Legacy support for simple error checking
  readonly errorMessage = signal<string | null>(null);
  
  // Modern notification queue
  readonly notifications = signal<Notification[]>([]);

  /**
   * Dispatches a notification to the global toast system.
   * @param type The visual and functional category of the notification.
   * @param message The text content to display.
   * @param duration Time in ms before auto-dismissal. Set to 0 for persistent toasts.
   */
  notify(type: NotificationType, message: string, duration: number = 5000): string {
    const id = Math.random().toString(36).substring(2, 9);
    
    this.notifications.update(current => [...current, { id, type, message }]);
    
    // Sync legacy error signal for components still relying on it
    if (type === 'error') {
      this.errorMessage.set(message);
    }

    if (duration > 0) {
      setTimeout(() => this.clear(id), duration);
    }
    
    return id;
  }

  clear(id: string): void {
    this.notifications.update(current => {
      const filtered = current.filter(n => n.id !== id);
      
      // Clear legacy error signal if no more errors exist in the queue
      if (!filtered.some(n => n.type === 'error')) {
        this.errorMessage.set(null);
      }
      
      return filtered;
    });
  }

  /**
   * Clears the most recent error notification.
   */
  clearError(): void {
    const lastError = [...this.notifications()].reverse().find(n => n.type === 'error');
    if (lastError) {
      this.clear(lastError.id);
    } else {
      this.errorMessage.set(null);
    }
  }

  handleError(error: unknown, context?: string): void {
    const isStringError = typeof error === 'string';
    const message = isStringError ? (error as string) : this.getErrorMessage(error);
    const finalMessage = context ? `[${context}] ${message}` : message;

    const errorDetails: { message: string, originalError: unknown, context?: string, stack?: string } = {
      message: finalMessage,
      originalError: error,
      context,
    };

    if (error instanceof Error && error.stack) {
      errorDetails.stack = error.stack;
    }

    console.error('[GlobalNotificationService]: An error occurred.', errorDetails);
    
    // Push to the new notification system
    this.notify('error', finalMessage);
  }

  private getErrorMessage(error: unknown): string {
    if (error instanceof HttpErrorResponse) {
      const httpError = error as HttpErrorResponse;
      if (httpError.error instanceof ErrorEvent) {
        return `Network Error: ${httpError.error.message}`;
      }
      if (typeof httpError.error === 'string') {
        return `[${httpError.status}] Server: ${httpError.error}`;
      }
      if (typeof httpError.error === 'object' && httpError.error !== null) {
        if ((httpError.error as any).message) {
          return `[${httpError.status}] Server Error: ${(httpError.error as any).message}`;
        }
        return `[${httpError.status}] Server Error: ${JSON.stringify(httpError.error)}`;
      }
      return `[${httpError.status}] Server Communication Error.`;
    }

    if (error instanceof Error) {
      return `System Error: ${error.message}`;
    }
    
    if (typeof error === 'object' && error !== null && (error as any).message) {
      return `Application Error: ${(error as any).message}`;
    }

    return 'An unexpected system error occurred.';
  }
}

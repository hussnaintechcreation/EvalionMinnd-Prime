
import { Injectable, signal, inject, NgZone } from '@angular/core';
import { GeminiService } from './gemini.service';
import { InterviewService } from './interview.service';

export type RecognitionState = 'idle' | 'initializing' | 'listening' | 'stopped' | 'error';

@Injectable({
  providedIn: 'root',
})
export class SpeechRecognitionService {
  private ngZone = inject(NgZone);
  private geminiService = inject(GeminiService);
  private interviewService = inject(InterviewService);

  // --- Public State ---
  state = signal('');
  error = signal<string | null>(null);
  finalTranscript = signal('');
  interimTranscript = signal('');

  // --- Private State ---
  private recognition: any | null = null;
  private finalTranscriptHolder = '';
  private manualStop = false;
  private restartTimer: any = null;

  public initialize(): void {
    // Prevent re-initialization
    if (this.state() !== 'idle' || typeof window === 'undefined') {
        return;
    }

    this.state.set('initializing');

    if (!('webkitSpeechRecognition' in window)) {
      this.handleError('Speech Recognition not supported in this browser.');
      return;
    }

    const SpeechRecognition = (window as any).webkitSpeechRecognition;
    this.recognition = new SpeechRecognition();
    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';

    this.recognition.onstart = () => {
      this.ngZone.run(() => {
        console.log('[SpeechRecognitionService] Service started');
        this.state.set('listening');
        this.error.set(null);
      });
    };

    this.recognition.onresult = (event: any) => {
      this.ngZone.run(async () => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            const rawFinal = event.results[i][0].transcript;
            final += this.postProcessTranscript(rawFinal);
          } else {
            interim += event.results[i][0].transcript; // Keep interim raw for speed
          }
        }
        
        this.interimTranscript.set(this.postProcessTranscript(interim));

        if (final) {
          this.finalTranscriptHolder += (this.finalTranscriptHolder ? ' ' : '') + final;
          this.finalTranscript.set(this.finalTranscriptHolder);
          this.interimTranscript.set(''); 

          const anomaly = await this.geminiService.processLiveTranscript(final);
          if (anomaly) {
            this.interviewService.trackAntiCheatEvent('audio_anomaly');
          }
        }
      });
    };

    this.recognition.onerror = (event: any) => {
      this.ngZone.run(() => {
        if (event.error === 'aborted') {
          console.log('[SpeechRecognitionService] Aborted (benign).');
          return;
        }
        if (event.error === 'not-allowed') {
          this.manualStop = true;
          this.handleError('Microphone permission revoked. Please re-enable to continue.');
          return;
        }
        this.handleError(event.error);
      });
    };

    this.recognition.onend = () => {
      this.ngZone.run(() => {
        console.log('[SpeechRecognitionService] Service ended.');
        if(this.state() !== 'error') {
            this.state.set('stopped');
        }
        
        if (!this.manualStop && this.interviewService.interviewState() === 'in-progress') {
          clearTimeout(this.restartTimer);
          this.restartTimer = setTimeout(() => {
            console.log('[SpeechRecognitionService] Attempting auto-restart...');
            this.start();
          }, 250);
        }
      });
    };

    this.state.set('stopped');
  }

  start(): void {
    if (!this.recognition || this.state() === 'listening') {
      return;
    }
    this.manualStop = false;
    try {
      this.recognition.start();
    } catch (e) {
      console.warn('[SpeechRecognitionService] Start failed (likely already started):', e);
    }
  }

  stop(): void {
    if (!this.recognition) {
      return;
    }
    this.manualStop = true;
    this.recognition.stop();
    clearTimeout(this.restartTimer);
  }
  
  resetTranscript(): void {
      this.finalTranscriptHolder = '';
      this.finalTranscript.set('');
      this.interimTranscript.set('');
  }

  destroy(): void {
    this.stop();
    if(this.recognition) {
        this.recognition.onstart = null;
        this.recognition.onresult = null;
        this.recognition.onerror = null;
        this.recognition.onend = null;
        this.recognition = null;
    }
    this.state.set('idle');
  }

  private handleError(errorMsg: string): void {
    this.state.set('error');
    this.error.set(errorMsg);
    console.error(`[SpeechRecognitionService] Error: ${errorMsg}`);
  }

  private postProcessTranscript(text: string): string {
    let processedText = text.trim();
    if (!processedText) return '';

    const jargonMap: { [key: string]: string } = {
        'angela': 'Angular', 'angularjs': 'AngularJS', 'nest chest': 'NestJS', 'type script': 'TypeScript',
        'react js': 'ReactJS', 'view js': 'Vue.js', 'java script': 'JavaScript', 'graph ql': 'GraphQL',
        'rest api': 'REST API', 'restful api': 'RESTful API', 'web sockets': 'WebSockets', 'ci cd': 'CI/CD',
        'cicd': 'CI/CD', 'sequel': 'SQL', 'my sequel': 'MySQL', 'post grass': 'Postgres', 'no sequel': 'NoSQL',
        'mongo db': 'MongoDB', 'redis': 'Redis', 'docker': 'Docker', 'doctor': 'Docker', 'docker eyes': 'Dockerize',
        'kubernates': 'Kubernetes', 'kubernetees': 'Kubernetes', 'agile scrum': 'Agile Scrum', 'agile': 'Agile',
        'scrum': 'Scrum', 'kanban': 'Kanban', 'aws': 'AWS', 'azure': 'Azure', 'gcp': 'GCP', 'lambda': 'Lambda',
        'ec2': 'EC2', 's3': 'S3', 'server less': 'serverless', 'micro services': 'microservices',
        'mono repo': 'monorepo', 'get hub': 'GitHub', 'git lab': 'GitLab', 'bit bucket': 'Bitbucket',
        'jazz on': 'JSON', 'jot': 'JWT', 'oath': 'OAuth', 'node js': 'Node.js', 'html': 'HTML',
        'css': 'CSS', 'http': 'HTTP', 's d l c': 'SDLC', 's q l': 'SQL', 'api': 'API',
        'ui ux': 'UI/UX', 'dev ops': 'DevOps', 'git': 'Git', 'jira': 'Jira', 'vs code': 'VS Code',
        'visual studio': 'Visual Studio', 'intelli j': 'IntelliJ', 'ide': 'IDE', 'front end': 'frontend',
        'back end': 'backend', 'full stack': 'full-stack', 'end to end': 'end-to-end', 'framework': 'framework',
        'library': 'library', 'database': 'database', 'algorithm': 'algorithm', 'data structure': 'data structure'
    };
    for (const key in jargonMap) {
        const regex = new RegExp(`\\b${key}\\b`, 'gi');
        processedText = processedText.replace(regex, jargonMap[key]);
    }

    processedText = processedText.replace(/\s+([.,?!:;])/g, '$1');
    processedText = processedText.replace(/([.,?!:;])(?=\S)/g, '$1 ');
    
    if (processedText.length > 0 && this.finalTranscriptHolder.endsWith('. ')) {
        processedText = processedText.charAt(0).toUpperCase() + processedText.slice(1);
    } else if (this.finalTranscriptHolder.length === 0) {
        processedText = processedText.charAt(0).toUpperCase() + processedText.slice(1);
    }
    
    processedText = processedText.replace(/\bi\b/g, 'I');
    processedText = processedText.replace(/\s{2,}/g, ' ').trim();

    return processedText;
  }
}
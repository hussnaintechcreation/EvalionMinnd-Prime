
import { Directive, inject, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { FeatureFlagService, FeatureFlags } from '../services/feature-flag.service';

@Directive({
  selector: '[appIfFeature]',
  // Removed 'standalone: true' as it's the default in Angular v20+
})
export class IfFeatureDirective {
  private featureFlagService = inject(FeatureFlagService);
  private templateRef = inject(TemplateRef);
  private viewContainer = inject(ViewContainerRef);
  private hasView = false;

  @Input() set appIfFeature(key: keyof FeatureFlags) {
    const isEnabled = this.featureFlagService.isEnabled(key);
    
    if (isEnabled && !this.hasView) {
      this.viewContainer.createEmbeddedView(this.templateRef);
      this.hasView = true;
    } else if (!isEnabled && this.hasView) {
      this.viewContainer.clear();
      this.hasView = false;
    }
  }
}
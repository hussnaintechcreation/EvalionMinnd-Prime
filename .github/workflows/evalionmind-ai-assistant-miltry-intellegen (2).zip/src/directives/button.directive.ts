
import { Directive, ElementRef, Input, OnInit, Renderer2 } from '@angular/core';

type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost' | 'cyber';

@Directive({
  selector: '[appBtn]',
  // Removed 'standalone: true' as it's the default in Angular v20+
})
export class ButtonDirective implements OnInit {
  @Input('appBtn') variant: ButtonVariant = 'primary';
  
  private baseClasses = 'relative overflow-hidden px-6 py-2 font-bold text-sm uppercase tracking-widest transition-all duration-300 ease-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black hover:-translate-y-0.5 active:translate-y-0 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none';
  
  private variantClasses: Record<ButtonVariant, string> = {
    primary: 'bg-teal-600 text-black font-extrabold border-2 border-teal-400 hover:bg-teal-500 hover:border-teal-200 hover:shadow-[0_0_25px_rgba(20,184,166,0.7),_inset_0_0_10px_rgba(200,255,250,0.3)] focus:ring-teal-400 clip-path-slant',
    cyber: 'bg-black/50 text-teal-400 border-2 border-teal-500 hover:bg-teal-500 hover:text-black hover:shadow-[0_0_25px_rgba(20,184,166,0.7)] focus:ring-teal-400 clip-path-slant',
    secondary: 'bg-black/50 text-gray-300 border border-gray-600 hover:border-green-500 hover:text-green-500 hover:bg-gray-900 focus:ring-green-500',
    danger: 'bg-gray-900 text-gray-400 border border-gray-700 hover:bg-red-900/20 hover:text-red-500 hover:border-red-900 focus:ring-red-500 shadow-none hover:shadow-[0_0_15px_rgba(239,68,68,0.2)]',
    ghost: 'text-gray-400 hover:text-white underline font-mono text-sm uppercase hover:decoration-green-500'
  };

  constructor(private el: ElementRef, private renderer: Renderer2) {}

  ngOnInit(): void {
    const classes = `${this.baseClasses} ${this.variantClasses[this.variant]}`;
    classes.split(' ').forEach(cls => {
      if(cls) this.renderer.addClass(this.el.nativeElement, cls);
    });
  }
}
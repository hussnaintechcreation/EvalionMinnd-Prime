export interface CertificateData {
  candidateName: string;
  role: string;
  issueDate: string;
  certificateId: string;
  issuingAuthority: string;
  issuingAuthorityTitle: string;
}


export interface InterviewQuestionPerformance {
  questionId: string;
  topic: string;
  confidence: number; // Score from 0 to 100
  accuracy: number;   // Score from 0 to 100
  speed: number;      // Score from 0 to 100
}

export interface CandidateProfile {
  id: string;
  name: string;
  role: string;
  status: string;
  avatarUrl: string;
  performanceMetrics: InterviewQuestionPerformance[];
}


// Unified Typing for structured resume data, ensuring type safety from AI to UI.

export interface ContactInfo {
  name?: string;
  email?: string;
  phone?: string;
  linkedin?: string;
}

export interface WorkExperience {
  jobTitle: string;
  company: string;
  location?: string;
  startDate: string;
  endDate: string;
  responsibilities: string[];
}

export interface Education {
  degree: string;
  institution: string;
  graduationYear: string;
}

export interface Skill {
  name: string;
  category: 'Programming Language' | 'Framework' | 'Tool' | 'Database' | 'Soft Skill' | 'Other';
}

export interface ParsedResume {
  contactInfo: ContactInfo;
  summary: string;
  workExperience: WorkExperience[];
  education: Education[];
  skills: Skill[];
}
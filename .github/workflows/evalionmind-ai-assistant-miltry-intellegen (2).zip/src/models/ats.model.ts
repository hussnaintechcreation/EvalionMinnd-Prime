
import { EvaluationReport } from './evaluation.model';

export type CandidateStatus = 'applied' | 'screening' | 'interviewing' | 'review' | 'offered' | 'hired' | 'rejected';

export interface Candidate {
  id: string;
  name: string;
  role: string;
  avatarUrl: string;
  stageId: string; // Maps to pipeline column
  status: CandidateStatus; // Granular status
  evaluation?: EvaluationReport; // AI Generated Report
  interviewDate?: string;
  rank?: number; // New: Optional rank for auto-ranking
}

export interface PipelineStage {
  id: string;
  title: string;
  candidates: Candidate[];
}
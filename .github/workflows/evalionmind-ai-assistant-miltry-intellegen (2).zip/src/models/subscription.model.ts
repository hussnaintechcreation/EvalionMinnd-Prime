
export interface SubscriptionPlan {
  id: string; // Corresponds to Stripe Price ID
  name: string;
  price: string;
  priceDetails: string;
  features: string[];
  isMostPopular: boolean;
  tierLevel: number; // For easy comparison of plans
}

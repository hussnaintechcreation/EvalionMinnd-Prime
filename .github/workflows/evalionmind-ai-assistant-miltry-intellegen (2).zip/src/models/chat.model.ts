
export type ChatRole = 'user' | 'model' | 'system-info';

export interface ChatMessage {
  role: ChatRole;
  text: string;
}

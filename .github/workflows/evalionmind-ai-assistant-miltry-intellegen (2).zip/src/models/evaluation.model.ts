

// Per-question analysis structure returned by the AI
export interface PerQuestionAnalysis {
  questionId: string;
  questionText: string;
  clarity: number; // 0-100
  relevance: number; // 0-100
  technicalDepth: number; // 0-100
  keywords: string[];
  // Replaced generic feedback with a structured object for more detailed insights.
  detailedFeedback: {
    technicalAccuracy: string;
    communicationClarity: string;
    problemSolvingApproach: string;
    keyStrengths: string[];
    areasForImprovement: string[];
  }
}

// The final, comprehensive report
export interface EvaluationReport {
  overallScore: number;
  summary: string;
  strengths: string[];
  areasForImprovement: string[];
  detailedAnalysis: PerQuestionAnalysis[];
}

// Historical/Average data for a specific role
export interface RoleBenchmark {
  role: string;
  avgOverallScore: number;
  avgClarity: number;
  avgRelevance: number;
  avgTechnicalDepth: number;
  sampleSize: number;
}

// New: Interface for AI-generated candidate ranks
export interface CandidateRank {
  candidateId: string;
  name: string;
  role: string;
  rank: number; // 1 for highest, N for lowest
  justification: string; // AI-generated reason for the rank
}

export interface InterviewQuestion {
  id: string;
  text: string;
  durationSeconds: number; // Time allocated for this question
}

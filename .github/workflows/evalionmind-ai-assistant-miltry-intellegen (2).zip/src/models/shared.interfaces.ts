// Unified Typing for Zero-Error Protocol

export type UserRole = 'admin' | 'company' | 'candidate';

export interface User {
  id: string;
  uniqueId: string; // System Generated Unique ID (e.g., CND-8842)
  email: string;
  name: string;
  role: UserRole;
  avatarUrl?: string; // Logo for company, Photo for candidate
  
  // Company Specific
  licenseNo?: string;

  // Candidate Specific
  contactNumber?: string;
  cnic?: string;
}

export interface AuthTokenPayload {
  sub: string;
  email: string;
  role: UserRole;
  exp: number;
  iat: number;
}

// WebSocket Events
export enum WsEvents {
  JOIN_ROOM = 'join_room',
  LEAVE_ROOM = 'leave_room',
  SIGNAL = 'signal',
  ANTI_CHEAT_LOG = 'anti_cheat_log',
  TRANSCRIPT_PART = 'transcript_part',
}

export interface SignalingPayload {
  target: string;
  type: 'offer' | 'answer' | 'candidate';
  sdp?: any;
  candidate?: any;
}

export interface AntiCheatPayload {
  sessionId: string;
  // FIX: Added 'audio_anomaly' to the type to allow for audio-based proctoring events.
  type: 'blur' | 'focus' | 'tab_hidden' | 'fullscreen_exit' | 'multiple_faces' | 'audio_anomaly';
  timestamp: number;
  confidence?: number;
  chatSessionId?: string; // Added for context in anti-cheat logging
}
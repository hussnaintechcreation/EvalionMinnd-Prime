
import { HttpInterceptorFn, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { of, timer, throwError } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { User, UserRole } from '../models/shared.interfaces';
import { Candidate, PipelineStage } from '../models/ats.model';
import { CandidateApplication } from '../services/candidate.service';

// --- IN-MEMORY MOCK DATABASE ---
let users: User[] = [];
let pipelineStagesData: PipelineStage[] = [
  {
    id: 'applied',
    title: 'Applied',
    candidates: [
      { id: 'cand-1', name: 'Alice Johnson', role: 'Frontend Developer', avatarUrl: 'https://picsum.photos/seed/cand-1/100', stageId: 'applied', status: 'applied' },
      { id: 'cand-2', name: 'Bob Williams', role: 'Backend Developer', avatarUrl: 'https://picsum.photos/seed/cand-2/100', stageId: 'applied', status: 'applied' },
    ],
  },
  {
    id: 'screening',
    title: 'Screening',
    candidates: [
      { id: 'cand-3', name: 'Charlie Brown', role: 'UI/UX Designer', avatarUrl: 'https://picsum.photos/seed/cand-3/100', stageId: 'screening', status: 'screening' },
    ],
  },
  {
    id: 'interview',
    title: 'Interview',
    candidates: [
      { id: 'cand-4', name: 'Diana Miller', role: 'Frontend Developer', avatarUrl: 'https://picsum.photos/seed/cand-4/100', stageId: 'interview', status: 'interviewing' },
      { id: 'cand-5', name: 'Ethan Davis', role: 'Product Manager', avatarUrl: 'https://picsum.photos/seed/cand-5/100', stageId: 'interview', status: 'interviewing' },
    ],
  },
  {
    id: 'review',
    title: 'Under Review',
    candidates: [
       { 
           id: 'cand-review-1', 
           name: 'Sarah Connor', 
           role: 'Security Engineer', 
           avatarUrl: 'https://picsum.photos/seed/sarah/100', 
           stageId: 'review', 
           status: 'review',
           interviewDate: '2024-05-20',
           evaluation: {
               overallScore: 88,
               summary: 'Candidate demonstrated exceptional knowledge of cybersecurity protocols.',
               strengths: ['Network Security', 'Threat Analysis'],
               areasForImprovement: ['Frontend Security'],
               detailedAnalysis: []
           }
       }
    ],
  },
  {
    id: 'hired',
    title: 'Hired',
    candidates: [
      { id: 'cand-8', name: 'Hannah Clark', role: 'Product Manager', avatarUrl: 'https://picsum.photos/seed/cand-8/100', stageId: 'hired', status: 'hired' },
    ],
  },
];
let candidateApplicationsData: CandidateApplication[] = [
  {
    role: 'Senior Full-Stack Engineer',
    status: 'pending_interview',
    date: '2024-05-24',
    score: null
  },
  {
    role: 'AI Systems Architect',
    status: 'approved',
    date: '2024-04-10',
    score: 94
  }
];

export const mockBackendInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.startsWith('/api/')) {
    return next(req);
  }

  const { url, method, body } = req;

  const ok = (responseBody?: any) => {
    console.log(`[Mock Backend] Responding with 200 OK for ${method} ${url}`, responseBody);
    return of(new HttpResponse({ status: 200, body: responseBody }));
  };
  const created = (responseBody?: any) => {
    console.log(`[Mock Backend] Responding with 201 CREATED for ${method} ${url}`, responseBody);
    return of(new HttpResponse({ status: 201, body: responseBody }));
  };
  const error = (status: number, message: string) => {
    console.error(`[Mock Backend] Responding with ${status} ERROR for ${method} ${url}: ${message}`);
    return throwError(() => new HttpErrorResponse({ status, error: { message }, statusText: message }));
  };

  function handleRoute() {
    // --- AUTH ---
    if (url.endsWith('/api/auth/signup') && method === 'POST') {
      const { email, name, role, ...rest } = body as any;
      if (users.find(u => u.email === email)) {
        return error(409, 'User with this email already exists.');
      }
      const newUser: User = {
        id: `user-${Date.now()}`,
        uniqueId: `${role === 'company' ? 'CMP' : 'CND'}-${Math.floor(Math.random() * 9000) + 1000}`,
        email,
        name,
        role,
        avatarUrl: (rest as any).avatarUrl || 'https://api.dicebear.com/7.x/initials/svg?seed=' + name,
        ...rest,
      };
      users.push(newUser);
      const tokenPayload = { sub: newUser.id, email: newUser.email, role: newUser.role, exp: (Date.now() / 1000) + 3600 };
      const token = `mock.${btoa(JSON.stringify(tokenPayload))}.mock`;
      const response = { user: newUser, token };
      console.log('[Mock Backend] Signup successful, responding with:', response);
      return created(response);
    }

    if (url.endsWith('/api/auth/login') && method === 'POST') {
      const { email, role } = body as any;
      let user = users.find(u => u.email === email);
      if (!user) {
        // If user doesn't exist on login, create them for this demo app's flow
        user = {
            id: `user-${Date.now()}`,
            uniqueId: `${role === 'company' ? 'CMP' : 'CND'}-${Math.floor(Math.random() * 9000) + 1000}`,
            email,
            name: role === 'company' ? 'Mock Company' : 'Mock Candidate',
            role: role || 'candidate',
            avatarUrl: 'https://api.dicebear.com/7.x/initials/svg?seed=Mock',
        };
        users.push(user);
      }
      const tokenPayload = { sub: user.id, email: user.email, role: user.role, exp: (Date.now() / 1000) + 3600 };
      const token = `mock.${btoa(JSON.stringify(tokenPayload))}.mock`;
      const response = { user: user, token };
      console.log('[Mock Backend] Login successful, responding with:', response);
      return ok(response);
    }
    
    // --- ATS ---
    if (url.endsWith('/api/ats/pipeline') && method === 'GET') {
      return ok(pipelineStagesData);
    }

    // --- CANDIDATE ---
    if (url.endsWith('/api/candidate/applications') && method === 'GET') {
      return ok(candidateApplicationsData);
    }
    
    // --- GENAI ---
    if (url.endsWith('/api/genai/chat/start') && method === 'POST') {
        return ok({ chatSessionId: `chat-${Date.now()}-${Math.random().toString(36).substring(2, 9)}` });
    }
    
    if (url.endsWith('/api/genai/deep-thought') && method === 'POST') {
      const { prompt } = body as any;
      const deepThoughtResponse = `After extensive analysis of your query regarding "${prompt}", the AI core concludes that the optimal strategic vector involves a multi-faceted approach, considering both temporal and resource-based constraints. The primary bottleneck is likely the quantum entanglement phase, which can be mitigated by recalibrating the neural network's predictive algorithms. A full dossier will be compiled and sent to your secure inbox.`;
      // Simulate a longer delay for "deep thought" to improve UX
      return timer(2500).pipe(
        switchMap(() => ok({ responseText: deepThoughtResponse }))
      );
    }

    if (url.endsWith('/api/genai/structured-json') && method === 'POST') {
        const promptBody = (body as any)?.prompt || '';
        if (promptBody.includes('rank the provided candidates')) {
             const candidateLines = promptBody.match(/Candidate ID: (cand-\S+)/g) || [];
             const candidateIds = candidateLines.map((line: string) => line.split(': ')[1]);
             const allCandidates = pipelineStagesData.flatMap(s => s.candidates);
             
             const candidatesToRank = candidateIds.map(id => allCandidates.find(c => c.id === id)).filter(Boolean) as Candidate[];

            const rankedCandidates = candidatesToRank.map((c, index) => ({
                candidateId: c!.id,
                name: c!.name,
                role: c!.role,
                rank: index + 1,
                justification: `AI analysis places ${c!.name} at this rank due to strong alignment with key requirements and demonstrated skills.`
            })).sort(() => Math.random() - 0.5); // Randomize for mock effect

            rankedCandidates.forEach((c, index) => c.rank = index + 1);
            return ok(rankedCandidates);
        }
        return ok({ message: "Mocked structured JSON response." });
    }

    // --- DIAGNOSTICS ---
    if (url.startsWith('/api/diagnostics/check/') && method === 'GET') {
      const id = url.split('/').pop();
      const status = (id === 'ws_vuln' && Math.random() > 0.9) ? 'fail' : 'success';
      return ok({ status });
    }

    // Default fallback
    console.warn(`[Mock Backend] Unhandled API route: ${method} ${url}`);
    return error(404, `Mock API endpoint not found: ${method} ${url}`);
  }

  // Most routes are synchronous for speed, but specific endpoints (e.g., deep-thought) may introduce delays for UX simulation.
  return handleRoute();
};

// Static getters for initial data loading by APP_INITIALIZER
export const mockInitialData = {
  get initialPipelineStages(): PipelineStage[] {
    return pipelineStagesData;
  },
  get initialCandidateApplications(): CandidateApplication[] {
    return candidateApplicationsData;
  }
};
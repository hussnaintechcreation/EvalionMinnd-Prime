
import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject, Injector } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { GlobalErrorHandlerService } from '../services/global-error-handler.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const injector = inject(Injector);
  const errorHandlerService = inject(GlobalErrorHandlerService);
  const token = localStorage.getItem('evalion_token');

  // Clone request to add Authorization header (simulating standard JWT flow)
  // Note: If using HttpOnly cookies, the browser handles this automatically, 
  // but for this "Elite" architecture, we support both patterns.
  let authReq = req;
  if (token) {
    authReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  return next(authReq).pipe(
    catchError((error: HttpErrorResponse) => {
      // Lazily inject AuthService here to break the circular dependency:
      // APP_INITIALIZER -> AtsService -> HttpClient -> authInterceptor -> AuthService -> HttpClient
      const authService = injector.get(AuthService);

      if (error.status === 401) {
        console.warn('[Auth Interceptor] 401 Unauthorized detected. Terminating session.');
        authService.logout();
      } else if (error.status >= 500 || error.status === 0) {
        // Handle unexpected server errors (5xx) or network errors (status 0) globally.
        errorHandlerService.handleError(error);
      }
      
      // For other errors (like 4xx validation errors), just re-throw them 
      // to be handled by the service/component that made the call.
      return throwError(() => error);
    })
  );
};
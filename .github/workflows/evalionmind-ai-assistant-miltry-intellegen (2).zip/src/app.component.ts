
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { UiService } from './services/ui.service';

import { AboutComponent } from './components/about/about.component';
import { BackgroundComponent } from './components/background/background.component';
import { ErrorToastComponent } from './components/ui/error-toast/error-toast.component';
import { GlobalErrorHandlerService } from './services/global-error-handler.service';
import { LoginComponent } from './components/login/login.component';

@Component({
  selector: 'app-root',
  // Removed 'standalone: true' as it's the default in Angular v20+
  template: `
    <!-- Global 3D Background -->
    <app-background></app-background>

    <!-- Main Content Area - Z-index ensures it sits above the background -->
    <main class="relative z-10 flex flex-col min-h-screen text-[var(--text)] selection:bg-[var(--primary-accent)] selection:text-black">
      <!-- The Router Outlet is now the single source of truth for what is displayed -->
      <router-outlet></router-outlet>

      @if (uiService.isAboutModalOpen()) {
        <app-about></app-about>
      }

      @if (uiService.isLoginModalOpen()) {
        <app-login (closeLogin)="uiService.closeLogin()"></app-login>
      }
    </main>

    <!-- Global Error Toast sits on top of everything -->
    <app-error-toast></app-error-toast>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    RouterModule,
    AboutComponent,
    BackgroundComponent,
    ErrorToastComponent,
    LoginComponent,
  ]
})
export class AppComponent {
  uiService = inject(UiService);
  errorHandler = inject(GlobalErrorHandlerService);

  constructor() {
    window.addEventListener('unhandledrejection', event => {
        console.warn('UNHANDLED PROMISE REJECTION DETECTED');
        this.errorHandler.handleError(event.reason);
    });
  }
}

import '@angular/compiler';
import { bootstrapApplication } from '@angular/platform-browser';
// Fix: provideExperimentalZonelessChangeDetection is renamed to provideZonelessChangeDetection in latest Angular
import { ErrorHandler, APP_INITIALIZER, provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideRouter, withHashLocation } from '@angular/router';
import { AppComponent } from './src/app.component';
import { authInterceptor } from './src/interceptors/auth.interceptor';
import { mockBackendInterceptor, mockInitialData } from './src/interceptors/mock-backend.interceptor';
import { routes } from './src/app.routes';
import { CustomErrorHandler } from './src/handlers/custom-error-handler';
import { AtsService } from './src/services/ats.service';
import { CandidateService } from './src/services/candidate.service';

const appInitializerFactory = (atsService: AtsService, candidateService: CandidateService) => {
  return () => {
    const initialPipeline = mockInitialData.initialPipelineStages;
    const initialApplications = mockInitialData.initialCandidateApplications;
    atsService.initializeData(initialPipeline);
    candidateService.initializeData(initialApplications);
    return Promise.resolve();
  };
};

bootstrapApplication(AppComponent, {
  providers: [
    // Fix: updated to non-experimental zoneless change detection
    provideZonelessChangeDetection(),
    provideHttpClient(withInterceptors([mockBackendInterceptor, authInterceptor])),
    provideRouter(routes, withHashLocation()),
    { provide: ErrorHandler, useClass: CustomErrorHandler },
    {
      provide: APP_INITIALIZER,
      useFactory: appInitializerFactory,
      deps: [AtsService, CandidateService],
      multi: true,
    }
  ],
}).catch((err) => console.error(err));
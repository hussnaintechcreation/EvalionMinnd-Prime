
import { Routes } from '@angular/router';
import { LandingComponent } from './components/landing/landing.component';
import { ProfileComponent } from './components/profile/profile.component';
import { LandingLayoutComponent } from './components/landing-layout/landing-layout.component';
import { authGuard } from './guards/auth.guard';
import { roleGuard } from './guards/role.guard';

// New Layout Components
import { CompanyLayoutComponent } from './components/company-layout/company-layout.component';
import { CandidateLayoutComponent } from './components/candidate-dashboard-view/candidate-dashboard-view.component';

// Company-specific routed components
import { CompanyDashboardComponent } from './components/company-dashboard/company-dashboard.component';
import { AtsComponent } from './components/ats/ats.component';
import { AssessmentsComponent } from './components/assessments/assessments.component';
import { CandidateRankingComponent } from './components/candidate-ranking/candidate-ranking.component';
import { SystemHealthComponent } from './components/system-health/system-health.component';
import { SystemDiagnoseComponent } from './components/system-diagnose/system-diagnose.component';
import { GenerativeToolkitComponent } from './components/generative-toolkit/generative-toolkit.component';
import { BillingComponent } from './components/billing/billing.component';
import { SettingsComponent } from './components/settings/settings.component';

// Candidate-specific routed components
import { CandidateDashboardComponent } from './components/candidate-dashboard/candidate-dashboard.component';
import { InterviewRoomComponent } from './components/interview-room/interview-room.component';
import { CertificateComponent } from './components/certificate/certificate.component';


export const routes: Routes = [
    // Authenticated Company Routes with a dedicated layout
    { 
        path: 'company', 
        component: CompanyLayoutComponent,
        canActivate: [authGuard, roleGuard], 
        data: { roles: ['company'] },
        children: [
            { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
            { path: 'dashboard', component: CompanyDashboardComponent },
            { path: 'operations', component: AtsComponent },
            { path: 'assessments', component: AssessmentsComponent },
            { path: 'ranking', component: CandidateRankingComponent },
            { path: 'system-health', component: SystemHealthComponent },
            { path: 'diagnostics', component: SystemDiagnoseComponent },
            { path: 'generative-toolkit', component: GenerativeToolkitComponent },
            { path: 'armory', component: BillingComponent },
            { path: 'profile', component: ProfileComponent },
            { path: 'settings', component: SettingsComponent },
        ]
    },
    // Authenticated Candidate Routes with a dedicated layout
    { 
        path: 'candidate', 
        component: CandidateLayoutComponent,
        canActivate: [authGuard, roleGuard], 
        data: { roles: ['candidate'] },
        children: [
            { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
            { path: 'dashboard', component: CandidateDashboardComponent },
            { path: 'interview', component: InterviewRoomComponent },
            { path: 'certificate', component: CertificateComponent },
            { path: 'profile', component: ProfileComponent },
            { path: 'settings', component: SettingsComponent },
        ]
    },
    
    // Public-facing routes nested under the main landing layout
    {
        path: '',
        component: LandingLayoutComponent,
        children: [
            { path: '', component: LandingComponent, pathMatch: 'full' },
        ]
    },
    
    // Fallback route redirects to the home page
    { path: '**', redirectTo: '' }
];
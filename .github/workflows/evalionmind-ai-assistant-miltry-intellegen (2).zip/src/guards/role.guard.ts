
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { UserRole } from '../models/shared.interfaces';

export const roleGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router: Router = inject(Router);

  const expectedRoles: UserRole[] = route.data['roles'] || [];
  const currentUserRole = authService.currentUserRole();

  if (!authService.isAuthenticated()) {
    console.warn('[RoleGuard] Access denied. User not authenticated.');
    // In a router-based app: router.navigate(['/login']);
    // For this applet, the authService state drives the view, but we return false to block navigation.
    return false;
  }

  if (currentUserRole && expectedRoles.includes(currentUserRole)) {
    return true;
  }

  console.warn(`[RoleGuard] Access denied. Role '${currentUserRole}' does not match expected: ${expectedRoles.join(', ')}`);
  // router.navigate(['/unauthorized']);
  return false;
};
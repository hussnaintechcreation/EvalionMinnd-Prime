
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  // FIX: Explicitly type the injected Router to resolve 'unknown' type error.
  const router: Router = inject(Router);

  if (authService.isAuthenticated()) {
    return true;
  }

  // Redirect to the landing page if not authenticated
  console.warn('[AuthGuard] Access denied. User not authenticated. Redirecting to home.');
  return router.parseUrl('/');
};

import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VideoGeneratorComponent } from '../video-generator/video-generator.component';
import { ResumeParserComponent } from '../resume-parser/resume-parser.component';

@Component({
  selector: 'app-generative-toolkit',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, VideoGeneratorComponent, ResumeParserComponent],
  templateUrl: './generative-toolkit.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GenerativeToolkitComponent {}
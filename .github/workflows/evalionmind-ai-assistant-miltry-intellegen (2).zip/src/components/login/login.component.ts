
import { Component, ChangeDetectionStrategy, inject, output, signal, input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService, RegistrationData } from '../../services/auth.service';
import { UserRole } from '../../models/shared.interfaces';
import { UiService } from '../../services/ui.service';

@Component({
  selector: 'app-login',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent implements OnInit {
  authService = inject(AuthService);
  uiService = inject(UiService);
  closeLogin = output<void>();

  mode = signal<'login' | 'signup'>('login');
  selectedRole = signal<UserRole>('candidate'); // Default role
  isLoading = signal(false);
  errorMessage = signal<string | null>(null);

  // Common Fields
  email = signal('');
  
  // Company Specific
  companyName = signal('');
  licenseNo = signal('');
  companyLogo = signal<string>('');

  // Candidate Specific
  candidateName = signal('');
  contactNumber = signal('');
  cnic = signal('');
  personalPhoto = signal<string>('');
  
  ngOnInit(): void {
    const preselected = this.uiService.preselectedRole();
    if (preselected) {
      this.selectedRole.set(preselected);
    }
  }

  toggleMode() {
      this.mode.update(m => m === 'login' ? 'signup' : 'login');
      this.errorMessage.set(null);
  }

  selectRole(role: UserRole) {
      this.selectedRole.set(role);
      this.errorMessage.set(null);
  }

  onFileSelected(event: Event, type: 'logo' | 'photo') {
      const input = event.target as HTMLInputElement;
      if (input.files && input.files[0]) {
          const reader = new FileReader();
          reader.onload = (e: any) => {
              if (type === 'logo') this.companyLogo.set(e.target.result);
              else this.personalPhoto.set(e.target.result);
          };
          reader.readAsDataURL(input.files[0]);
      }
  }

  async processAuth(): Promise<void> {
    if (this.isLoading()) return;
    
    this.isLoading.set(true);
    this.errorMessage.set(null);

    const role = this.selectedRole();
    const isSignup = this.mode() === 'signup';

    // --- Enhanced Validation ---
    if (!this.email() || !/\S+@\S+\.\S+/.test(this.email())) {
        this.handleError('A valid email address is required for the uplink.');
        return;
    }

    if (isSignup) {
        if (role === 'company' && (!this.companyName() || !this.licenseNo())) {
            this.handleError('Company Name and License No. are required for registration.');
            return;
        }
        if (role === 'candidate' && (!this.candidateName() || !this.contactNumber() || !this.cnic())) {
            this.handleError('Full Name, Contact No., and Identity ID are required for registration.');
            return;
        }
    }
    // --- End Validation ---

    const payload: RegistrationData = {
        email: this.email(),
        name: role === 'company' ? this.companyName() : this.candidateName(),
        avatarUrl: role === 'company' ? this.companyLogo() : this.personalPhoto(),
        licenseNo: this.licenseNo(),
        contactNumber: this.contactNumber(),
        cnic: this.cnic()
    };
    
    // In login mode, if the name isn't provided (which it won't be), we create a mock one.
    // A real backend would find the user by email.
    if (!isSignup && !payload.name) {
        payload.name = role === 'company' ? 'Recruiter Operative' : 'Candidate Operative';
    }

    try {
      // Pass the isSignup flag to the service for simulated backend logic
      await this.authService.loginOrSignup(payload, role, isSignup);
      // On success, the service handles navigation and the modal will close via an effect in LandingLayoutComponent.
    } catch (error: any) {
      console.error('[LoginComponent] Auth Error:', error);
      const errorMessageText = error.message || 'An unknown authentication error occurred.';
      if (errorMessageText.includes('User with this email already exists')) {
          this.handleError('Operative with this email is already registered. Switched to login mode.');
          this.mode.set('login'); // Automatically switch to login mode for better UX
      } else {
          this.handleError(errorMessageText);
      }
    } finally { // Ensure isLoading is reset even if an error occurs and is caught.
        this.isLoading.set(false);
    }
  }
  
  private handleError(msg: string) {
      this.errorMessage.set(msg);
      this.isLoading.set(false);
  }
}
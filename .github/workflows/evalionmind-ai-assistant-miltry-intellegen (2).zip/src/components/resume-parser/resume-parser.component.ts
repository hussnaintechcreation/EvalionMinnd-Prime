
import { Component, ChangeDetectionStrategy, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';
import { ButtonDirective } from '../../directives/button.directive';
import { ParsedResume } from '../../models/resume.model';

@Component({
  selector: 'app-resume-parser',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, FormsModule, ButtonDirective],
  templateUrl: './resume-parser.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ResumeParserComponent {
  geminiService = inject(GeminiService);

  resumeText = signal('');
  isLoading = signal(false);
  parsedResume = signal<ParsedResume | null>(null);
  error = signal<string | null>(null);

  async parseResume(): Promise<void> {
    if (!this.resumeText().trim() || this.isLoading()) {
      return;
    }

    this.isLoading.set(true);
    this.parsedResume.set(null);
    this.error.set(null);

    try {
      const result = await this.geminiService.parseResume(this.resumeText());
      if (result) {
        this.parsedResume.set(result);
      } else {
        this.error.set(this.geminiService.error() || 'Failed to parse resume. The structure might be unconventional.');
      }
    } catch (e: any) {
      this.error.set(e.message || 'An unexpected error occurred during parsing.');
    } finally {
      this.isLoading.set(false);
    }
  }

  onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.resumeText.set(e.target.result);
      };
      reader.readAsText(file);
    }
  }

  reset(): void {
    this.resumeText.set('');
    this.parsedResume.set(null);
    this.error.set(null);
    this.isLoading.set(false);
  }
}
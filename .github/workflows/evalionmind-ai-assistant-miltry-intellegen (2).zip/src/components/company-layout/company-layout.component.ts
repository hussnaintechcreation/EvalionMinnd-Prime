
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { ChatbotComponent } from '../chatbot/chatbot.component';
import { AuthService } from '../../services/auth.service';
import { FeatureFlagService } from '../../services/feature-flag.service';

@Component({
  selector: 'app-company-layout',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [
    CommonModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    HeaderComponent,
    ChatbotComponent,
  ],
  templateUrl: './company-layout.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CompanyLayoutComponent {
  authService = inject(AuthService);
  featureFlagService = inject(FeatureFlagService);
  // FIX: Explicitly type injected Router to resolve 'unknown' type error.
  router: Router = inject(Router);

  handleGoToProfile(): void {
    this.router.navigate(['/company/profile']);
  }
  
  handleGoToSettings(): void {
    this.router.navigate(['/company/settings']);
  }
}
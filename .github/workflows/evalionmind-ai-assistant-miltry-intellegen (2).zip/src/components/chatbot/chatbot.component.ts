
import { Component, ChangeDetectionStrategy, signal, inject, OnInit, WritableSignal, effect, viewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';
import { ChatMessage } from '../../models/chat.model';
import { LogoComponent } from '../ui/logo.component';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser'; // Import DomSanitizer and SafeHtml

const CHAT_HISTORY_KEY = 'evalion_chat_history';

@Component({
  selector: 'app-chatbot',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, FormsModule, LogoComponent],
  templateUrl: './chatbot.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChatbotComponent implements OnInit {
  // FIX: Converted to viewChild signal for declarative DOM access
  messageContainer = viewChild<ElementRef<HTMLDivElement>>('messageContainer');

  geminiService = inject(GeminiService);
  private sanitizer: DomSanitizer = inject(DomSanitizer); // FIX: Explicitly typed DomSanitizer

  messages: WritableSignal<ChatMessage[]> = signal([]);
  userInput = signal('');
  isLoading = signal(false);
  isRecording = signal(false);
  useDeepThought = signal(false);
  isOpen = signal(false);

  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];

  constructor() {
    effect(() => {
        const error = this.geminiService.error();
        if (error) {
            this.messages.update(msgs => [...msgs, { role: 'system-info', text: `Error: ${error}` }]);
        }
    });

    effect(() => {
        // Only scroll if chat is open and there are messages
        if(this.messages().length > 0 && this.isOpen()) {
            // Defer scroll to ensure DOM is updated
            setTimeout(() => this.scrollToBottom(), 0);
        }
    });

    // Auto-save chat history to localStorage
    effect(() => {
        const msgs = this.messages();
        if (msgs.length > 1) { // Don't save if only initial greeting
             try {
                localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(msgs));
             } catch (e) {
                console.error('[Chatbot] Failed to save chat history to localStorage:', e);
             }
        }
    });
  }

  async ngOnInit(): Promise<void> { // Made ngOnInit async
    let savedChat: ChatMessage[] | null = null;
    try {
        const item = localStorage.getItem(CHAT_HISTORY_KEY);
        savedChat = item ? JSON.parse(item) : null;
    } catch (e) {
        console.error('[Chatbot] Failed to load chat history from localStorage:', e);
    }
    
    if (savedChat && savedChat.length > 0) {
        this.messages.set(savedChat);
    } else {
        await this.geminiService.startChat(); // Await chat session start
        if (!this.geminiService.error()) {
          this.messages.set([{ role: 'model', text: "Greetings. I am the Evalion Assistant. How can I facilitate your hiring operations today?" }]);
        }
    }
  }

  toggleChat(): void {
    this.isOpen.update(open => !open);
  }

  async sendMessage(): Promise<void> {
    const messageText = this.userInput().trim();
    if (!messageText || this.isLoading()) return;

    this.messages.update(msgs => [...msgs, { role: 'user', text: messageText }]);
    this.userInput.set('');
    this.isLoading.set(true);
    this.scrollToBottom();

    if (this.useDeepThought()) {
      const response = await this.geminiService.generateWithDeepThought(messageText);
      this.messages.update(msgs => [...msgs, { role: 'model', text: response }]);
      this.isLoading.set(false);
    } else {
      this.messages.update(msgs => [...msgs, { role: 'model', text: '' }]);
      await this.geminiService.sendMessageStream(
        messageText,
        (chunkText) => {
          this.messages.update(currentMessages => {
            const lastMessage = currentMessages[currentMessages.length - 1];
            if (lastMessage && lastMessage.role === 'model') {
              const newMessages = [...currentMessages];
              newMessages[newMessages.length - 1] = {
                ...lastMessage,
                text: lastMessage.text + chunkText,
              };
              return newMessages;
            }
            return currentMessages;
          });
          this.scrollToBottom();
        },
        () => {
          this.isLoading.set(false);
        }
      );
    }
  }

  async toggleRecording(): Promise<void> {
    if (this.isRecording()) {
      this.stopRecording();
    } else {
      await this.startRecording();
    }
  }

  private async startRecording(): Promise<void> {
    try {
      // Ensure we don't hold the mic from previous sessions
      this.stopRecording(); 

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.isRecording.set(true);
      this.audioChunks = [];
      const options = { mimeType: 'audio/webm' };
      this.mediaRecorder = new MediaRecorder(stream, options);

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
           this.audioChunks.push(event.data);
        }
      };

      this.mediaRecorder.onstop = async () => {
        // cleanup tracks immediately
        stream.getTracks().forEach(track => track.stop());
        
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
        if (audioBlob.size > 0) {
            const base64String = await this.blobToBase64(audioBlob);
            this.isLoading.set(true);
            this.messages.update(msgs => [...msgs, { role: 'system-info', text: 'Transcribing audio...' }]);
            
            const transcribedText = await this.geminiService.transcribeAudio(base64String, 'audio/webm');
            this.userInput.set(transcribedText);
            this.messages.update(msgs => msgs.filter(m => m.text !== 'Transcribing audio...'));
            this.isLoading.set(false);
        }
      };

      this.mediaRecorder.start();
    } catch (error) {
      console.error('Error accessing microphone:', error);
      this.messages.update(msgs => [...msgs, { role: 'system-info', text: 'Microphone access denied or unavailable. Please check permissions.' }]);
      this.isRecording.set(false);
    }
  }

  private stopRecording(): void {
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      this.mediaRecorder.stop();
      // Ensure tracks are stopped in onstop handler or here as safety
      if (this.mediaRecorder.stream) {
          this.mediaRecorder.stream.getTracks().forEach(track => track.stop());
      }
    }
    this.isRecording.set(false);
  }

  private blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        const base64String = result.split(',')[1];
        resolve(base64String);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  private scrollToBottom(): void {
    try {
      // Access the nativeElement from the signal
      const container = this.messageContainer();
      if (container) {
          container.nativeElement.scrollTop = container.nativeElement.scrollHeight;
      }
    } catch (err) {}
  }

  // FIX: Added method to safely format message text for innerHTML
  formatMessageText(text: string): SafeHtml {
    const formattedText = text.replace(/\n/g, '<br>');
    return this.sanitizer.bypassSecurityTrustHtml(formattedText);
  }
}
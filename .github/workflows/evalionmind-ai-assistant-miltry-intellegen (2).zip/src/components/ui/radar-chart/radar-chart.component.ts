
import { Component, ChangeDetectionStrategy, Input, OnChanges, SimpleChanges, ElementRef, viewChild, NgZone, afterNextRender } from '@angular/core';
import { CommonModule } from '@angular/common';

declare var d3: any;

export interface RadarChartData {
  label: string;
  candidateScore: number;
  benchmarkScore: number;
}

@Component({
  selector: 'app-radar-chart',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule],
  templateUrl: './radar-chart.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RadarChartComponent implements OnChanges {
  @Input({ required: true }) data: RadarChartData[] = [];
  chartContainer = viewChild<ElementRef<HTMLDivElement>>('chartContainer');

  constructor(private ngZone: NgZone) {
    afterNextRender(() => {
      this.drawChart();
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['data'] && this.data.length > 0 && this.chartContainer()) {
      this.drawChart();
    }
  }

  private drawChart(): void {
    if (!this.data || this.data.length === 0 || !this.chartContainer()) {
      return;
    }

    this.ngZone.runOutsideAngular(() => {
      const element = this.chartContainer()!.nativeElement;
      d3.select(element).select('svg').remove(); // Clear previous chart

      const margin = { top: 60, right: 60, bottom: 60, left: 60 };
      const width = element.offsetWidth - margin.left - margin.right;
      const height = 300 - margin.top - margin.bottom; // Fixed height for consistency
      const radius = Math.min(width, height) / 2;

      const svg = d3.select(element)
        .append('svg')
        .attr('width', width + margin.left + margin.right)
        .attr('height', height + margin.top + margin.bottom)
        .append('g')
        .attr('transform', `translate(${width / 2 + margin.left}, ${height / 2 + margin.top})`);

      const axes = this.data.map(d => d.label);
      const numAxes = axes.length;
      const angleSlice = (Math.PI * 2) / numAxes;

      const rScale = d3.scaleLinear().range([0, radius]).domain([0, 100]);

      // Draw grid lines
      const grid = svg.append('g').attr('class', 'grid');
      grid.selectAll('.levels')
        .data(d3.range(1, 5).reverse())
        .enter()
        .append('circle')
        .attr('r', (d: number) => (radius / 4) * d)
        .style('fill', '#1f2937')
        .style('stroke', '#374151')
        .style('fill-opacity', 0.5);
      
      // Draw axes
      const axis = svg.selectAll('.axis')
        .data(axes)
        .enter()
        .append('g')
        .attr('class', 'axis');

      axis.append('line')
        .attr('x1', 0)
        .attr('y1', 0)
        .attr('x2', (_d: any, i: number) => rScale(100) * Math.cos(angleSlice * i - Math.PI / 2))
        .attr('y2', (_d: any, i: number) => rScale(100) * Math.sin(angleSlice * i - Math.PI / 2))
        .attr('class', 'line')
        .style('stroke', '#4b5563')
        .style('stroke-width', '1px');
        
      // Append axis labels
      axis.append('text')
          .attr('class', 'text-xs font-mono fill-current text-gray-400')
          .attr('text-anchor', 'middle')
          .attr('dy', '0.35em')
          .attr('x', (_d: any, i: number) => rScale(120) * Math.cos(angleSlice * i - Math.PI / 2))
          .attr('y', (_d: any, i: number) => rScale(120) * Math.sin(angleSlice * i - Math.PI / 2))
          .text((d: any) => d);


      const radarLine = d3.lineRadial()
        .curve(d3.curveLinearClosed)
        .radius((d: any) => rScale(d))
        .angle((_d: any, i: number) => i * angleSlice);

      const datasets = [
        { name: 'Benchmark', color: '#4b5563', data: this.data.map(d => d.benchmarkScore) },
        { name: 'Candidate', color: '#3FA86C', data: this.data.map(d => d.candidateScore) }
      ];

      // Draw the radar areas
      const blobWrapper = svg.selectAll('.radarWrapper')
        .data(datasets)
        .enter().append('g')
        .attr('class', 'radarWrapper');
        
      // Append the polygons
      blobWrapper.append('path')
        .attr('class', 'radarArea')
        .attr('d', (d: any) => radarLine(d.data))
        .style('fill', (d: any) => d.color)
        .style('fill-opacity', 0.6);
        
      // Append the outlines
      blobWrapper.append('path')
        .attr('class', 'radarStroke')
        .attr('d', (d: any) => radarLine(d.data))
        .style('stroke-width', '2px')
        .style('stroke', (d: any) => d.color)
        .style('fill', 'none');
    });
  }
}
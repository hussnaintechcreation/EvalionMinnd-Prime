
import { Component, ChangeDetectionStrategy, Input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ButtonDirective } from '../../directives/button.directive';

@Component({
  selector: 'app-flipping-card',
  imports: [CommonModule, RouterModule, ButtonDirective],
  template: `
    <div class="group h-80 w-full [perspective:1000px] cursor-pointer" (click)="cardClick.emit()">
      <div class="relative h-full w-full transition-all duration-500 [transform-style:preserve-3d] group-hover:[transform:rotateY(180deg)]">
        
        <!-- Front Face -->
        <div class="absolute inset-0 h-full w-full bg-black/80 border border-gray-800 p-8 flex flex-col items-center justify-center [backface-visibility:hidden] backdrop-blur-md shadow-[0_0_30px_rgba(0,0,0,0.5)]">
          <div class="w-16 h-16 mb-6 text-green-500 bg-green-900/20 rounded-full flex items-center justify-center border border-green-500/50">
             <ng-content select="[slot=icon]"></ng-content>
          </div>
          <h3 class="text-2xl font-black text-white uppercase tracking-wider text-center font-mono">{{ title }}</h3>
          <div class="mt-4 w-12 h-1 bg-green-600"></div>
          <p class="mt-4 text-xs text-gray-500 font-mono uppercase tracking-widest text-center">
             [ Hover to decrypt ]
          </p>
          
          <!-- Tactical Corners -->
          <div class="absolute top-0 left-0 w-2 h-2 border-t border-l border-green-500"></div>
          <div class="absolute top-0 right-0 w-2 h-2 border-t border-r border-green-500"></div>
          <div class="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-green-500"></div>
          <div class="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-green-500"></div>
        </div>

        <!-- Back Face -->
        <div class="absolute inset-0 h-full w-full bg-green-900/95 border border-green-700 p-8 flex flex-col items-center justify-center [transform:rotateY(180deg)] [backface-visibility:hidden]">
            <p class="text-sm text-green-100 text-center font-mono leading-relaxed mb-6">{{ description }}</p>
            <button appBtn="cyber" class="!text-xs">Establish Link</button>
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FlippingCardComponent {
  @Input({ required: true }) title!: string;
  @Input({ required: true }) description!: string;
  cardClick = output<void>();
}


import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GlobalErrorHandlerService } from '../../../services/global-error-handler.service';

@Component({
  selector: 'app-error-toast',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule],
  templateUrl: './error-toast.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ErrorToastComponent {
  errorHandlerService = inject(GlobalErrorHandlerService);
  notifications = this.errorHandlerService.notifications;
}


import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VoidGlassComponent } from './void-glass.component';

@Component({
  selector: 'app-testimonial-marquee',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, VoidGlassComponent],
  template: `
    <div class="relative w-full overflow-hidden py-10 bg-black/50 border-y border-gray-900">
      <div class="flex animate-marquee gap-8 w-max hover:[animation-play-state:paused]">
        @for (item of testimonials(); track $index) {
          <div class="w-80 flex-shrink-0">
             <app-void-glass [interactive]="true">
                <p class="text-gray-400 text-sm font-mono italic mb-4">"{{ item.text }}"</p>
                <div class="flex items-center gap-3 border-t border-gray-800 pt-3">
                   <div class="w-8 h-8 rounded-full bg-gray-800 border border-green-900 flex items-center justify-center text-xs font-bold text-green-500">
                      {{ item.initials }}
                   </div>
                   <div>
                      <p class="text-white text-xs font-bold uppercase">{{ item.name }}</p>
                      <p class="text-green-600 text-[10px] uppercase tracking-wider">{{ item.role }}</p>
                   </div>
                </div>
             </app-void-glass>
          </div>
        }
        <!-- Duplicate for seamless loop -->
        @for (item of testimonials(); track $index + 'dup') {
          <div class="w-80 flex-shrink-0">
             <app-void-glass [interactive]="true">
                <p class="text-gray-400 text-sm font-mono italic mb-4">"{{ item.text }}"</p>
                <div class="flex items-center gap-3 border-t border-gray-800 pt-3">
                   <div class="w-8 h-8 rounded-full bg-gray-800 border border-green-900 flex items-center justify-center text-xs font-bold text-green-500">
                      {{ item.initials }}
                   </div>
                   <div>
                      <p class="text-white text-xs font-bold uppercase">{{ item.name }}</p>
                      <p class="text-green-600 text-[10px] uppercase tracking-wider">{{ item.role }}</p>
                   </div>
                </div>
             </app-void-glass>
          </div>
        }
      </div>
      
      <!-- Gradient Fades -->
      <div class="absolute inset-y-0 left-0 w-20 bg-gradient-to-r from-black to-transparent z-10"></div>
      <div class="absolute inset-y-0 right-0 w-20 bg-gradient-to-l from-black to-transparent z-10"></div>
    </div>
  `,
  styles: [`
    @keyframes marquee {
      0% { transform: translateX(0); }
      100% { transform: translateX(-50%); }
    }
    .animate-marquee {
      animation: marquee 40s linear infinite;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TestimonialMarqueeComponent {
  testimonials = signal([
    { text: "Reduced our hiring time by 70%. The AI is terrifyingly accurate.", name: "Sarah Connor", role: "CTO, Skynet Corp", initials: "SC" },
    { text: "Zero-trust architecture met our rigorous security compliance needs.", name: "James Bond", role: "Head of Security, MI6", initials: "JB" },
    { text: "The anti-cheat detection is flawless. Candidates can't fake it.", name: "Neo Anderson", role: "Lead Eng, Matrix Systems", initials: "NA" },
    { text: "Automated pipeline management allowed us to scale 10x instantly.", name: "Ellen Ripley", role: "HR Dir, Weyland-Yutani", initials: "ER" },
  ]);
}
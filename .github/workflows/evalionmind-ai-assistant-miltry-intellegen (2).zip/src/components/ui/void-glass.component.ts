
import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-void-glass',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule],
  template: `
    <div 
      class="relative overflow-hidden bg-gray-900/30 backdrop-blur-sm border border-gray-800 transition-all duration-300 group h-full"
      [class.hover:border-green-500]="interactive"
      [class.hover:shadow-[0_0_20px_rgba(16,185,129,0.2)]]="interactive"
      [class.hover:-translate-y-1]="interactive"
      [class.cursor-pointer]="interactive"
    >
      <!-- Scanline effect overlay -->
      <div class="absolute inset-0 z-0 pointer-events-none opacity-20 bg-[linear-gradient(rgba(18,18,18,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_4px,3px_100%]"></div>
      
      <!-- Content Container -->
      <div class="relative z-10 p-6 h-full">
        <ng-content></ng-content>
      </div>

      <!-- Tactical Corner Accents (Visible on Hover/Interactive) -->
      @if (interactive) {
        <div class="absolute top-0 left-0 w-2 h-2 border-t border-l border-green-500/30 group-hover:border-green-500 transition-colors duration-300"></div>
        <div class="absolute top-0 right-0 w-2 h-2 border-t border-r border-green-500/30 group-hover:border-green-500 transition-colors duration-300"></div>
        <div class="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-green-500/30 group-hover:border-green-500 transition-colors duration-300"></div>
        <div class="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-green-500/30 group-hover:border-green-500 transition-colors duration-300"></div>
      }
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class VoidGlassComponent {
  @Input() interactive = false;
}
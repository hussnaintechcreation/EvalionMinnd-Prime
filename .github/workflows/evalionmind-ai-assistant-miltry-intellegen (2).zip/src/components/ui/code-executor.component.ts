
import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-code-executor',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule],
  template: `
    <div class="w-full max-w-2xl mx-auto bg-[#0F111A] border border-gray-700 shadow-2xl overflow-hidden font-mono text-sm relative group">
      <!-- Header -->
      <div class="bg-[#1A1C25] px-4 py-2 flex items-center justify-between border-b border-gray-700">
        <div class="flex items-center gap-2">
          <div class="w-3 h-3 rounded-full bg-red-500"></div>
          <div class="w-3 h-3 rounded-full bg-yellow-500"></div>
          <div class="w-3 h-3 rounded-full bg-green-500"></div>
        </div>
        <span class="text-gray-500 text-xs">candidate_evaluation.ts</span>
      </div>

      <!-- Code Area -->
      <div class="p-6 text-gray-300 relative">
        <div class="absolute left-4 top-6 bottom-6 w-px bg-gray-700 opacity-50"></div>
        <div class="pl-6 space-y-1">
          <!-- Used HTML entities for curly braces to prevent Angular parser errors -->
          <p><span class="text-purple-400">import</span> &#123; AI_Evaluator &#125; <span class="text-purple-400">from</span> <span class="text-green-400">'@evalion/core'</span>;</p>
          <p>&nbsp;</p>
          <p><span class="text-purple-400">const</span> candidate = <span class="text-yellow-300">await</span> AI_Evaluator.<span class="text-blue-400">analyze</span>(&#123;</p>
          <p>&nbsp;&nbsp;id: <span class="text-green-400">'CND-8842'</span>,</p>
          <p>&nbsp;&nbsp;skills: [<span class="text-green-400">'Angular'</span>, <span class="text-green-400">'NestJS'</span>],</p>
          <p>&nbsp;&nbsp;mode: <span class="text-green-400">'DEEP_SCAN'</span></p>
          <p>&#125;);</p>
          <p>&nbsp;</p>
          <p><span class="text-gray-500">// Executing neural analysis...</span></p>
          <p>console.<span class="text-blue-400">log</span>(candidate.score);</p>
        </div>

        <!-- Cursor -->
        @if (isRunning()) {
          <div class="absolute bottom-6 left-10 w-2 h-4 bg-green-500 animate-pulse"></div>
        }
      </div>

      <!-- Output Console -->
      <div class="bg-black/80 border-t border-gray-800 p-4 h-32 overflow-y-auto font-mono text-xs">
        @if (output().length === 0) {
          <div class="text-gray-600 italic">>> Ready to execute...</div>
        }
        @for (line of output(); track $index) {
          <div class="mb-1">
            <span class="text-green-500">>></span> <span [class]="line.color">{{ line.text }}</span>
          </div>
        }
      </div>

      <!-- Run Button -->
      <button (click)="runCode()" [disabled]="isRunning()" class="absolute top-16 right-6 bg-green-700 text-white px-4 py-1 text-xs uppercase tracking-widest hover:bg-green-600 transition-colors shadow-lg flex items-center gap-2">
        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        Execute
      </button>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CodeExecutorComponent {
  isRunning = signal(false);
  output = signal<{ text: string, color: string }[]>([]);

  runCode() {
    this.isRunning.set(true);
    this.output.set([]);

    const sequence = [
      { text: 'Initializing Neural Engine...', delay: 500, color: 'text-gray-400' },
      { text: 'Parsing Candidate GitHub Profile...', delay: 1200, color: 'text-blue-400' },
      { text: 'Detecting Tech Stack: Angular 18, RxJS, Tailwind', delay: 2000, color: 'text-yellow-400' },
      { text: 'Analysis Complete. Match Score: 98.4%', delay: 2800, color: 'text-green-400 font-bold' },
    ];

    let totalDelay = 0;
    sequence.forEach(step => {
      totalDelay += step.delay;
      setTimeout(() => {
        this.output.update(lines => [...lines, { text: step.text, color: step.color }]);
        if (step === sequence[sequence.length - 1]) {
          this.isRunning.set(false);
        }
      }, totalDelay);
    });
  }
}

import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-logo',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule],
  template: `
    <div class="flex items-center gap-3 select-none group cursor-pointer transition-transform duration-300 hover:scale-105">
      <!-- SVG Logo Container -->
      <div 
           [style.width.px]="size" 
           [style.height.px]="size" 
           class="filter drop-shadow-[0_0_8px_rgba(16,185,129,0.5)] transition-all duration-300 group-hover:drop-shadow-[0_0_15px_rgba(16,185,129,0.9)]">
        <svg viewBox="0 0 200 180" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
          <defs>
            <linearGradient id="em-gradient" x1="50%" y1="0%" x2="50%" y2="100%">
              <stop offset="0%" stop-color="#4ade80" />
              <stop offset="100%" stop-color="#15803d" />
            </linearGradient>
             <filter id="glow-filter" x="-50%" y="-50%" width="200%" height="200%">
                <feMorphology operator="dilate" radius="1" in="SourceAlpha" result="thicken" />
                <feGaussianBlur in="thicken" stdDeviation="3" result="blurred" />
                <feFlood flood-color="#10b981" result="glowColor" />
                <feComposite in="glowColor" in2="blurred" operator="in" result="softGlow_colored" />
                <feMerge>
                    <feMergeNode in="softGlow_colored"/>
                    <feMergeNode in="SourceGraphic"/>
                </feMerge>
            </filter>
          </defs>
          
          <!-- Main Shape -->
          <g>
            <!-- Left Brain/Circuit Part -->
            <path d="M95 15 V165 C85 175, 75 175, 65 165 L25 125 C5 105, 5 75, 25 55 L65 15 C75 5, 85 5, 95 15 Z" fill="#1e293b" stroke="url(#em-gradient)" stroke-width="2"/>
            <!-- Right Shield Part -->
            <path d="M105 15 V165 C115 175, 125 175, 135 165 L175 125 C195 105, 195 75, 175 55 L135 15 C125 5, 115 5, 105 15 Z" fill="#0f172a" stroke="#4ade80" stroke-width="2"/>
          </g>

          <!-- EM Letters & Circuit Details -->
          <g filter="url(#glow-filter)" fill="url(#em-gradient)">
            <!-- E -->
            <path d="M75 50 H40 V130 H75 M75 90 H40" fill="none" stroke="url(#em-gradient)" stroke-width="12" stroke-linejoin="round" stroke-linecap="round"/>
            
            <!-- M -->
            <path d="M125 130 V50 L145 90 L165 50 V130" fill="none" stroke="url(#em-gradient)" stroke-width="12" stroke-linejoin="round" stroke-linecap="round"/>

            <!-- Circuit Lines Left -->
            <circle cx="65" cy="25" r="4" stroke="#4ade80" stroke-width="2"/>
            <path d="M65 29 V40 H75" fill="none" stroke="#4ade80" stroke-width="3"/>
            <circle cx="30" cy="60" r="4" stroke="#4ade80" stroke-width="2"/>
            <path d="M34 60 H40" fill="none" stroke="#4ade80" stroke-width="3"/>
            <circle cx="30" cy="120" r="4" stroke="#4ade80" stroke-width="2"/>
            <path d="M34 120 H40" fill="none" stroke="#4ade80" stroke-width="3"/>
            <circle cx="65" cy="155" r="4" stroke="#4ade80" stroke-width="2"/>
            <path d="M65 151 V140 H75" fill="none" stroke="#4ade80" stroke-width="3"/>

            <!-- Circuit Lines Right -->
            <circle cx="135" cy="25" r="4" stroke="#4ade80" stroke-width="2"/>
            <path d="M135 29 V40" fill="none" stroke="#4ade80" stroke-width="3"/>
          </g>
        </svg>
      </div>

      <!-- Branded Text (Optional) -->
      @if (withText) {
        <div class="flex flex-col justify-center">
          <h1 [class]="textSizeClass" class="font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-400 uppercase tracking-tighter font-mono leading-none group-hover:from-white group-hover:to-white transition-colors">
            Evalion<span class="text-green-500 drop-shadow-[0_0_5px_rgba(16,185,129,0.8)]">Mind</span>
          </h1>
          @if (subText) {
             <span class="text-[0.6rem] text-green-600 font-mono tracking-[0.2em] uppercase mt-0.5 border-t border-green-900/50 pt-0.5">{{ subText }}</span>
          }
        </div>
      }
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LogoComponent {
  @Input() size: number = 40;
  @Input() withText: boolean = false;
  @Input() textSizeClass: string = 'text-xl'; // e.g., 'text-2xl', 'text-4xl'
  @Input() subText: string = '';
}
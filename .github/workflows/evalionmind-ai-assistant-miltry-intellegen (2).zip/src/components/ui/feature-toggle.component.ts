
import { Component, ChangeDetectionStrategy, Input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeatureFlagService, FeatureFlags } from '../../services/feature-flag.service';

@Component({
  selector: 'app-feature-toggle',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule],
  template: `
    <div class="flex items-center justify-between p-3 bg-black/40 border border-gray-800 hover:border-gray-700 transition-colors">
      <div class="flex flex-col">
        <span class="text-xs font-mono uppercase text-gray-300 tracking-wider">{{ label }}</span>
        <span class="text-[10px] text-gray-600 font-mono">FLAG: {{ featureKey }}</span>
      </div>
      
      <button 
        (click)="toggle()"
        class="relative inline-flex h-5 w-10 items-center border border-gray-600 transition-colors duration-200 focus:outline-none focus:ring-1 focus:ring-green-500 focus:ring-offset-1 focus:ring-offset-black"
        [class.bg-green-900]="isEnabled()"
        [class.border-green-500]="isEnabled()"
        [class.bg-gray-900]="!isEnabled()"
      >
        <span class="sr-only">Toggle {{ label }}</span>
        <span 
          class="inline-block h-3 w-3 transform bg-white transition duration-200 ease-in-out"
          [class.translate-x-6]="isEnabled()"
          [class.translate-x-1]="!isEnabled()"
          [class.bg-green-400]="isEnabled()"
          [class.bg-gray-500]="!isEnabled()"
        ></span>
      </button>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FeatureToggleComponent {
  @Input({ required: true }) featureKey!: keyof FeatureFlags;
  @Input({ required: true }) label!: string;
  
  featureService = inject(FeatureFlagService);

  isEnabled() {
    return this.featureService.isEnabled(this.featureKey);
  }

  toggle() {
    this.featureService.toggleFeature(this.featureKey);
  }
}
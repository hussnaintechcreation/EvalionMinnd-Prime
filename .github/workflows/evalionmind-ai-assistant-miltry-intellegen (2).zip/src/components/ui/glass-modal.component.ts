
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-glass-modal',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule],
  template: `
    <div class="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fadeIn">
      <div class="relative w-full max-w-lg bg-gray-900 border border-green-900 shadow-[0_0_50px_rgba(16,185,129,0.2)] overflow-hidden">
        <!-- Header -->
        <div class="bg-black/60 p-4 border-b border-gray-800 flex justify-between items-center">
          <h3 class="text-white font-bold uppercase tracking-widest font-mono text-sm">{{ title }}</h3>
          <button (click)="close.emit()" class="text-gray-500 hover:text-red-500 transition-colors">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>
        </div>
        
        <!-- Body -->
        <div class="p-6 bg-black/40">
          <ng-content></ng-content>
        </div>

        <!-- Footer -->
        <div class="bg-black/60 p-4 border-t border-gray-800 flex justify-end gap-3">
            <ng-content select="[slot=footer]"></ng-content>
        </div>
        
        <!-- Tactical Corners -->
        <div class="absolute top-0 left-0 w-2 h-2 border-t border-l border-green-500"></div>
        <div class="absolute top-0 right-0 w-2 h-2 border-t border-r border-green-500"></div>
        <div class="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-green-500"></div>
        <div class="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-green-500"></div>
      </div>
    </div>
  `
})
export class GlassModalComponent {
  @Input() title = 'System Message';
  @Output() close = new EventEmitter<void>();
}
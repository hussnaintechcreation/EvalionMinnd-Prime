
import { Component, ChangeDetectionStrategy, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogoComponent } from '../ui/logo.component';

@Component({
  selector: 'app-footer',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, LogoComponent],
  templateUrl: './footer.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FooterComponent {
  aboutClick = output<void>();
}
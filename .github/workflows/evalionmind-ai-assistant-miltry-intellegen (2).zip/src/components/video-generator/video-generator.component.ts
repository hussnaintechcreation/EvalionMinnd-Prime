
import { Component, ChangeDetectionStrategy, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';
import { ButtonDirective } from '../../directives/button.directive';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-video-generator',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, FormsModule, ButtonDirective],
  templateUrl: './video-generator.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class VideoGeneratorComponent {
  geminiService = inject(GeminiService);
  // FIX: Explicitly type `DomSanitizer` to resolve a type inference issue where it was inferred as `unknown`.
  private sanitizer: DomSanitizer = inject(DomSanitizer);

  prompt = signal('A cinematic, high-speed drone shot of a futuristic city at night, with neon lights and flying vehicles.');
  isLoading = signal(false);
  progressMessage = signal('');
  videoUrl = signal<SafeUrl | null>(null);
  error = signal<string | null>(null);

  async generateVideo(): Promise<void> {
    if (!this.prompt().trim() || this.isLoading()) {
      return;
    }

    this.isLoading.set(true);
    this.videoUrl.set(null);
    this.error.set(null);
    this.progressMessage.set('');

    try {
      const unsafeUrl = await this.geminiService.generateVideo(
        this.prompt(),
        (status: string) => {
          this.progressMessage.set(status);
        }
      );

      if (unsafeUrl) {
        this.videoUrl.set(this.sanitizer.bypassSecurityTrustUrl(unsafeUrl));
      } else {
        this.error.set(this.geminiService.error() || 'An unknown error occurred during video generation.');
      }
    } catch (e: any) {
      this.error.set(e.message || 'An unexpected error occurred.');
    } finally {
      this.isLoading.set(false);
    }
  }

  reset(): void {
      this.videoUrl.set(null);
      this.error.set(null);
      this.progressMessage.set('');
      this.prompt.set('A cinematic, high-speed drone shot of a futuristic city at night, with neon lights and flying vehicles.');
  }
}
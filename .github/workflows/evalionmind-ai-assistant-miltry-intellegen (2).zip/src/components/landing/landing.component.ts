
import { Component, ChangeDetectionStrategy, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeroComponent } from '../hero/hero.component';
import { FlippingCardComponent } from '../ui/flipping-card.component';
import { TestimonialMarqueeComponent } from '../ui/testimonial-marquee.component';
import { CodeExecutorComponent } from '../ui/code-executor.component';
import { UiService } from '../../services/ui.service';

@Component({
  selector: 'app-landing',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, HeroComponent, FlippingCardComponent, TestimonialMarqueeComponent, CodeExecutorComponent],
  templateUrl: './landing.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LandingComponent {
  uiService = inject(UiService);

  // Modules for flipping cards, now without direct links.
  modules = signal([
    { 
      title: 'Mission Control', 
      description: 'Centralized command center for recruitment operations. Monitor global hiring metrics and threat levels.', 
      action: () => this.uiService.openLogin('company'),
      icon: 'globe' 
    },
    { 
      title: 'Operations (ATS)', 
      description: 'Manage active pipelines, requisition clearances, and deploy recruitment campaigns.', 
      action: () => this.uiService.openLogin('company'),
      icon: 'briefcase'
    },
    { 
      title: 'AI Assessment', 
      description: 'Review detailed dossiers, AI-generated reports, and skill assessments for candidates.', 
      action: () => this.uiService.openLogin('company'),
      icon: 'users'
    },
    { 
      title: 'Resource Armory', 
      description: 'Configure system tools, billing resources, and AI protocols to match mission parameters.', 
      action: () => this.uiService.openLogin('company'),
      icon: 'cog'
    }
  ]);

  handleCardClick(action: () => void): void {
    action();
  }
}
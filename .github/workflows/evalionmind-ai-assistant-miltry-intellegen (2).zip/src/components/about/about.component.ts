
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { UiService } from '../../services/ui.service';
import { CommonModule } from '@angular/common'; // FIX: Add CommonModule for standalone components

@Component({
  selector: 'app-about',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule], // FIX: Added CommonModule for standalone
  template: `
    <div class="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-[100] font-mono">
      <div class="relative bg-gray-900 border-2 border-green-800 w-full max-w-lg p-1 shadow-2xl shadow-green-900/20">
        <!-- Tactical Corner Decals -->
        <div class="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-green-500"></div>
        <div class="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-green-500"></div>
        <div class="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-green-500"></div>
        <div class="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-green-500"></div>

        <div class="bg-black/50 p-8">
          <button (click)="uiService.closeAbout()" class="absolute top-4 right-4 text-gray-500 hover:text-red-500 transition-colors">
            [X] CLOSE
          </button>

          <h2 class="text-2xl font-bold text-green-500 uppercase tracking-widest mb-6 border-b border-gray-800 pb-2">
            Command Structure
          </h2>

          <div class="space-y-6 text-gray-300">
            <div>
              <p class="text-xs text-gray-600 uppercase mb-1">Principal Architect / Owner</p>
              <p class="text-xl text-white font-bold tracking-wide">Mr. Hussnain</p>
            </div>

            <div class="grid grid-cols-1 gap-4">
              <div class="bg-gray-800/50 p-3 border-l-2 border-green-700">
                <p class="text-xs text-gray-500 uppercase">Secure Line</p>
                <p class="text-green-400 font-bold">+92 302 8808488</p>
              </div>
              
              <div class="bg-gray-800/50 p-3 border-l-2 border-green-700">
                <p class="text-xs text-gray-500 uppercase">Uplink</p>
                <p class="text-green-400 font-bold">hussnaintechofficial@gmail.com</p>
              </div>
            </div>

            <div class="mt-6 pt-4 border-t border-gray-800 text-center">
              <p class="text-xs text-gray-500">
                HUSSNAIN TECH VERTEX PVTD <br>
                <span class="text-green-800">AUTHORIZED PERSONNEL ONLY</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AboutComponent {
  uiService = inject(UiService);
}
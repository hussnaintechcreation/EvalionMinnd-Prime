
import { Component, ChangeDetectionStrategy, signal, viewChild, ElementRef, OnDestroy, inject, computed, NgZone, WritableSignal, effect, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InterviewService } from '../../services/interview.service';
import { EvaluationService } from '../../services/evaluation.service';
import { Subscription } from 'rxjs';
import { AntiCheatPayload } from '../../models/shared.interfaces';
import { AuthService } from '../../services/auth.service';
import { SpeechRecognitionService } from '../../services/speech-recognition.service';

type ProctoringStatus = {
  gazeTracking: 'nominal' | 'alert';
  expressionAnalysis: 'nominal' | 'warning';
  audioAnomaly: 'nominal' | 'detected';
  systemIntegrity: 'secure' | 'compromised';
};

interface ToastNotification {
  id: number;
  type: 'warning' | 'info' | 'critical';
  message: string;
}

@Component({
  selector: 'app-interview-room',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule],
  templateUrl: './interview-room.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InterviewRoomComponent implements OnDestroy, OnInit {
  videoElement = viewChild<ElementRef<HTMLVideoElement>>('videoElement');
  videoContainer = viewChild<ElementRef<HTMLDivElement>>('videoContainer');
  transcriptContainer = viewChild<ElementRef<HTMLDivElement>>('transcriptContainer');
  
  interviewService = inject(InterviewService);
  evaluationService = inject(EvaluationService);
  speechRecognitionService = inject(SpeechRecognitionService);
  authService = inject(AuthService);
  private ngZone = inject(NgZone);

  // Component State
  setupState = signal<'idle' | 'requesting' | 'success' | 'error'>('idle');
  errorMessage = signal<string | null>(null);
  isCommencing = signal(false);
  
  // Real-time Transcription State - Derived from service
  isListening = computed(() => this.speechRecognitionService.state() === 'listening');
  displayFinalTranscript = this.speechRecognitionService.finalTranscript;
  displayInterimTranscript = this.speechRecognitionService.interimTranscript;
  liveTranscript = computed(() => {
    const final = this.displayFinalTranscript();
    const interim = this.displayInterimTranscript();
    return (final + (interim ? ' ' + interim : '')).trim();
  });

  private antiCheatSub: Subscription;
  
  // UI State
  notifications = signal<ToastNotification[]>([]);
  isVideoFullscreen = signal(false);
  isPiPActive = signal(false);
  isMuted = signal(true);
  currentVideoLayout: WritableSignal<'self-view' | 'interviewer-feed' | 'grid-view'> = signal('self-view');

  // AI Proctoring Visual Alerts
  videoFocusLostAlert = signal(false);
  videoMultipleFacesAlert = signal(false);

  proctoringStatus = signal<ProctoringStatus>({
    gazeTracking: 'nominal',
    expressionAnalysis: 'nominal',
    audioAnomaly: 'nominal',
    systemIntegrity: 'secure',
  });

  readonly proctoringItems = computed(() => [
    { label: 'Gaze Tracking', status: this.proctoringStatus().gazeTracking },
    { label: 'Expression Analysis', status: this.proctoringStatus().expressionAnalysis },
    { label: 'Audio Anomaly', status: this.proctoringStatus().audioAnomaly },
    { label: 'System Integrity', status: this.proctoringStatus().systemIntegrity }
  ]);
  
  stream = signal<MediaStream | null>(null);

  constructor() {
    this.antiCheatSub = this.interviewService.antiCheatEvent$.subscribe(eventType => {
      this.ngZone.run(() => this.updateProctoringStatus(eventType));
    });

    effect(() => {
        const text = this.displayFinalTranscript() + this.displayInterimTranscript();
        if (text) {
            setTimeout(() => this.scrollToBottom(), 0);
        }
    });

    effect(() => {
      const stream = this.stream();
      const videoRef = this.videoElement();
      const videoEl = videoRef?.nativeElement;
      
      if (stream && videoEl) {
        if (videoEl.srcObject !== stream) {
          videoEl.srcObject = stream;
          videoEl.muted = this.isMuted();
          videoEl.onloadedmetadata = () => {
              videoEl.play().catch(err => {
                console.error('[InterviewRoom] Video autoplay blocked:', err);
                this.addNotification('warning', 'Video autoplay blocked. Please interact with the page.');
              });
          };
        }
      }
    });

    // Effect to handle errors from the SpeechRecognitionService
    effect(() => {
      const error = this.speechRecognitionService.error();
      if (error) {
        this.addNotification('critical', error);
      }
    });
  }

  ngOnInit(): void {
    this.checkInitialPermissions();
  }

  private async checkInitialPermissions(): Promise<void> {
    if (navigator.permissions && navigator.permissions.query) {
        try {
            const cameraStatus = await navigator.permissions.query({ name: 'camera' as any });
            const micStatus = await navigator.permissions.query({ name: 'microphone' as any });
            
            if (cameraStatus.state === 'denied' || micStatus.state === 'denied') {
                this.setupState.set('error');
                this.errorMessage.set('Permission denied. Please allow access in browser settings.');
            }
        } catch(e) {}
    }
  }

  async startSetup(): Promise<void> {
    this.setupState.set('requesting');
    this.errorMessage.set(null);
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      this.stream.set(stream);
      
      this.speechRecognitionService.initialize();
      if (this.speechRecognitionService.state() === 'error') {
        throw new Error(this.speechRecognitionService.error()!);
      }

      this.setupState.set('success');
      this.addNotification('info', 'Hardware verification complete.');

    } catch (err: any) {
      console.error('[InterviewRoom] Setup failed:', err);
      this.setupState.set('error');
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
         this.errorMessage.set('Access to Camera/Microphone was denied.');
      } else if (err.name === 'NotFoundError') {
         this.errorMessage.set('No compatible camera or microphone found.');
      } else {
         this.errorMessage.set('Hardware initialization failed: ' + (err.message || 'Unknown Error'));
      }
    }
  }

  retrySetup(): void {
      this.startSetup();
  }
  
  enableDemoMode(): void {
      this.setupState.set('success');
      this.errorMessage.set(null);
      this.addNotification('warning', 'Running in DEMO MODE. Hardware inputs simulated.');
  }

  async commenceInterview(): Promise<void> {
    this.isCommencing.set(true);
    
    const candidateId = this.authService.currentUser()?.id;
    if (!candidateId) {
        this.addNotification('critical', 'Candidate ID not found. Cannot start interview.');
        this.isCommencing.set(false);
        return;
    }

    const success = await this.interviewService.startInterview(candidateId);
    
    if (success) {
        this.isCommencing.set(false);
        this.speechRecognitionService.start();
        this.addNotification('info', 'Interview Protocol Initiated.');
    } else {
        this.isCommencing.set(false);
        this.addNotification('critical', 'Failed to initialize interview session.');
    }
  }

  submitAndNextQuestion(): void {
    if (this.interviewService.interviewState() !== 'in-progress') return;

    const answer = this.liveTranscript();
    this.interviewService.nextQuestion(answer);
    
    this.speechRecognitionService.resetTranscript();
  }

  finalizeInterview(): void {
    if (this.interviewService.interviewState() !== 'in-progress') return;
    const finalAnswer = this.liveTranscript();
    this.interviewService.endInterview(finalAnswer);
    this.speechRecognitionService.stop();
  }

  formattedTimeLeft() {
    const seconds = this.interviewService.timeLeft();
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  }

  toggleFullscreen() {
    const el = this.videoContainer()?.nativeElement;
    if (!el) return;

    if (!document.fullscreenElement) {
      el.requestFullscreen().then(() => this.isVideoFullscreen.set(true)).catch(err => {
        this.addNotification('warning', `Fullscreen denied: ${err.message}`);
      });
    } else {
      document.exitFullscreen().then(() => this.isVideoFullscreen.set(false));
    }
  }

  togglePictureInPicture() {
    const video = this.videoElement()?.nativeElement;
    if (!video) return;

    if (document.pictureInPictureElement) {
      document.exitPictureInPicture().catch(err => console.error(err));
      this.isPiPActive.set(false);
    } else {
      video.requestPictureInPicture().catch(err => {
          this.addNotification('warning', 'PiP not supported or disabled.');
      });
      this.isPiPActive.set(true);
    }
  }
  
  toggleMute() {
    this.isMuted.update(m => !m);
    const video = this.videoElement()?.nativeElement;
    if(video) video.muted = this.isMuted();
  }

  selectVideoLayout(layout: 'self-view' | 'interviewer-feed' | 'grid-view') {
      this.currentVideoLayout.set(layout);
  }

  private updateProctoringStatus(eventType: AntiCheatPayload['type']): void {
    this.ngZone.run(() => {
        this.addNotification('critical', `Anti-Cheat Alert: ${eventType.replace(/_/g, ' ').toUpperCase()}`);

        if (eventType === 'focus') { 
            this.videoFocusLostAlert.set(false);
            this.videoMultipleFacesAlert.set(false);
            this.proctoringStatus.update(s => ({ ...s, systemIntegrity: 'secure', gazeTracking: 'nominal', expressionAnalysis: 'nominal', audioAnomaly: 'nominal' }));
            return; 
        }

        switch (eventType) {
            case 'tab_hidden':
            case 'blur':
                this.proctoringStatus.update(s => ({ ...s, systemIntegrity: 'compromised' }));
                this.videoFocusLostAlert.set(true);
                setTimeout(() => this.ngZone.run(() => this.videoFocusLostAlert.set(false)), 3000);
                break;
            case 'multiple_faces':
                this.proctoringStatus.update(s => ({ ...s, expressionAnalysis: 'warning' }));
                this.videoMultipleFacesAlert.set(true);
                setTimeout(() => this.ngZone.run(() => this.videoMultipleFacesAlert.set(false)), 3000);
                break;
            case 'audio_anomaly':
                this.proctoringStatus.update(s => ({ ...s, audioAnomaly: 'detected' }));
                setTimeout(() => this.ngZone.run(() => this.proctoringStatus.update(s => ({ ...s, audioAnomaly: 'nominal' }))), 4000);
                break;
        }
    });
  }

  addNotification(type: 'warning' | 'info' | 'critical', message: string) {
    const id = Date.now();
    this.notifications.update(n => [...n, { id, type, message }]);
    setTimeout(() => {
      this.notifications.update(n => n.filter(item => item.id !== id));
    }, 5000);
  }
  
  scrollToBottom() {
      try {
          const el = this.transcriptContainer()?.nativeElement;
          if(el) el.scrollTop = el.scrollHeight;
      } catch(e) {}
  }

  ngOnDestroy(): void {
    if (this.stream()) {
      this.stream()!.getTracks().forEach(track => track.stop());
    }
    this.speechRecognitionService.destroy();
    if (this.antiCheatSub) this.antiCheatSub.unsubscribe();
  }
}

import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { AtsService } from '../../services/ats.service';
import { VoidGlassComponent } from '../ui/void-glass.component';

@Component({
  selector: 'app-company-dashboard',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [
    CommonModule,
    RouterLink,
    VoidGlassComponent,
  ],
  templateUrl: './company-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CompanyDashboardComponent {
  authService = inject(AuthService);
  atsService = inject(AtsService);

  // Stats for Mission Control Overview
  missionStats = signal([
    { label: 'Active Pipeline', value: '45', color: 'text-green-500' },
    { label: 'Interviews Today', value: '12', color: 'text-yellow-500' },
    { label: 'Pending Reviews', value: '8', color: 'text-red-500' },
    { label: 'Avg Time to Hire', value: '14d', color: 'text-blue-500' }
  ]);
  
  // High-priority candidates for the dashboard
  priorityCandidates = computed(() => {
    const allStages = this.atsService.pipelineStages();
    const relevantCandidates = allStages.flatMap(stage => 
      stage.candidates.filter(c => c.status === 'review' || c.status === 'interviewing')
    );
    return relevantCandidates.sort((a, b) => {
      const dateA = a.interviewDate ? new Date(a.interviewDate).getTime() : 0;
      const dateB = b.interviewDate ? new Date(b.interviewDate).getTime() : 0;
      return dateB - dateA;
    }).slice(0, 5); 
  });
}
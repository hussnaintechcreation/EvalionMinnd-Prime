
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet, RouterLink } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { AuthService } from '../../services/auth.service';
import { ChatbotComponent } from '../chatbot/chatbot.component';

@Component({
  selector: 'app-candidate-layout', // Renamed selector for clarity
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [
    CommonModule, 
    RouterOutlet,
    RouterLink,
    HeaderComponent, 
    ChatbotComponent
  ],
  templateUrl: './candidate-dashboard-view.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CandidateLayoutComponent {
  authService = inject(AuthService);
  // FIX: Explicitly type injected Router to resolve 'unknown' type error.
  router: Router = inject(Router);

  handleGoToProfile(): void {
    this.router.navigate(['/candidate/profile']);
  }

  handleGoToSettings(): void {
    this.router.navigate(['/candidate/settings']);
  }
}
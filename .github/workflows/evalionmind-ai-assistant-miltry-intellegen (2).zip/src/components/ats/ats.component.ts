
import { Component, ChangeDetectionStrategy, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AtsService } from '../../services/ats.service';
import { Candidate, PipelineStage } from '../../models/ats.model';
import { GlassModalComponent } from '../ui/glass-modal.component';
import { ButtonDirective } from '../../directives/button.directive';

@Component({
  selector: 'app-ats',
  imports: [CommonModule, GlassModalComponent, FormsModule, ButtonDirective],
  templateUrl: './ats.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AtsComponent {
  atsService = inject(AtsService);
  pipelineStages = this.atsService.pipelineStages;

  // --- CRUD UI State ---
  showStageModal = signal(false);
  stageToEdit = signal<PipelineStage | null>(null);
  stageTitle = signal('');
  stageToDelete = signal<PipelineStage | null>(null);

  showCandidateModal = signal(false);
  candidateToEdit = signal<{ candidate: Candidate, stageId: string } | null>(null);
  candidateName = signal('');
  candidateRole = signal('');
  candidateStageId = signal(''); // Track selected stage
  
  // --- Stage CRUD Handlers ---
  openAddStageModal(): void {
    this.stageToEdit.set(null);
    this.stageTitle.set('');
    this.showStageModal.set(true);
  }

  openEditStageModal(stage: PipelineStage, event: MouseEvent): void {
    event.stopPropagation();
    this.stageToEdit.set(stage);
    this.stageTitle.set(stage.title);
    this.showStageModal.set(true);
  }

  saveStage(): void {
    if (!this.stageTitle().trim()) return;

    const stage = this.stageToEdit();
    if (stage) {
      this.atsService.editStage(stage.id, this.stageTitle());
    } else {
      this.atsService.addStage(this.stageTitle());
    }
    this.closeStageModal();
  }

  closeStageModal(): void {
    this.showStageModal.set(false);
    this.stageToEdit.set(null);
    this.stageTitle.set('');
  }
  
  confirmDeleteStage(stage: PipelineStage, event: MouseEvent): void {
    event.stopPropagation();
    this.stageToDelete.set(stage);
  }
  
  executeDeleteStage(): void {
      const stage = this.stageToDelete();
      if(stage) {
          this.atsService.deleteStage(stage.id);
      }
      this.stageToDelete.set(null);
  }

  // --- Candidate CRUD Handlers ---
  openAddCandidateModal(): void {
    this.candidateToEdit.set(null);
    this.candidateName.set('');
    this.candidateRole.set('');
    // Default to first stage
    this.candidateStageId.set(this.pipelineStages()[0]?.id || '');
    this.showCandidateModal.set(true);
  }

  openEditCandidateModal(candidate: Candidate, stageId: string, event: MouseEvent): void {
    event.stopPropagation();
    this.candidateToEdit.set({ candidate, stageId });
    this.candidateName.set(candidate.name);
    this.candidateRole.set(candidate.role);
    this.candidateStageId.set(stageId);
    this.showCandidateModal.set(true);
  }

  saveCandidate(): void {
    if (!this.candidateName().trim() || !this.candidateRole().trim() || !this.candidateStageId()) return;

    const editInfo = this.candidateToEdit();
    const newStageId = this.candidateStageId();

    if (editInfo) {
      // Handle Move if stage changed
      if (editInfo.stageId !== newStageId) {
        this.atsService.moveCandidate(editInfo.candidate.id, editInfo.stageId, newStageId);
      }
      
      // Update details
      this.atsService.editCandidate(editInfo.candidate.id, newStageId, {
        name: this.candidateName(),
        role: this.candidateRole(),
      });
    } else {
      // Create new candidate in selected stage
      this.atsService.addCandidate(this.candidateName(), this.candidateRole(), newStageId);
    }
    this.closeCandidateModal();
  }

  closeCandidateModal(): void {
    this.showCandidateModal.set(false);
    this.candidateToEdit.set(null);
    this.candidateName.set('');
    this.candidateRole.set('');
    this.candidateStageId.set('');
  }
  
  deleteCandidate(candidateId: string, stageId: string, event: MouseEvent): void {
    event.stopPropagation();
    this.atsService.deleteCandidate(candidateId, stageId);
  }

  getScoreColor(score: number): string {
    if (score >= 85) return 'text-green-500';
    if (score >= 60) return 'text-yellow-500';
    return 'text-red-500';
  }
}

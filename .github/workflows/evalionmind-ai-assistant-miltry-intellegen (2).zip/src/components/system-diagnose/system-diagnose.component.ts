
import { Component, ChangeDetectionStrategy, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonDirective } from '../../directives/button.directive';
import { HttpClient } from '@angular/common/http';
import { lastValueFrom } from 'rxjs';

interface LogMessage {
  text: string;
  status: 'pending' | 'success' | 'fail' | 'info';
}

interface DiagnosticCheck {
  id: string; // Unique ID for the check
  text: string;
  delay: number;
  expectedStatus: 'success' | 'fail' | 'info'; // Expected status from backend
}

@Component({
  selector: 'app-system-diagnose',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, ButtonDirective],
  templateUrl: './system-diagnose.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SystemDiagnoseComponent {
  // FIX: Explicitly type injected HttpClient to resolve 'unknown' type error.
  private httpClient: HttpClient = inject(HttpClient);

  logMessages = signal<LogMessage[]>([]);
  isRunning = signal(false);
  scanComplete = signal(false);
  finalStatus = signal<'nominal' | 'warning' | 'error'>('nominal');

  async runDiagnostics(): Promise<void> {
    if (this.isRunning()) return;

    this.isRunning.set(true);
    this.scanComplete.set(false);
    this.logMessages.set([]);
    this.finalStatus.set('nominal');

    const checks: DiagnosticCheck[] = [
      { id: 'init', text: 'Initializing diagnostic sequence...', delay: 500, expectedStatus: 'info' },
      { id: 'ping_ai', text: 'Pinging AI Core...', delay: 1000, expectedStatus: 'success' },
      { id: 'encrypt_proto', text: 'Verifying encryption protocols (AES-256)...', delay: 800, expectedStatus: 'success' },
      { id: 'db_conn', text: 'Checking database connection pool...', delay: 1200, expectedStatus: 'success' },
      { id: 'ws_vuln', text: 'Scanning for WebSocket vulnerabilities...', delay: 1500, expectedStatus: Math.random() > 0.1 ? 'success' : 'fail' }, // Simulate random failure
      { id: 'zero_trust', text: 'Validating Zero-Trust policy enforcement...', delay: 700, expectedStatus: 'success' },
      { id: 'api_latency', text: 'Testing API gateway latency...', delay: 900, expectedStatus: 'success' },
      { id: 'feature_flags', text: 'Analyzing feature flag integrity...', delay: 500, expectedStatus: 'success' },
    ];
    
    for (const check of checks) {
        this.logMessages.update(logs => [...logs, { text: check.text.replace('...', ''), status: 'pending' }]);
        await new Promise(res => setTimeout(res, check.delay));
        
        let actualStatus: LogMessage['status'] = 'info';
        try {
            // Fix: Added explicit type casting for backendResponse from lastValueFrom
            const backendResponse = await lastValueFrom(this.httpClient.get<{ status: 'success' | 'fail' | 'info' }>(`/api/diagnostics/check/${check.id}`)) as { status: 'success' | 'fail' | 'info' };
            actualStatus = backendResponse.status;
        } catch (error) {
            console.error(`[Diagnostics] Backend check for '${check.id}' failed:`, error);
            actualStatus = 'fail'; // Mark as fail if backend call itself fails
        }

        this.logMessages.update(logs => {
            if (logs.length === 0) return logs;
            const newLogs = [...logs];
            const lastLog = newLogs[newLogs.length - 1];
            newLogs[newLogs.length - 1] = { ...lastLog, status: actualStatus };

            if (actualStatus === 'fail' && this.finalStatus() !== 'error') { // Only set to error if not already error
                this.finalStatus.set('error');
            } else if (actualStatus === 'info' && this.finalStatus() === 'nominal') {
                this.finalStatus.set('warning'); // Set warning for info messages if no errors
            }
            return newLogs;
        });
    }

    this.logMessages.update(logs => [...logs, { text: 'Diagnostic sequence complete.', status: 'info' }]);
    this.scanComplete.set(true);
    this.isRunning.set(false);
    
    // If no errors but some warnings, set final status to warning
    if (this.finalStatus() === 'nominal' && this.logMessages().some(log => log.status === 'info' && log.text.includes('warn'))) {
        this.finalStatus.set('warning');
    }
  }
}
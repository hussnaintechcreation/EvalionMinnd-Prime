
import { Component, ChangeDetectionStrategy, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SubscriptionPlan } from '../../models/subscription.model';
import { StripeService } from '../../services/stripe.service';

@Component({
  selector: 'app-billing',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule],
  templateUrl: './billing.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BillingComponent implements OnInit {
  private stripeService = inject(StripeService);
  private route = inject(ActivatedRoute) as ActivatedRoute;
  // FIX: Explicitly type injected Router to resolve 'unknown' type error.
  private router: Router = inject(Router);

  plans = signal<SubscriptionPlan[]>([
     {
      id: 'price_free_tier',
      name: 'Free',
      price: '$0',
      priceDetails: '/month',
      features: [
        '1 AI-powered interview',
        'Basic candidate screening',
        'Email support',
      ],
      isMostPopular: false,
      tierLevel: 0,
    },
    {
      id: 'price_starter_tier',
      name: 'Starter',
      price: '$49',
      priceDetails: '/month',
      features: [
        '5 AI-powered interviews',
        'Basic candidate screening',
        'Standard reporting',
        'Email support',
      ],
      isMostPopular: false,
      tierLevel: 1,
    },
    {
      id: 'price_professional_tier',
      name: 'Professional',
      price: '$99',
      priceDetails: '/month',
      features: [
        '50 AI-powered interviews',
        'Advanced candidate screening',
        'In-depth analytics dashboard',
        'Priority email support',
        'ATS Integration',
      ],
      isMostPopular: true,
      tierLevel: 2,
    },
    {
      id: 'price_enterprise_tier',
      name: 'Enterprise',
      price: 'Custom',
      priceDetails: '',
      features: [
        'Unlimited interviews',
        'Custom AI models',
        'Dedicated account manager',
        '24/7 premium support',
        'API Access & SSO',
      ],
      isMostPopular: false,
      tierLevel: 3,
    },
  ]);

  currentPlan = signal<SubscriptionPlan>(this.plans()[0]);
  selectedPlan = signal<SubscriptionPlan | null>(null);
  
  isProcessing = signal(false);
  subscriptionSuccess = signal(false);
  webhookStatus = signal<'waiting' | 'verified' | null>(null);
  errorMessage = signal<string | null>(null);

  // Rate Limiting
  private requestTimestamps: number[] = [];
  private readonly RATE_LIMIT_COUNT = 5;
  private readonly RATE_LIMIT_WINDOW_MS = 10000;
  isRateLimited = signal(false);
  rateLimitMessage = signal('');

  ngOnInit(): void {
    // Check for Stripe return URL parameters
    this.route.queryParams.subscribe(async params => {
      if (params['payment_status'] === 'succeeded' && params['session_id']) {
        this.handlePaymentSuccess(params['session_id']);
      }
    });
  }

  private async handlePaymentSuccess(sessionId: string): Promise<void> {
    this.isProcessing.set(true);
    this.selectedPlan.set(this.plans()[2]); // Assume upgrade to Professional for demo
    
    // Simulate waiting for Webhook confirmation
    this.webhookStatus.set('waiting');
    await this.stripeService.simulateWebhookEvent(sessionId);
    this.webhookStatus.set('verified');
    
    this.currentPlan.set(this.plans()[2]); // Update local state
    this.subscriptionSuccess.set(true);
    this.isProcessing.set(false);
    
    // Clean URL
    this.router.navigate([], {
      queryParams: { payment_status: null, session_id: null },
      queryParamsHandling: 'merge'
    });
  }

  async selectPlan(plan: SubscriptionPlan): Promise<void> {
    if (this.checkRateLimit()) return;
    if (this.isProcessing() || plan.id === this.currentPlan().id) return;
    
    this.isProcessing.set(true);
    this.selectedPlan.set(plan);
    this.errorMessage.set(null);

    try {
      // 1. Create Checkout Session
      const sessionId = await this.stripeService.createCheckoutSession(plan.id);
      
      // 2. Redirect to Stripe
      await this.stripeService.redirectToCheckout(sessionId);
      
    } catch (error: any) {
      console.error('Payment Error:', error);
      this.errorMessage.set(error.message || 'An unexpected error occurred during checkout.');
      this.isProcessing.set(false);
      this.selectedPlan.set(null);
    }
  }

  changePlan(): void {
    this.selectedPlan.set(null);
    this.subscriptionSuccess.set(false);
    this.webhookStatus.set(null);
  }

  private checkRateLimit(): boolean {
    const now = Date.now();
    this.requestTimestamps = this.requestTimestamps.filter(t => now - t < this.RATE_LIMIT_WINDOW_MS);
    if (this.requestTimestamps.length >= this.RATE_LIMIT_COUNT) {
      this.isRateLimited.set(true);
      this.rateLimitMessage.set('Too many requests. Please wait 30 seconds.');
      setTimeout(() => this.isRateLimited.set(false), 30000);
      return true;
    }
    this.requestTimestamps.push(now);
    return false;
  }

  getButtonText(plan: SubscriptionPlan): string {
    if (plan.tierLevel === this.currentPlan().tierLevel) return 'Current Plan';
    if (plan.tierLevel > this.currentPlan().tierLevel) return 'Upgrade';
    return 'Downgrade';
  }
}
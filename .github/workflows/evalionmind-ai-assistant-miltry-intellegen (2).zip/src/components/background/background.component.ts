
import { Component, ChangeDetectionStrategy, AfterViewInit, OnDestroy, ElementRef, ViewChild, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';

declare var THREE: any;

@Component({
  selector: 'app-background',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule],
  template: `
    <div #canvasContainer class="fixed inset-0 w-full h-full z-[-1] bg-black pointer-events-none"></div>
    <div class="fixed inset-0 z-[-1] bg-[radial-gradient(circle_at_center,_transparent_0%,_#000000_100%)] opacity-80 pointer-events-none"></div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BackgroundComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvasContainer') private canvasContainer!: ElementRef;

  private renderer!: any;
  private scene!: any;
  private camera!: any;
  private particles!: any;
  private animationFrameId!: number;
  
  // Parallax State
  private targetX = 0;
  private targetY = 0;
  private windowHalfX = window.innerWidth / 2;
  private windowHalfY = window.innerHeight / 2;

  constructor(private ngZone: NgZone) {}

  ngAfterViewInit(): void {
    this.ngZone.runOutsideAngular(() => {
      this.initThree();
      this.animate();
      window.addEventListener('resize', this.onWindowResize);
      document.addEventListener('mousemove', this.onDocumentMouseMove);
      // Performance: Removed deviceorientation listener to save battery and cycles on mobile
    });
  }

  private initThree(): void {
    const container = this.canvasContainer.nativeElement;
    
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0x000000, 0.0008);

    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 1, 3000);
    this.camera.position.z = 1000;

    this.renderer = new THREE.WebGLRenderer({ antialias: false, alpha: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // Cap pixel ratio for performance
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    container.appendChild(this.renderer.domElement);

    this.createParticles();
  }

  private createParticles(): void {
    // Optimization: Reduced from 2000 to 400 to unblock main thread and improve click response
    const particleCount = 400; 
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const color = new THREE.Color();

    for (let i = 0; i < particleCount; i++) {
        const x = (Math.random() * 2 - 1) * 2000;
        const y = (Math.random() * 2 - 1) * 2000;
        const z = (Math.random() * 2 - 1) * 2000;

        positions[i * 3] = x;
        positions[i * 3 + 1] = y;
        positions[i * 3 + 2] = z;

        const isActive = Math.random() > 0.9;
        color.set(isActive ? '#10b981' : '#374151'); 

        colors[i * 3] = color.r;
        colors[i * 3 + 1] = color.g;
        colors[i * 3 + 2] = color.b;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({ 
      size: 4, // Slightly larger to compensate for fewer particles
      vertexColors: true,
      blending: THREE.AdditiveBlending,
      transparent: true,
      opacity: 0.8
    });

    this.particles = new THREE.Points(geometry, material);
    this.scene.add(this.particles);
  }

  private animate = () => {
    this.animationFrameId = requestAnimationFrame(this.animate);
    
    this.particles.rotation.x += 0.0002;
    this.particles.rotation.y += 0.0005;

    this.camera.position.x += (this.targetX - this.camera.position.x) * 0.05;
    this.camera.position.y += (-this.targetY - this.camera.position.y) * 0.05;

    this.camera.lookAt(this.scene.position);
    this.renderer.render(this.scene, this.camera);
  }

  private onWindowResize = () => {
    this.windowHalfX = window.innerWidth / 2;
    this.windowHalfY = window.innerHeight / 2;
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  private onDocumentMouseMove = (event: MouseEvent) => {
    this.targetX = (event.clientX - this.windowHalfX) * 0.5;
    this.targetY = (event.clientY - this.windowHalfY) * 0.5;
  }

  ngOnDestroy(): void {
    cancelAnimationFrame(this.animationFrameId);
    window.removeEventListener('resize', this.onWindowResize);
    document.removeEventListener('mousemove', this.onDocumentMouseMove);
    if (this.renderer) {
      this.renderer.dispose();
    }
  }
}

import { Component, ChangeDetectionStrategy, Input, inject, OnChanges, signal, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EvaluationReport, RoleBenchmark } from '../../models/evaluation.model';
import { EvaluationService } from '../../services/evaluation.service';
import { RadarChartComponent, RadarChartData } from '../ui/radar-chart/radar-chart.component';

@Component({
  selector: 'app-evaluation-report',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, RadarChartComponent],
  templateUrl: './evaluation-report.component.html',
  styleUrls: ['./evaluation-report.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EvaluationReportComponent implements OnChanges {
  @Input({ required: true }) report!: EvaluationReport;
  @Input() role: string = 'Senior Full-Stack Engineer'; // Default role, but can be passed in
  
  evaluationService = inject(EvaluationService);
  
  benchmark = signal<RoleBenchmark | null>(null);
  comparisons = signal<RadarChartData[]>([]);
  expandedQuestions = signal<Set<string>>(new Set());

  async ngOnChanges(changes: SimpleChanges): Promise<void> {
    if (changes['report'] && this.report) {
      await this.calculateComparisons();
    }
    if (changes['role'] && this.report) {
        await this.calculateComparisons(); // Recalculate if role changes
    }
  }

  toggleQuestionDetail(questionId: string): void {
    this.expandedQuestions.update(currentSet => {
      const newSet = new Set(currentSet);
      if (newSet.has(questionId)) {
        newSet.delete(questionId);
      } else {
        newSet.add(questionId);
      }
      return newSet;
    });
  }

  isQuestionExpanded(questionId: string): boolean {
    return this.expandedQuestions().has(questionId);
  }

  private async calculateComparisons(): Promise<void> {
    const roleData = await this.evaluationService.getRoleBenchmark(this.role);
    this.benchmark.set(roleData);

    const count = this.report.detailedAnalysis.length;
    if (count === 0) {
        this.comparisons.set([
          {
            label: 'Overall',
            candidateScore: this.report.overallScore,
            benchmarkScore: roleData.avgOverallScore,
          }
        ]);
        return;
    }

    // Calculate Candidate Averages
    const avgClarity = Math.round(this.report.detailedAnalysis.reduce((acc, curr) => acc + curr.clarity, 0) / count);
    const avgRelevance = Math.round(this.report.detailedAnalysis.reduce((acc, curr) => acc + curr.relevance, 0) / count);
    const avgTech = Math.round(this.report.detailedAnalysis.reduce((acc, curr) => acc + curr.technicalDepth, 0) / count);

    this.comparisons.set([
      {
        label: 'Overall',
        candidateScore: this.report.overallScore,
        benchmarkScore: roleData.avgOverallScore,
      },
      {
        label: 'Tech Depth',
        candidateScore: avgTech,
        benchmarkScore: roleData.avgTechnicalDepth,
      },
      {
        label: 'Clarity',
        candidateScore: avgClarity,
        benchmarkScore: roleData.avgClarity,
      },
      {
        label: 'Relevance',
        candidateScore: avgRelevance,
        benchmarkScore: roleData.avgRelevance,
      }
    ]);
  }

  getScoreColor(score: number): string {
    if (score >= 85) return 'text-green-500 border-green-500';
    if (score >= 60) return 'text-yellow-500 border-yellow-500';
    return 'text-red-500 border-red-500';
  }

  getProgressBarColor(score: number): string {
    if (score >= 85) return 'bg-green-500';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  }

  getRatingLabel(score: number): string {
    if (score >= 90) return 'ELITE';
    if (score >= 75) return 'PROFICIENT';
    if (score >= 50) return 'ADEQUATE';
    return 'COMPROMISED';
  }
}

import { Component, ChangeDetectionStrategy, inject, signal, computed, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonDirective } from '../../directives/button.directive';
import { VoidGlassComponent } from '../ui/void-glass.component';
import { AtsService } from '../../services/ats.service';
import { Candidate } from '../../models/ats.model';
import { CandidateRank } from '../../models/evaluation.model';
import { RankingService } from '../../services/ranking.service';

@Component({
  selector: 'app-candidate-ranking',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, FormsModule, ButtonDirective, VoidGlassComponent],
  templateUrl: './candidate-ranking.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CandidateRankingComponent {
  atsService = inject(AtsService);
  rankingService = inject(RankingService);

  jobDescription = signal('');
  selectedCandidateIds = signal<Set<string>>(new Set());
  rankedCandidates = signal<CandidateRank[] | null>(null);

  isLoading = this.rankingService.isLoading;
  error = this.rankingService.error;

  // Filter out candidates without a name or role for cleaner ranking input
  availableCandidates = computed(() => {
    return this.atsService.pipelineStages().flatMap(stage => 
      stage.candidates.filter(c => c.name && c.role)
    );
  });

  constructor() {
    // Effect to clear ranked candidates if available candidates change significantly
    effect(() => {
      this.availableCandidates(); // Depend on availableCandidates
      this.rankedCandidates.set(null); // Reset ranking
      this.selectedCandidateIds.set(new Set()); // Clear selections
    }, { allowSignalWrites: true });
  }

  toggleCandidateSelection(candidateId: string): void {
    this.selectedCandidateIds.update(currentIds => {
      const newSet = new Set(currentIds);
      if (newSet.has(candidateId)) {
        newSet.delete(candidateId);
      } else {
        newSet.add(candidateId);
      }
      return newSet;
    });
  }

  async performRanking(): Promise<void> {
    const selected = this.availableCandidates().filter(c => this.selectedCandidateIds().has(c.id));
    
    if (!this.jobDescription().trim()) {
      this.error.set('Job description is required to perform ranking.');
      return;
    }
    if (selected.length === 0) {
      this.error.set('Please select at least one candidate to rank.');
      return;
    }

    this.rankedCandidates.set(null); // Clear previous results
    this.error.set(null); // Clear previous errors

    // Pass the actual candidate objects to the service
    const results = await this.rankingService.rankCandidates(this.jobDescription(), selected);
    this.rankedCandidates.set(results);

    if (results) {
      // Optional: Update original candidates in ATS with their rank for display elsewhere
      this.atsService.pipelineStages.update(stages => {
        return stages.map(stage => ({
          ...stage,
          candidates: stage.candidates.map(candidate => {
            const ranked = results.find(r => r.candidateId === candidate.id);
            return ranked ? { ...candidate, rank: ranked.rank } : candidate;
          })
        }));
      });
    }
  }

  resetRanking(): void {
    this.jobDescription.set('');
    this.selectedCandidateIds.set(new Set());
    this.rankedCandidates.set(null);
    this.error.set(null);
  }

  getRankColor(rank: number, total: number): string {
    if (total <= 1) return 'text-green-500'; // Only one candidate is always rank 1
    const percentile = (rank - 1) / (total - 1); // 0 for rank 1, 1 for last rank

    if (percentile <= 0.25) return 'text-green-500'; // Top 25%
    if (percentile <= 0.5) return 'text-blue-400';  // Next 25%
    if (percentile <= 0.75) return 'text-yellow-500'; // Next 25%
    return 'text-red-500'; // Bottom 25%
  }
}
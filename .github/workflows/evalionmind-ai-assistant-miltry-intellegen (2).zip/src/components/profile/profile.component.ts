
import { Component, inject, signal, output, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { GlassModalComponent } from '../ui/glass-modal.component';
import { ButtonDirective } from '../../directives/button.directive';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, FormsModule, GlassModalComponent, ButtonDirective],
  templateUrl: './profile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProfileComponent {
  authService = inject(AuthService);
  // FIX: Explicitly type injected Router to resolve 'unknown' type error.
  private router: Router = inject(Router);

  formData = signal({
    name: this.authService.currentUser()?.name || '',
    avatarUrl: this.authService.currentUser()?.avatarUrl || ''
  });
  
  errorMessage = signal<string | null>(null);

  updateField(field: 'name' | 'avatarUrl', value: string) {
    this.formData.update(current => ({ ...current, [field]: value }));
    this.errorMessage.set(null);
  }

  async save(): Promise<void> {
    this.errorMessage.set(null);
    try {
      await this.authService.updateProfile(this.formData());
      this.navigateToDashboard();
    } catch (error: any) {
      console.error('[ProfileComponent] Error saving profile:', error);
      this.errorMessage.set(error.message || 'Failed to update profile.');
    }
  }

  cancel() {
    this.navigateToDashboard();
  }
  
  private navigateToDashboard(): void {
      const role = this.authService.currentUserRole();
      const path = role === 'company' ? '/company' : '/candidate';
      this.router.navigate([path]);
  }
}
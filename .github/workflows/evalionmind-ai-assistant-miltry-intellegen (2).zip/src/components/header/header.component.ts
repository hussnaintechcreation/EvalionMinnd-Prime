
import { Component, ChangeDetectionStrategy, output, input, signal, inject, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { User } from '../../models/shared.interfaces';
import { ButtonDirective } from '../../directives/button.directive';
import { LogoComponent } from '../ui/logo.component';
import { GlassModalComponent } from '../ui/glass-modal.component';

@Component({
  selector: 'app-header',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, ButtonDirective, LogoComponent, RouterLink, GlassModalComponent],
  templateUrl: './header.component.html',
  host: {
    '(document:click)': 'onDocumentClick($event)',
  },
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderComponent implements OnInit, OnDestroy {
  user = input.required<User | null>();
  logout = output<void>(); 
  goToProfile = output<void>();
  goToSettings = output<void>();
  
  showLogoutConfirm = signal(false);
  showCommandPalette = signal(false);
  isProfileMenuOpen = signal(false);
  currentTime = signal('');
  private timer: any;

  // FIX: Explicitly type injected Router to resolve 'unknown' type error.
  private router: Router = inject(Router);

  ngOnInit(): void {
    this.timer = setInterval(() => this.updateTime(), 1000);
    this.updateTime();
  }

  ngOnDestroy(): void {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  private updateTime(): void {
    const now = new Date();
    const pad = (n: number) => n.toString().padStart(2, '0');
    const timeString = `${pad(now.getUTCHours())}:${pad(now.getUTCMinutes())}:${pad(now.getUTCSeconds())} ZULU`;
    this.currentTime.set(timeString);
  }

  goHome(): void {
    const currentUser = this.user();
    if (currentUser) {
      const destination = currentUser.role === 'company' ? '/company' : '/candidate';
      this.router.navigate([destination]);
    } else {
      this.router.navigate(['/']);
    }
  }

  toggleProfileMenu(event: MouseEvent): void {
    event.stopPropagation();
    this.isProfileMenuOpen.update(v => !v);
  }

  onDocumentClick(event: MouseEvent): void {
    // Close the menu if the click is outside
    this.isProfileMenuOpen.set(false);
  }

  handleProfileClick(): void {
    this.goToProfile.emit();
    this.isProfileMenuOpen.set(false);
  }
  
  handleSettingsClick(): void {
    this.goToSettings.emit();
    this.isProfileMenuOpen.set(false);
  }

  handleDisconnectClick(): void {
    this.showLogoutConfirm.set(true);
    this.isProfileMenuOpen.set(false);
  }

  confirmLogout() {
    this.showLogoutConfirm.set(false);
    this.logout.emit();
  }
}
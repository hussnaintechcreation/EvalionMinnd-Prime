
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, Router } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { AuthService } from '../../services/auth.service';
import { UiService } from '../../services/ui.service';

@Component({
  selector: 'app-landing-layout',
  // Removed 'standalone: true' as it's the default in Angular v20+
  template: `
    <app-header 
      [user]="authService.currentUser()"
      (logout)="authService.logout()"
      (goToProfile)="handleGoToProfile()"
      (goToSettings)="handleGoToSettings()"
    />
    <main class="min-h-[calc(100vh-80px)]">
      <router-outlet />
    </main>
    <app-footer (aboutClick)="uiService.openAbout()" />
  `,
  imports: [
    CommonModule,
    RouterOutlet,
    HeaderComponent,
    FooterComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LandingLayoutComponent {
  authService = inject(AuthService);
  uiService = inject(UiService);
  // FIX: Explicitly type injected Router to resolve 'unknown' type error.
  router: Router = inject(Router);

  handleGoToProfile(): void {
    const user = this.authService.currentUser();
    if (user) {
        const path = user.role === 'company' ? '/company/profile' : '/candidate/profile';
        this.router.navigate([path]);
    } else {
        this.uiService.openLogin();
    }
  }

  handleGoToSettings(): void {
    const user = this.authService.currentUser();
    if (user) {
        const path = user.role === 'company' ? '/company/settings' : '/candidate/settings';
        this.router.navigate([path]);
    } else {
        // No settings for non-logged-in users, could open login as alternative
        this.uiService.openLogin();
    }
  }
}

import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AtsService } from '../../services/ats.service';
import { Candidate } from '../../models/ats.model';
import { ButtonDirective } from '../../directives/button.directive';
import { GlassModalComponent } from '../ui/glass-modal.component';
import { EvaluationReportComponent } from '../evaluation-report/evaluation-report.component';

@Component({
  selector: 'app-assessments',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, ButtonDirective, GlassModalComponent, EvaluationReportComponent],
  templateUrl: './assessments.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AssessmentsComponent {
  atsService = inject(AtsService);
  
  // Get all candidates who are in 'review' status or have an evaluation report
  candidatesUnderReview = computed(() => {
    const allStages = this.atsService.pipelineStages();
    const reviews: Candidate[] = [];
    allStages.forEach(stage => {
        stage.candidates.forEach(c => {
            if (c.status === 'review' || (c.evaluation && c.status !== 'hired' && c.status !== 'rejected')) {
                reviews.push(c);
            }
        });
    });
    return reviews;
  });

  completedHistory = computed(() => {
    const allStages = this.atsService.pipelineStages();
    const history: Candidate[] = [];
    allStages.forEach(stage => {
        stage.candidates.forEach(c => {
            if (c.status === 'hired' || c.status === 'rejected') {
                history.push(c);
            }
        });
    });
    return history;
  });

  selectedCandidate = signal<Candidate | null>(null);

  viewReport(candidate: Candidate): void {
    this.selectedCandidate.set(candidate);
  }

  closeReport(): void {
    this.selectedCandidate.set(null);
  }

  approveCandidate(candidate: Candidate): void {
    if(confirm(`Are you sure you want to APPROVE ${candidate.name}? This will generate their certificate.`)) {
        this.atsService.makeDecision(candidate.id, 'approve');
        this.closeReport();
    }
  }

  rejectCandidate(candidate: Candidate): void {
    if(confirm(`Are you sure you want to REJECT ${candidate.name}?`)) {
        this.atsService.makeDecision(candidate.id, 'reject');
        this.closeReport();
    }
  }
  
  getScoreColor(score: number): string {
    if (score >= 85) return 'text-green-500';
    if (score >= 60) return 'text-yellow-500';
    return 'text-red-500';
  }
}

import { Component, ChangeDetectionStrategy, signal, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VoidGlassComponent } from '../ui/void-glass.component';

interface Metric {
  label: string;
  value: number;
  unit: string;
  colorClass: string;
}

@Component({
  selector: 'app-system-health',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, VoidGlassComponent],
  templateUrl: './system-health.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SystemHealthComponent implements OnInit, OnDestroy {
  private updateInterval: any;

  // Signals for core metrics
  cpuLoad = signal(0);
  memoryUsage = signal(0);
  networkLatency = signal(0);
  activeNodes = signal(0);
  systemStatus = signal<'OPERATIONAL' | 'DEGRADED' | 'CRITICAL'>('OPERATIONAL');
  lastUpdatedTimestamp = signal('');

  ngOnInit(): void {
    this.randomizeMetrics();
    this.updateInterval = setInterval(() => this.randomizeMetrics(), 2000);
  }

  ngOnDestroy(): void {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }
  }

  private randomizeMetrics(): void {
    // Simulate realistic fluctuations
    this.cpuLoad.update(load => this.fluctuate(load, 15, 85, 5));
    this.memoryUsage.update(usage => this.fluctuate(usage, 30, 90, 3));
    this.networkLatency.update(latency => this.fluctuate(latency, 8, 45, 10));
    this.activeNodes.update(nodes => this.fluctuate(nodes, 8450, 8550, 20));

    // Determine overall system status
    if (this.cpuLoad() > 80 || this.memoryUsage() > 85) {
        this.systemStatus.set('CRITICAL');
    } else if (this.cpuLoad() > 65 || this.memoryUsage() > 70 || this.networkLatency() > 35) {
        this.systemStatus.set('DEGRADED');
    } else {
        this.systemStatus.set('OPERATIONAL');
    }
    
    this.lastUpdatedTimestamp.set(new Date().toISOString());
  }

  private fluctuate(currentValue: number, min: number, max: number, maxChange: number): number {
    let change = (Math.random() - 0.5) * maxChange * 2;
    let newValue = currentValue + change;
    newValue = Math.max(min, Math.min(max, newValue));
    return Math.round(newValue);
  }
  
  getColorClass(value: number): string {
    if (value > 80) return 'bg-red-500';
    if (value > 65) return 'bg-yellow-500';
    return 'bg-green-500';
  }

  getLatencyColor(value: number): string {
    if (value > 35) return 'text-red-500';
    if (value > 25) return 'text-yellow-500';
    return 'text-green-500';
  }

  getStatusColor(status: 'OPERATIONAL' | 'DEGRADED' | 'CRITICAL'): string {
    switch(status) {
        case 'OPERATIONAL': return 'text-green-500 border-green-500 bg-green-900/20';
        case 'DEGRADED': return 'text-yellow-500 border-yellow-500 bg-yellow-900/20';
        case 'CRITICAL': return 'text-red-500 border-red-500 bg-red-900/20';
    }
  }
}
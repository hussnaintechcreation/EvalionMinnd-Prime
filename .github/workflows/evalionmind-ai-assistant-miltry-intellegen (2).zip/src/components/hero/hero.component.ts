
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonDirective } from '../../directives/button.directive';
import { LogoComponent } from '../ui/logo.component';
import { UiService } from '../../services/ui.service';
import { UserRole } from '../../models/shared.interfaces';

@Component({
  selector: 'app-hero',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, ButtonDirective, LogoComponent],
  templateUrl: './hero.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeroComponent {
  uiService = inject(UiService);

  scrollTo(id: string) {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  openLoginModal(role: UserRole): void {
    this.uiService.openLogin(role);
  }
}
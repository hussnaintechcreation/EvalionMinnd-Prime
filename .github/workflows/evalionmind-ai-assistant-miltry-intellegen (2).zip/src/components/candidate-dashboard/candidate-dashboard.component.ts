
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ButtonDirective } from '../../directives/button.directive';
import { AuthService } from '../../services/auth.service';
import { CandidateService } from '../../services/candidate.service';

@Component({
  selector: 'app-candidate-dashboard',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, ButtonDirective],
  templateUrl: './candidate-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CandidateDashboardComponent {
  authService = inject(AuthService);
  candidateService = inject(CandidateService);
  // FIX: Explicitly type injected Router to resolve 'unknown' type error.
  router: Router = inject(Router);

  applications = this.candidateService.applications;

  startInterview(role: string) {
      this.router.navigate(['/candidate/interview']);
  }

  downloadCertificate() {
      this.router.navigate(['/candidate/certificate']);
  }

  getStatusColor(status: string): string {
      switch(status) {
          case 'approved': return 'text-green-500 border-green-500 bg-green-900/20';
          case 'rejected': return 'text-red-500 border-red-500 bg-red-900/20';
          case 'review': return 'text-yellow-500 border-yellow-500 bg-yellow-900/20';
          default: return 'text-blue-500 border-blue-500 bg-blue-900/20';
      }
  }

  getStatusLabel(status: string): string {
      switch(status) {
          case 'pending_interview': return 'Action Required';
          case 'approved': return 'Hired / Certified';
          default: return status.replace('_', ' ');
      }
  }
}
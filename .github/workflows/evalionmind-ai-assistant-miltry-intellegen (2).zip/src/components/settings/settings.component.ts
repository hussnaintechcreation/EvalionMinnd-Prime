
import { Component, ChangeDetectionStrategy, output, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonDirective } from '../../directives/button.directive';
import { FeatureFlagService } from '../../services/feature-flag.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-settings',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, FormsModule, ButtonDirective],
  templateUrl: './settings.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SettingsComponent {
  close = output<void>();
  featureFlagService = inject(FeatureFlagService);
  authService = inject(AuthService);

  // Settings State
  notificationsEnabled = signal(true);
  autoTranscription = signal(true);
  highContrastMode = signal(false);
  audioInputDevice = signal('default');

  saveSettings() {
    // In a real app, save to localStorage or backend
    console.log('Settings Saved:', {
        notifications: this.notificationsEnabled(),
        autoTranscription: this.autoTranscription(),
        highContrast: this.highContrastMode(),
        audioDevice: this.audioInputDevice()
    });
    this.close.emit();
  }

  toggleFeature(key: 'generativeToolkit' | 'fullstackEnhancer' | 'videoInterviews') {
      this.featureFlagService.toggleFeature(key);
  }
}
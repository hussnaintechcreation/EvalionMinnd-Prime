
import { Component, ChangeDetectionStrategy, inject, signal, ViewChild, ElementRef, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CertificateService } from '../../services/certificate.service';
import { ButtonDirective } from '../../directives/button.directive';
import { LogoComponent } from '../ui/logo.component';
import { CertificateData } from '../../models/certificate.model';

// Declare third-party libraries to satisfy TypeScript
declare var html2canvas: any;
declare var jspdf: any;

@Component({
  selector: 'app-certificate',
  // Removed 'standalone: true' as it's the default in Angular v20+
  imports: [CommonModule, ButtonDirective, LogoComponent],
  templateUrl: './certificate.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CertificateComponent {
  @ViewChild('certificateContainer') certificateContainer!: ElementRef;
  
  certificateService = inject(CertificateService);
  close = output<void>();

  certificateData = this.certificateService.getCertificateData;
  isProcessing = signal(false);

  async downloadCertificate(): Promise<void> {
    this.isProcessing.set(true);
    
    try {
      const { jsPDF } = jspdf;
      const element = this.certificateContainer.nativeElement;
      
      // Wait a moment to ensure all assets/fonts are rendered
      await new Promise(resolve => setTimeout(resolve, 500));

      const canvas = await html2canvas(element, { 
        scale: 2, // 2 is usually sufficient and faster than 3
        useCORS: true, // Crucial for external images like QR codes/Avatars
        logging: false,
        backgroundColor: '#0f172a', // Match the dark theme background
        allowTaint: true
      }); 
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'px',
        format: [canvas.width, canvas.height] // Match canvas dimensions exactly
      });
      
      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save(`EvalionMind_Certificate_${this.certificateData().candidateName.replace(/\s+/g, '_')}.pdf`);

    } catch (error) {
      console.error("Failed to generate PDF:", error);
    } finally {
      this.isProcessing.set(false);
    }
  }

  printCertificate(): void {
    window.print();
  }
}
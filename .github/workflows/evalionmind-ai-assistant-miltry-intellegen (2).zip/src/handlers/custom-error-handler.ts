
import { ErrorHandler, Injectable, inject, NgZone } from '@angular/core';
import { GlobalErrorHandlerService } from '../services/global-error-handler.service';

@Injectable()
export class CustomErrorHandler implements ErrorHandler {
  private errorHandlerService = inject(GlobalErrorHandlerService);
  private ngZone = inject(NgZone);

  handleError(error: unknown): void {
    // We run this inside the zone to make sure that UI changes (like showing the error toast)
    // are picked up by Angular's change detection.
    this.ngZone.run(() => {
      this.errorHandlerService.handleError(error, 'Unhandled Exception');
    });
  }
}

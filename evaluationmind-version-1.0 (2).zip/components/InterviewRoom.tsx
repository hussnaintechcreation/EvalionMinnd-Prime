
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect, useRef } from 'react';
import { motion as framerMotion, AnimatePresence } from 'framer-motion';
import { Question, ProctoringMetrics, User } from '../types';
import { CircularTimer, AudioVisualizer, NeuralWaveform } from './Visualizers';
import { ProctoringPanel } from './ProctoringPanel';
import { Mic, Cpu, Binary, Activity, Send, Timer, Shield, Camera, RefreshCw, AlertTriangle, Key, Bot, Wifi, Volume2, Lock } from 'lucide-react';
import { APIService, AIKernelError } from '../services';

const motion = framerMotion as any;

interface InterviewRoomProps {
  user: User;
  onComplete: (transcript: string, context: { text: string, answer?: string }[]) => void;
  onNavigate: (state: any) => void;
}

const AIInterviewerProfile = () => (
    <div className="relative w-full h-full bg-black flex flex-col items-center justify-center overflow-hidden">
        <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.3)_0%,transparent_70%)]"></div>
            <div className="absolute inset-0 bg-cyber-grid bg-[length:20px_20px]"></div>
        </div>
        
        <div className="relative">
            <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                className="w-32 h-32 border border-evalion-purple/40 rounded-full flex items-center justify-center"
            >
                <div className="w-24 h-24 border-2 border-evalion-purple/20 rounded-full flex items-center justify-center border-dashed"></div>
            </motion.div>
            <motion.div 
                animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="absolute inset-0 m-auto w-12 h-12 bg-evalion-purple rounded-full blur-xl"
            />
            <div className="absolute inset-0 m-auto flex items-center justify-center">
                <Bot size={40} className="text-evalion-purple drop-shadow-[0_0_15px_rgba(139,92,246,0.8)]" />
            </div>
        </div>
        
        <div className="mt-8 text-center relative z-10">
            <div className="text-[10px] font-mono text-evalion-purple uppercase tracking-[0.4em] font-black mb-1">Neural_Sentinel</div>
            <div className="text-[8px] font-mono text-evalion-textDim uppercase tracking-widest opacity-40">Orchestration_Mode: Active</div>
        </div>
    </div>
);

// Inlined Web Worker logic from transcriptProcessorWorker.js
const workerScript = `
    const TECH_CORRECTIONS = {
        'nest js': 'NestJS', 'nestjs': 'NestJS', 'prisma': 'Prisma', 'postgress': 'PostgreSQL', 'postgres': 'PostgreSQL',
        'typescript': 'TypeScript', 'javascript': 'JavaScript', 'cap theorem': 'CAP Theorem', 'zero trust': 'Zero-Trust',
        'micro expressions': 'micro-expressions', 'webrtc': 'WebRTC', 'kubernetes': 'Kubernetes', 'k8s': 'K8s',
        'docker': 'Docker', 'react': 'React', 'angular': 'Angular', 'backend': 'Backend', 'frontend': 'Frontend',
        'api': 'API', 'restful': 'RESTful', 'graphql': 'GraphQL', 'nosql': 'NoSQL', 'sql': 'SQL', 'agile': 'Agile', 'scrum': 'Scrum'
    };

    const FILLER_WORDS = [
        'um', 'uh', 'er', 'ah', 'like', 'okay', 'right', 'so', 'you know', 
        'basically', 'actually', 'literally', 'well', 'i mean', 'i guess'
    ];

    function applyNeuralCorrection(text) {
        let corrected = text;
        for (const [misspelled, correct] of Object.entries(TECH_CORRECTIONS)) {
            const regex = new RegExp(\`\\\\b\${misspelled}\\\\b\`, 'gi');
            corrected = corrected.replace(regex, correct);
        }
        return corrected;
    }

    function removeFillerWords(text) {
        const fillerRegex = new RegExp(\`\\\\b(\${FILLER_WORDS.join('|')})\\\\b\`, 'gi');
        return text.replace(fillerRegex, '').replace(/\\s\\s+/g, ' ').trim();
    }

    self.onmessage = (event) => {
        if (event.data.type === 'process_transcript_chunk') {
            const { chunk } = event.data;
            const correctedChunk = applyNeuralCorrection(chunk);
            const cleanedChunk = removeFillerWords(correctedChunk);
            
            self.postMessage({ 
                type: 'processed_transcript_chunk', 
                cleanedChunk
            });
        }
    };
`;

export const InterviewRoom: React.FC<InterviewRoomProps> = ({ user, onComplete, onNavigate }) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [fullTranscript, setFullTranscript] = useState<string>("");
  const [questionContext, setQuestionContext] = useState<{text: string, answer?: string}[]>([]);
  const [currentTranscript, setCurrentTranscript] = useState<string>("");
  const [interimTranscript, setInterimTranscript] = useState<string>("");
  const [speechStatus, setSpeechStatus] = useState<'IDLE' | 'LISTENING' | 'ERROR'>('IDLE');
  const [isThinking, setIsThinking] = useState(true);
  const [errorContext, setErrorContext] = useState<AIKernelError | null>(null);
  const [proctorMetrics, setProctorMetrics] = useState<ProctoringMetrics>({
    gaze: 'FOCUSED', expression: 'NEUTRAL', audioAnomaly: false, systemIntegrity: 'SECURE'
  });
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const recognitionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const workerRef = useRef<Worker | null>(null);
  const transcriptEndRef = useRef<HTMLDivElement>(null);
  const restartTimeoutRef = useRef<any>(null);

  // Refs for Speech Recognition stability
  const isThinkingRef = useRef(isThinking);
  const errorActiveRef = useRef(false);

  useEffect(() => { isThinkingRef.current = isThinking; }, [isThinking]);

  useEffect(() => {
    if (transcriptEndRef.current) {
        transcriptEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [currentTranscript, interimTranscript]);

  useEffect(() => {
    // Initialize Web Worker from Blob for technical correction logic
    try {
        const blob = new Blob([workerScript], { type: 'application/javascript' });
        const url = URL.createObjectURL(blob);
        workerRef.current = new Worker(url);
        workerRef.current.onmessage = (event) => {
          if (event.data.type === 'processed_transcript_chunk') {
              setCurrentTranscript(prev => (prev + " " + event.data.cleanedChunk).trim());
          }
        };
        // Clean up the URL when the component unmounts
        return () => URL.revokeObjectURL(url);
    } catch(e) {
        console.warn("Worker init failed. Performance might be degraded.", e);
    }

    // Camera/Audio Uplink
    navigator.mediaDevices.getUserMedia({ video: true, audio: true }).then(s => {
      streamRef.current = s;
      if (videoRef.current) videoRef.current.srcObject = s;
      fetchNextQuestion();
    }).catch(() => {
      onNavigate('DASHBOARD');
    });

    return () => {
      streamRef.current?.getTracks().forEach(t => t.stop());
      stopSpeechRecognition();
      workerRef.current?.terminate();
      if (restartTimeoutRef.current) clearTimeout(restartTimeoutRef.current);
    };
  }, []);

  const fetchNextQuestion = async () => {
    setIsThinking(true);
    setErrorContext(null);
    errorActiveRef.current = false;
    stopSpeechRecognition();
    
    try {
        const q = await APIService.generateNextQuestion('Senior Full Stack Engineer', questionContext);
        setQuestions(prev => [...prev, q]);
        if (questions.length > 0) setCurrentQuestionIndex(prev => prev + 1);
        setTimeLeft(q.durationSeconds);
        setCurrentTranscript("");
        setInterimTranscript("");
        setIsThinking(false);
        // Delay speech start slightly to ensure the candidate has read the prompt
        setTimeout(startSpeechRecognition, 800);
    } catch (e: any) {
        const kernelErr = e as AIKernelError;
        setErrorContext(kernelErr);
        errorActiveRef.current = true;
        setIsThinking(false);
    }
  };

  const startSpeechRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSpeechStatus('ERROR');
      return;
    }

    try {
      stopSpeechRecognition();
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
          setSpeechStatus('LISTENING');
          errorActiveRef.current = false;
      };
      
      recognition.onresult = (event: any) => {
          let final_chunk = '';
          let interim_chunk = '';

          for (let i = event.resultIndex; i < event.results.length; ++i) {
              if (event.results[i].isFinal) {
                  final_chunk += event.results[i][0].transcript;
              } else {
                  interim_chunk += event.results[i][0].transcript;
              }
          }

          if (final_chunk) {
              if (workerRef.current) {
                // Route through worker for technical correction
                workerRef.current.postMessage({ type: 'process_transcript_chunk', chunk: final_chunk });
              } else {
                setCurrentTranscript(prev => (prev + " " + final_chunk).trim());
              }
              setInterimTranscript('');
          } else {
              setInterimTranscript(interim_chunk);
          }
      };

      recognition.onend = () => {
          setSpeechStatus('IDLE');
          // Intelligent restart logic: Only restart if we are not "thinking" or in error state
          if (!isThinkingRef.current && !errorActiveRef.current) {
              restartTimeoutRef.current = setTimeout(() => {
                  if (!isThinkingRef.current && !errorActiveRef.current) startSpeechRecognition();
              }, 300);
          }
      };

      recognition.onerror = (event: any) => {
          if (event.error === 'aborted' || event.error === 'no-speech') return;
          if (event.error === 'not-allowed') {
              setSpeechStatus('ERROR');
              errorActiveRef.current = true;
          }
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (e) {
      setSpeechStatus('ERROR');
    }
  };

  const stopSpeechRecognition = () => {
      if (recognitionRef.current) {
          recognitionRef.current.onend = null;
          recognitionRef.current.onresult = null;
          recognitionRef.current.onerror = null;
          try { recognitionRef.current.stop(); } catch(e) {}
          recognitionRef.current = null;
      }
      if (restartTimeoutRef.current) clearTimeout(restartTimeoutRef.current);
      setSpeechStatus('IDLE');
  };

  useEffect(() => {
    if (isThinking || timeLeft <= 0 || errorContext) return;
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) { handleNextQuestion(); return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isThinking, timeLeft, errorContext]);

  const handleNextQuestion = () => {
    const currentQ = questions[currentQuestionIndex];
    if (!currentQ) return;

    const finalAnswer = (currentTranscript + " " + interimTranscript).trim();
    const qaPair = `Q: ${currentQ.text}\nA: ${finalAnswer || "(No answer provided)"}\n\n`;
    
    const newFullTranscript = fullTranscript + qaPair;
    const newQuestionContext = [...questionContext, { text: currentQ.text, answer: finalAnswer }];
    
    setFullTranscript(newFullTranscript);
    setQuestionContext(newQuestionContext);
    setCurrentTranscript("");
    setInterimTranscript("");

    if (currentQuestionIndex >= 2) { // 3 question limit for demo/production flow
      onComplete(newFullTranscript, newQuestionContext);
    } else {
      fetchNextQuestion();
    }
  };

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="w-full max-w-[95rem] mx-auto min-h-screen grid grid-cols-1 lg:grid-cols-12 gap-6 pt-24 pb-8 px-6">
      
      {/* LEFT: Neural Telemetry */}
      <div className="lg:col-span-3 flex flex-col gap-6 order-2 lg:order-1">
          <ProctoringPanel metrics={proctorMetrics} />
          
          <div className="glass-panel p-6 rounded-[2.5rem] bg-evalion-purple/5 border-evalion-purple/20 flex flex-col gap-6 shadow-2xl">
              <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[10px] font-mono text-evalion-purple uppercase tracking-[0.3em] font-black">
                      <Volume2 size={14} /> Logic_Decibels
                  </div>
                  <Wifi size={14} className="text-evalion-purple opacity-40" />
              </div>
              <AudioVisualizer isActive={speechStatus === 'LISTENING' && !isThinking && !errorContext} level={isThinking ? 0 : 60} />
          </div>

          <div className="glass-panel p-6 rounded-[2.5rem] mt-auto">
              <div className="flex items-center justify-between mb-4">
                  <div className="text-[10px] font-mono text-evalion-teal uppercase tracking-[0.3em] font-black">Secure_Vault</div>
                  <Lock size={12} className="text-evalion-teal" />
              </div>
              <div className="text-[9px] font-mono text-evalion-textDim leading-relaxed uppercase opacity-60">
                  Real-time packets are RSA-4096 encrypted before neural ingestion.
              </div>
          </div>
      </div>

      {/* CENTER: Main Interaction Stage */}
      <div className="lg:col-span-6 flex flex-col gap-6 order-1 lg:order-2">
          <div className="grid grid-cols-2 gap-4 h-64 md:h-80">
              <div className="relative bg-black rounded-[2.5rem] overflow-hidden border-2 border-evalion-teal/20 shadow-2xl">
                  <video ref={videoRef} autoPlay muted className="w-full h-full object-cover opacity-80" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20"></div>
                  <div className="absolute top-4 left-4 flex items-center gap-2 px-2.5 py-1 bg-evalion-teal/10 border border-evalion-teal/30 rounded-full backdrop-blur-md">
                      <div className="w-1.5 h-1.5 rounded-full bg-evalion-teal animate-pulse"></div>
                      <span className="text-[8px] font-mono text-evalion-teal font-black uppercase tracking-widest">Candidate_Uplink</span>
                  </div>
              </div>

              <div className="relative bg-black rounded-[2.5rem] overflow-hidden border-2 border-evalion-purple/20 shadow-2xl">
                  <AIInterviewerProfile />
                  <div className="absolute top-4 right-4 flex items-center gap-2 px-2.5 py-1 bg-evalion-purple/10 border border-evalion-purple/30 rounded-full backdrop-blur-md">
                      <Shield size={10} className="text-evalion-purple" />
                      <span className="text-[8px] font-mono text-evalion-purple font-black uppercase tracking-widest">AI_Decision_Engine</span>
                  </div>
              </div>
          </div>

          <div className="flex-1 flex flex-col min-h-0">
              <AnimatePresence mode="wait">
                  {errorContext ? (
                      <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-panel p-12 rounded-[2.5rem] flex flex-col items-center justify-center gap-8 flex-1 border-evalion-danger/30 shadow-2xl text-center">
                          <AlertTriangle size={72} className="text-evalion-danger animate-bounce" />
                          <div className="text-evalion-danger font-mono text-xl tracking-[0.2em] uppercase font-black">{errorContext.message}</div>
                          <button onClick={fetchNextQuestion} className="px-12 py-4 bg-white text-black font-black font-mono rounded-2xl hover:bg-evalion-teal transition-all uppercase text-xs">
                             Restart_Protocol
                          </button>
                      </motion.div>
                  ) : isThinking ? (
                      <motion.div key="thinking" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-panel p-12 rounded-[2.5rem] flex flex-col items-center justify-center gap-8 flex-1 border-white/5">
                          <RefreshCw size={56} className="text-evalion-teal animate-spin" />
                          <div className="text-evalion-teal font-mono text-xs tracking-[0.6em] uppercase font-black">Processing_Logic_Vector</div>
                          <NeuralWaveform active={true} />
                      </motion.div>
                  ) : (
                      <motion.div key="question" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-6 flex-1 min-h-0">
                          <div className="glass-panel p-8 rounded-[2.5rem] border-l-4 border-l-evalion-teal shadow-2xl flex items-center justify-between gap-6">
                              <div className="flex-1">
                                  <div className="flex items-center gap-3 mb-4">
                                      <span className="text-[9px] font-black font-mono bg-evalion-teal/10 text-evalion-teal px-2.5 py-1 rounded border border-evalion-teal/20 uppercase">Question_0{currentQuestionIndex + 1}</span>
                                      <span className="text-[9px] font-mono text-evalion-textDim uppercase tracking-widest font-black opacity-40">{currentQuestion?.category}</span>
                                  </div>
                                  <h3 className="text-xl md:text-2xl font-black text-white uppercase tracking-tight leading-snug">{currentQuestion?.text}</h3>
                              </div>
                              <CircularTimer timeLeft={timeLeft} totalTime={currentQuestion?.durationSeconds || 60} />
                          </div>

                          <div className="glass-panel rounded-[2.5rem] flex-1 flex flex-col overflow-hidden shadow-2xl bg-black/40 border-white/5">
                              <div className="px-8 py-3.5 border-b border-white/5 flex justify-between items-center bg-black/60">
                                  <div className="flex items-center gap-8">
                                      <div className="flex items-center gap-2 text-[9px] font-mono text-evalion-teal/40 font-black uppercase tracking-[0.2em]">
                                          <Binary size={14} /> Real-time_Stream
                                      </div>
                                      <div className="flex items-center gap-3">
                                          <Mic size={14} className={`${speechStatus === 'LISTENING' ? 'text-evalion-success animate-pulse' : 'text-evalion-danger opacity-40'}`} />
                                          <span className="text-[9px] font-mono text-evalion-textDim uppercase tracking-widest font-black">{speechStatus}_ACTIVE</span>
                                      </div>
                                  </div>
                                  <div className="flex items-center gap-2 px-2 py-0.5 rounded border border-evalion-success/20 bg-evalion-success/5">
                                      <div className="w-1 h-1 rounded-full bg-evalion-success animate-ping"></div>
                                      <span className="text-[8px] font-mono text-evalion-success uppercase font-black">Encrypted</span>
                                  </div>
                              </div>
                              
                              <div className="flex-1 p-8 font-mono text-base text-white/90 overflow-y-auto custom-scrollbar relative bg-black/20" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.6' numOctaves='3'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.03'/%3E%3C/svg%3E")` }}>
                                  <p className="leading-relaxed tracking-tight whitespace-pre-wrap">
                                      <span className="text-evalion-teal/40 mr-4 select-none font-black italic">TX://</span>
                                      {currentTranscript} 
                                      <span className="text-evalion-textDim/40 italic ml-1">{interimTranscript}</span>
                                      {speechStatus === 'LISTENING' && (
                                          <motion.span 
                                            animate={{ opacity: [0, 1, 0] }} 
                                            transition={{ repeat: Infinity, duration: 1 }} 
                                            className="inline-block w-2.5 h-5 bg-evalion-teal ml-2 align-middle shadow-[0_0_15px_#00F0FF]" 
                                          />
                                      )}
                                  </p>
                                  <div ref={transcriptEndRef} className="h-4" />
                              </div>

                              <div className="px-8 py-5 bg-black/40 border-t border-white/5 flex justify-between items-center">
                                  <div className="text-[10px] font-mono text-white/30 flex items-center gap-3 uppercase tracking-widest font-black">
                                      <Timer size={14} /> Packet_Buffer: Stable
                                  </div>
                                  <button 
                                      onClick={handleNextQuestion}
                                      className="px-10 py-3.5 bg-evalion-teal text-evalion-bg font-black rounded-2xl flex items-center justify-center gap-4 hover:bg-white transition-all shadow-[0_0_30px_rgba(0,240,255,0.2)] active:scale-95 text-[11px] uppercase tracking-[0.2em]"
                                  >
                                      COMMIT_RESPONSE <Send size={16} />
                                  </button>
                              </div>
                          </div>
                      </motion.div>
                  )}
              </AnimatePresence>
          </div>
      </div>

      {/* RIGHT: Integrity Status */}
      <div className="lg:col-span-3 flex flex-col gap-6 order-3">
          <div className="glass-panel p-6 rounded-[2.5rem] bg-evalion-bg/60 border border-white/10">
              <h3 className="text-[11px] font-black text-white uppercase tracking-[0.4em] mb-6 font-mono flex items-center gap-3">
                  <Activity size={16} className="text-evalion-teal" /> Neural_Continuity
              </h3>
              <div className="space-y-6">
                  {['Technical Accuracy', 'Problem Solving', 'Communication'].map((metric, idx) => (
                      <div key={idx} className="space-y-2">
                          <div className="flex justify-between text-[10px] font-mono text-white/40 uppercase tracking-widest font-black">
                              <span>{metric}</span>
                              <span className="text-evalion-teal">{80 + (idx * 5)}%</span>
                          </div>
                          <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                              <motion.div initial={{ width: 0 }} animate={{ width: `${80 + (idx * 5)}%` }} className="h-full bg-evalion-teal shadow-[0_0_10px_#00F0FF] opacity-60" />
                          </div>
                      </div>
                  ))}
              </div>
          </div>

          <div className="glass-panel p-6 rounded-[2.5rem] border-white/5 bg-black/40">
              <div className="flex items-center justify-between mb-4">
                  <div className="text-[10px] font-mono text-evalion-purple uppercase tracking-[0.3em] font-black flex items-center gap-2">
                      <Shield size={14} /> Sentinel_Trust
                  </div>
              </div>
              <div className="space-y-3">
                  <div className="flex justify-between items-center glass-panel-item p-3 rounded-xl border border-white/5">
                      <span className="text-[9px] font-mono text-white/40 uppercase tracking-widest">Post_Refresh</span>
                      <span className="text-[10px] font-mono text-evalion-success font-black">NOMINAL</span>
                  </div>
                  <button 
                    onClick={handleNextQuestion}
                    className="w-full mt-2 py-2.5 rounded-xl border border-evalion-purple/20 text-[9px] font-mono font-black text-evalion-purple uppercase tracking-widest hover:bg-evalion-purple/10 transition-all flex items-center justify-center gap-2"
                  >
                      <Key size={12} /> Force_Uplink_Sync
                  </button>
              </div>
          </div>
      </div>
    </div>
  );
};


/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect, useRef } from 'react';
import { motion as framerMotion, AnimatePresence } from 'framer-motion';
import { Shield, Fingerprint, Activity, Lock, RefreshCw, AlertTriangle, CheckCircle2, Scan } from 'lucide-react';

const motion = framerMotion as any;

interface BiometricGateProps {
  onSuccess: () => void;
  onCancel: () => void;
  title?: string;
}

export const BiometricGate: React.FC<BiometricGateProps> = ({ onSuccess, onCancel, title = "Neural_Identity_Verification" }) => {
  const [step, setStep] = useState<'IDLE' | 'SCANNING' | 'ANALYZING' | 'SUCCESS' | 'ERROR'>('IDLE');
  const [progress, setProgress] = useState(0);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    initCamera();
    return () => {
      stream?.getTracks().forEach(t => t.stop());
    };
  }, []);

  const initCamera = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: true });
      setStream(s);
      if (videoRef.current) videoRef.current.srcObject = s;
      setStep('SCANNING');
    } catch (err) {
      setStep('ERROR');
    }
  };

  useEffect(() => {
    if (step === 'SCANNING') {
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setStep('ANALYZING');
            return 100;
          }
          return prev + 1;
        });
      }, 30);
      return () => clearInterval(interval);
    }
  }, [step]);

  useEffect(() => {
    if (step === 'ANALYZING') {
      setTimeout(() => {
        setStep('SUCCESS');
        setTimeout(onSuccess, 1500);
      }, 2000);
    }
  }, [step]);

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-evalion-bg/95 backdrop-blur-xl">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-2xl glass-panel p-10 rounded-[3rem] border-2 border-evalion-teal/30 shadow-[0_0_100px_rgba(0,240,255,0.15)] relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-cyber-grid bg-[size:40px_40px] opacity-10"></div>
        
        <div className="relative z-10 flex flex-col items-center">
            <div className="flex items-center gap-3 mb-8">
                <Shield className="text-evalion-teal animate-pulse" size={24} />
                <h2 className="text-2xl font-black text-white uppercase tracking-tighter font-mono">{title}</h2>
            </div>

            <div className="relative w-full aspect-video bg-black rounded-3xl overflow-hidden border-2 border-evalion-teal/20 mb-8 group">
                <video ref={videoRef} autoPlay muted className="w-full h-full object-cover grayscale opacity-60" />
                
                <AnimatePresence>
                    {step === 'SCANNING' && (
                        <>
                            <motion.div 
                                className="absolute inset-0 z-20 pointer-events-none"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                exit={{ opacity: 0 }}
                            >
                                <motion.div 
                                    className="absolute left-0 right-0 h-1 bg-evalion-teal shadow-[0_0_30px_#00F0FF]"
                                    animate={{ top: ['0%', '100%', '0%'] }}
                                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                                />
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <div className="w-64 h-64 border-2 border-evalion-teal/40 rounded-full animate-ping opacity-20"></div>
                                    <div className="w-48 h-48 border border-white/10 rounded-full animate-pulse"></div>
                                </div>
                            </motion.div>
                            <div className="absolute bottom-4 left-4 right-4 flex flex-col gap-2">
                                <div className="flex justify-between text-[10px] font-mono text-evalion-teal uppercase tracking-widest font-black">
                                    <span>Mapping_Face_Vectors</span>
                                    <span>{progress}%</span>
                                </div>
                                <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden border border-white/10">
                                    <motion.div className="h-full bg-evalion-teal" style={{ width: `${progress}%` }} />
                                </div>
                            </div>
                        </>
                    )}

                    {step === 'ANALYZING' && (
                        <motion.div 
                            className="absolute inset-0 z-30 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center text-center"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                        >
                            <RefreshCw size={48} className="text-evalion-teal animate-spin mb-4" />
                            <div className="text-[10px] font-mono text-white uppercase tracking-[0.4em] font-black animate-pulse">Neural_Cross_Verification...</div>
                        </motion.div>
                    )}

                    {step === 'SUCCESS' && (
                        <motion.div 
                            className="absolute inset-0 z-30 bg-evalion-success/10 backdrop-blur-sm flex flex-col items-center justify-center text-center"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                        >
                            <CheckCircle2 size={64} className="text-evalion-success mb-4 animate-bounce" />
                            <div className="text-xl font-black text-evalion-success font-mono uppercase tracking-[0.2em]">Access_Granted</div>
                        </motion.div>
                    )}

                    {step === 'ERROR' && (
                        <motion.div 
                            className="absolute inset-0 z-30 bg-evalion-danger/20 backdrop-blur-sm flex flex-col items-center justify-center text-center p-8"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                        >
                            <AlertTriangle size={64} className="text-evalion-danger mb-4" />
                            <div className="text-xl font-black text-evalion-danger font-mono uppercase tracking-[0.2em] mb-2">Auth_Mismatch</div>
                            <p className="text-xs text-white/60 font-mono uppercase">Neural signature rejected or camera unavailable.</p>
                            <button onClick={initCamera} className="mt-6 px-6 py-2 bg-white text-black font-black font-mono text-[10px] rounded uppercase tracking-widest">Retry_Uplink</button>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>

            <div className="grid grid-cols-3 gap-4 w-full mb-10">
                <div className="glass-panel-item p-4 rounded-2xl flex flex-col items-center gap-2 border border-white/5">
                    <Activity size={16} className="text-evalion-teal" />
                    <span className="text-[8px] font-mono text-white/40 uppercase tracking-widest">Heartbeat</span>
                    <span className="text-[10px] font-mono text-white font-black">72_BPM</span>
                </div>
                <div className="glass-panel-item p-4 rounded-2xl flex flex-col items-center gap-2 border border-white/5">
                    <Scan size={16} className="text-evalion-teal" />
                    <span className="text-[8px] font-mono text-white/40 uppercase tracking-widest">Liveness</span>
                    <span className="text-[10px] font-mono text-white font-black">STABLE</span>
                </div>
                <div className="glass-panel-item p-4 rounded-2xl flex flex-col items-center gap-2 border border-white/5">
                    <Fingerprint size={16} className="text-evalion-teal" />
                    <span className="text-[8px] font-mono text-white/40 uppercase tracking-widest">Auth_Mode</span>
                    <span className="text-[10px] font-mono text-white font-black">BIO_V2</span>
                </div>
            </div>

            <div className="flex gap-4 w-full">
                <button 
                    onClick={onCancel}
                    className="flex-1 py-4 border border-white/10 text-evalion-textDim font-mono text-[10px] font-black uppercase tracking-widest rounded-2xl hover:bg-white/5 transition-all"
                >
                    Terminate_Protocol
                </button>
            </div>
        </div>
      </motion.div>
    </div>
  );
};


/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import { motion as framerMotion, AnimatePresence } from 'framer-motion';
import { Logo } from './Logo';
import { User, AppState, SocketStatus } from '../types';
import { 
    ChevronLeft, 
    Shield, 
    Activity, 
    Command, 
    LayoutDashboard, 
    User as UserProfileIcon, 
    CreditCard, 
    BarChartHorizontal, 
    Power, 
    RefreshCw, 
    CheckCircle, 
    AlertTriangle, 
    XCircle,
    Cpu,
    Zap,
    Network
} from 'lucide-react';

const motion = framerMotion as any;

const SocketStatusIndicator: React.FC<{ status: SocketStatus }> = ({ status }) => {
    const statusConfig = {
        'CONNECTING': { text: 'SYNCING...', icon: RefreshCw, color: 'text-evalion-teal', animate: 'animate-spin' },
        'CONNECTED': { text: 'LIVE SYNC', icon: CheckCircle, color: 'text-evalion-success', animate: '' },
        'UNSTABLE': { text: 'UNSTABLE', icon: AlertTriangle, color: 'text-yellow-500', animate: 'animate-pulse' },
        'DISCONNECTED': { text: 'OFFLINE', icon: XCircle, color: 'text-evalion-danger', animate: 'animate-pulse' }
    };
    const { text, icon: Icon, color, animate } = statusConfig[status];

    return (
        <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-[9px] font-mono font-black uppercase tracking-widest transition-all ${
            status === 'CONNECTED' ? 'bg-evalion-success/5 border-evalion-success/10 text-evalion-success/70' :
            status === 'CONNECTING' ? 'bg-evalion-teal/5 border-evalion-teal/10 text-evalion-teal/70' :
            status === 'UNSTABLE' ? 'bg-yellow-500/5 border-yellow-500/10 text-yellow-500/70' :
            'bg-evalion-danger/5 border-evalion-danger/10 text-evalion-danger/70'
        }`}>
            <Icon size={12} className={`${color} ${animate}`} />
            {text}
        </div>
    );
};

interface HeaderProps {
  user: User | null;
  state: AppState;
  historyLength: number;
  socketStatus: SocketStatus;
  onNavigate: (state: AppState) => void;
  onBack: () => void;
  onLogout: () => void;
  onProfile: () => void;
  onOpenCommandHub: () => void;
}

const navLinks: { name: string, state: AppState, icon?: any }[] = [
    { name: 'Platform', state: 'PLATFORM' },
    { name: 'Solutions', state: 'SOLUTIONS' },
    { name: 'Pricing', state: 'PRICING' },
    { name: 'Enterprise', state: 'ENTERPRISE' },
    { name: 'Docs', state: 'DOCS' },
    { name: 'About', state: 'ABOUT' },
    { name: 'Contact', state: 'CONTACT' },
    { name: 'Status', state: 'STATUS', icon: Network },
];

export const Header: React.FC<HeaderProps> = ({ 
  user, state, historyLength, socketStatus, onNavigate, onBack, onLogout, onProfile, onOpenCommandHub
}) => {
  const isLanding = state === 'LANDING';
  const isCritical = ['INTERVIEW', 'VERIFICATION', 'ANALYSIS'].includes(state);

  return (
    <header className="fixed top-4 left-1/2 -translate-x-1/2 w-[calc(100%-3rem)] max-w-7xl z-[100] h-16 glass-panel rounded-full px-6 flex justify-between items-center transition-all border border-white/10 shadow-2xl overflow-hidden">
      {/* Background Scanning Animation */}
      <div className="absolute inset-0 bg-cyber-grid bg-[size:30px_30px] opacity-[0.03] pointer-events-none"></div>
      
      <div className="flex items-center gap-6 relative z-10">
        {/* Conditional Back Button */}
        {historyLength > 0 && !isCritical && !isLanding && (
            <motion.button 
                whileHover={{ scale: 1.1, x: -2 }}
                whileTap={{ scale: 0.9 }}
                onClick={onBack}
                className="p-1.5 hover:bg-white/10 rounded-full text-evalion-textDim hover:text-white transition-all group"
            >
                <ChevronLeft size={20} />
            </motion.button>
        )}
        
        <div onClick={() => !isCritical && onNavigate('LANDING')} className="cursor-pointer">
          <Logo size="sm" />
        </div>
      </div>

      {/* Global Navigation */}
      {!user && !isCritical && (
        <nav className="hidden lg:flex items-center gap-1 relative z-10">
          {navLinks.map(link => {
            const isActive = state === link.state;
            return (
              <button 
                  key={link.state}
                  onClick={() => onNavigate(link.state)}
                  className={`relative px-4 py-2 text-[9px] font-mono tracking-[0.2em] uppercase transition-all rounded-full group ${isActive ? 'text-evalion-teal font-black' : 'text-evalion-textDim hover:text-white'}`}
              >
                  <span className="relative z-10 flex items-center gap-2">
                    {link.state === 'STATUS' && <div className="w-1.5 h-1.5 rounded-full bg-evalion-success animate-pulse shadow-[0_0_8px_#05FF00]"></div>}
                    {link.name}
                  </span>
                  {isActive && (
                    <motion.div 
                        layoutId="navActive"
                        className="absolute inset-0 bg-evalion-teal/10 border border-evalion-teal/30 rounded-full"
                        transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                  {!isActive && (
                    <div className="absolute inset-0 bg-white/0 group-hover:bg-white/5 rounded-full transition-colors" />
                  )}
              </button>
            );
          })}
          <div className="w-px h-6 bg-white/10 mx-3"></div>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('AUTH')}
            className="px-6 py-2 bg-gradient-to-r from-evalion-purple/80 to-evalion-purple border border-evalion-purple/30 text-white font-black uppercase tracking-widest rounded-full hover:shadow-[0_0_20px_rgba(139,92,246,0.4)] transition-all text-[10px] flex items-center gap-2 shadow-lg"
          >
              <Zap size={12} fill="currentColor" /> Access_ID
          </motion.button>
        </nav>
      )}

      {/* Logged In State */}
      {user && (
        <div className="flex items-center gap-4 relative z-10">
          <div className="hidden xl:block">
            <SocketStatusIndicator status={socketStatus} />
          </div>

          <button 
            onClick={onOpenCommandHub}
            className="flex items-center gap-3 px-4 py-2 bg-black/40 hover:bg-black/60 rounded-full border border-white/10 text-white/40 hover:text-evalion-teal transition-all group shadow-inner"
            title="Search Neural Hub (⌘K)"
          >
              <Command size={14} className="group-hover:rotate-12 transition-transform" />
              <span className="text-[10px] font-mono uppercase tracking-[0.2em] hidden md:block font-black">Neural Hub</span>
              <div className="hidden md:flex items-center gap-1.5 border-l border-white/10 pl-3">
                  <span className="text-[9px] font-mono opacity-40">⌘K</span>
              </div>
          </button>
          
          <div className="relative group">
            <button 
              className="flex items-center gap-3 p-1 pr-4 rounded-full bg-evalion-surface border border-white/10 hover:border-evalion-teal/40 transition-all cursor-pointer shadow-lg"
            >
              <div className="relative">
                <img 
                    src={user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`} 
                    className="w-8 h-8 rounded-full border-2 border-evalion-teal/30" 
                    alt="Profile" 
                />
                <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-evalion-success border-2 border-evalion-surface rounded-full"></div>
              </div>
              <div className="text-left hidden md:block">
                  <div className="text-[10px] font-black text-white leading-none mb-0.5 uppercase tracking-tighter">{user.name}</div>
                  <div className="text-[8px] font-mono text-evalion-teal/60 uppercase leading-none font-black">{user.role}</div>
              </div>
            </button>
            
            {/* Dropdown Menu */}
            <div 
              className="absolute top-full right-0 mt-4 w-72 glass-panel rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-white/10 p-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 origin-top-right z-50 scale-95 group-hover:scale-100"
            >
              <div className="p-5 border-b border-white/5 bg-white/5 rounded-t-2xl">
                <div className="text-xs font-black text-white uppercase tracking-widest">{user.name}</div>
                <div className="text-[9px] font-mono text-evalion-textDim truncate mt-1 opacity-60 uppercase">{user.email}</div>
                <div className="mt-3 inline-flex items-center gap-2 px-2 py-0.5 bg-evalion-teal/10 border border-evalion-teal/20 rounded text-[8px] font-mono text-evalion-teal font-black uppercase">
                    Access: {user.role === 'RECRUITER' ? 'ROOT_ADMIN' : 'CANDIDATE_NODE'}
                </div>
              </div>
              
              <div className="p-2 space-y-1 font-mono">
                <button onClick={() => onNavigate('DASHBOARD')} className="w-full text-left flex items-center gap-4 p-3 rounded-xl hover:bg-evalion-teal/10 text-evalion-textDim hover:text-white transition-all group/item">
                  <LayoutDashboard size={16} className="group-hover/item:text-evalion-teal" /> 
                  <span className="text-[10px] font-black uppercase tracking-widest">Dashboard</span>
                </button>
                <button onClick={() => onNavigate('PROFILE')} className="w-full text-left flex items-center gap-4 p-3 rounded-xl hover:bg-evalion-teal/10 text-evalion-textDim hover:text-white transition-all group/item">
                  <UserProfileIcon size={16} className="group-hover/item:text-evalion-teal" /> 
                  <span className="text-[10px] font-black uppercase tracking-widest">Profile Config</span>
                </button>
                {user.role === 'RECRUITER' && (
                  <button onClick={() => onNavigate('BILLING')} className="w-full text-left flex items-center gap-4 p-3 rounded-xl hover:bg-evalion-teal/10 text-evalion-textDim hover:text-white transition-all group/item">
                    <CreditCard size={16} className="group-hover/item:text-evalion-teal" /> 
                    <span className="text-[10px] font-black uppercase tracking-widest">Billing & Nodes</span>
                  </button>
                )}
                <button onClick={() => onNavigate('STATUS')} className="w-full text-left flex items-center gap-4 p-3 rounded-xl hover:bg-evalion-teal/10 text-evalion-textDim hover:text-white transition-all group/item">
                  <BarChartHorizontal size={16} className="group-hover/item:text-evalion-teal" /> 
                  <span className="text-[10px] font-black uppercase tracking-widest">System Health</span>
                </button>
              </div>
              
              <div className="p-2 border-t border-white/5">
                <button onClick={onLogout} className="w-full text-left flex items-center gap-4 p-3 rounded-xl hover:bg-evalion-danger/10 text-evalion-danger/60 hover:text-evalion-danger transition-all group/item">
                  <Power size={16} /> 
                  <span className="text-[10px] font-black uppercase tracking-widest">Terminate Session</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Critical State UI */}
      {isCritical && (
          <div className="flex items-center gap-3 relative z-10">
              <div className="flex items-center gap-2 px-4 py-1.5 bg-evalion-danger/10 border border-evalion-danger/30 rounded-full text-evalion-danger text-[9px] font-mono font-black animate-pulse uppercase tracking-[0.2em] shadow-[0_0_15px_rgba(255,42,109,0.2)]">
                  <Activity size={12} /> Buffer_Active
              </div>
          </div>
      )}
    </header>
  );
};

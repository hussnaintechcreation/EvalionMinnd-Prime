
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { Component, ErrorInfo, ReactNode, useState, useEffect } from 'react';
import { AlertTriangle, RefreshCw, Terminal, ShieldAlert, WifiOff, CloudOff, Key, Lock, Cpu } from 'lucide-react';
import { motion as framerMotion } from 'framer-motion';

const motion = framerMotion as any;

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

/**
 * BLOCKS APP IF API KEY IS MISSING OR INVALID
 * Provides a "hot-swap" capability by forcing a reload to pick up a new key.
 */
// Fix: children must be optional to support using ApiKeyGuard as a full-page status screen
export const ApiKeyGuard = ({ children }: { children?: ReactNode }) => {
  const [isKeyValid, setIsKeyValid] = useState<boolean>(!!process.env.API_KEY);

  useEffect(() => {
      const checkKey = () => setIsKeyValid(!!process.env.API_KEY);
      window.addEventListener('focus', checkKey);
      return () => window.removeEventListener('focus', checkKey);
  }, []);

  if (!isKeyValid) {
    return (
      <div className="min-h-screen bg-[#010409] text-[#E6EDF3] flex flex-col items-center justify-center p-6 font-sans relative overflow-hidden">
          {/* Ambient Neural Background */}
          <div className="absolute inset-0 z-0 pointer-events-none opacity-20">
              <div className="absolute inset-0 bg-cyber-grid bg-[size:40px_40px]"></div>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-5xl aspect-square bg-gradient-to-tr from-evalion-teal/20 via-transparent to-evalion-purple/20 rounded-full blur-[160px]" />
          </div>

          <div className="relative z-10 max-w-xl w-full">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                className="glass-panel border-2 border-yellow-500/50 bg-[#0d1117]/90 p-12 rounded-[3rem] shadow-[0_0_100px_rgba(255,165,0,0.1)] backdrop-blur-3xl relative overflow-hidden"
              >
                  <div className="absolute top-0 left-0 right-0 h-1.5 bg-yellow-500 opacity-20 bg-[repeating-linear-gradient(45deg,transparent,transparent_10px,#000_10px,#000_20px)]"></div>
                  
                  <div className="flex flex-col items-center text-center">
                      <div className="mb-10 relative">
                          <div className="w-28 h-28 bg-yellow-500/10 rounded-full flex items-center justify-center border-2 border-yellow-500/30 animate-pulse">
                              <Lock size={56} className="text-yellow-500" />
                          </div>
                          <motion.div 
                             animate={{ rotate: 360 }}
                             transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                             className="absolute -inset-4 border border-dashed border-yellow-500/20 rounded-full"
                          />
                      </div>

                      <h1 className="text-4xl md:text-5xl font-black text-white mb-4 uppercase tracking-tighter leading-none">
                          Kernel_Access <span className="text-yellow-500">Denied</span>
                      </h1>
                      
                      <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 font-mono text-[10px] font-black uppercase tracking-[0.3em] mb-10">
                          <Cpu size={14} /> Mission_Critical_Protocol
                      </div>

                      <p className="text-evalion-textDim font-mono text-sm leading-relaxed max-w-lg mb-12 uppercase tracking-wide">
                          The autonomous evaluation engine is currently locked. The AI Kernel requires a validated <span className="text-white font-bold">API_KEY</span> in the environment to establish a neural downlink.
                          <br/><br/>
                          <span className="text-[10px] opacity-60">Status: awaiting_deployment_parameters</span>
                      </p>

                      <div className="flex flex-col w-full gap-4">
                        <button 
                            onClick={() => window.location.reload()}
                            className="group relative w-full py-5 bg-yellow-500 text-black font-black font-mono rounded-2xl overflow-hidden transition-all hover:shadow-[0_0_40px_rgba(255,165,0,0.4)] active:scale-[0.98] cursor-pointer"
                        >
                            <div className="relative z-10 flex items-center justify-center gap-4 uppercase tracking-[0.2em] text-xs">
                                <RefreshCw size={18} className="group-hover:rotate-180 transition-transform duration-700" /> 
                                REBOOT_DOWNLINK
                            </div>
                        </button>
                        
                        <div className="flex items-center justify-center gap-6 opacity-40 mt-4">
                            <Key size={16} />
                            <div className="h-[1px] w-12 bg-white/20"></div>
                            <Terminal size={16} />
                        </div>
                      </div>
                  </div>
              </motion.div>
          </div>
      </div>
    );
  }

  return <>{children}</>;
};

/**
 * CATCHES CRITICAL RENDERING ERRORS
 */
export class SystemErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error, errorInfo: null };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    this.setState({ errorInfo });
    console.error("SystemGuard CRITICAL FAILURE:", error, errorInfo);
  }

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      const { error, errorInfo } = this.state;
      return (
        <div className="min-h-screen bg-[#010409] text-[#E6EDF3] flex flex-col items-center justify-center p-6 font-sans relative overflow-hidden selection:bg-[#FF2A6D] selection:text-white">
          <div className="absolute inset-0 z-0 pointer-events-none opacity-10">
            <div className="absolute inset-0 bg-[linear-gradient(rgba(255,42,109,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(255,42,109,0.1)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
          </div>
          
          <div className="relative z-10 max-w-2xl w-full">
            <div className="glass-panel border-2 border-[#FF2A6D] bg-[#0d1117]/90 p-12 rounded-[2rem] shadow-[0_0_50px_rgba(255,42,109,0.15)] backdrop-blur-xl relative overflow-hidden">
               <div className="absolute top-0 left-0 right-0 h-2 bg-[#FF2A6D] bg-[repeating-linear-gradient(45deg,transparent,transparent_10px,#000_10px,#000_20px)] opacity-50"></div>

               <div className="flex flex-col items-center text-center">
                  <div className="mb-8 relative">
                      <div className="w-24 h-24 bg-[#FF2A6D]/10 rounded-full flex items-center justify-center border border-[#FF2A6D]/30 animate-pulse">
                          <ShieldAlert size={48} className="text-[#FF2A6D]" />
                      </div>
                  </div>

                  <h1 className="text-4xl md:text-5xl font-black text-white mb-4 uppercase tracking-tighter">
                      System Critical <span className="text-[#FF2A6D]">Failure</span>
                  </h1>
                  
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#FF2A6D]/10 border border-[#FF2A6D]/20 text-[#FF2A6D] font-mono text-xs font-bold uppercase tracking-widest mb-8">
                      <AlertTriangle size={12} /> Runtime_Exception_Detected
                  </div>

                  <p className="text-[#8B949E] font-mono text-sm leading-relaxed max-w-lg mb-10">
                      The application kernel encountered an unrecoverable error. Safety protocols have engaged to prevent data corruption. 
                      <br/><br/>
                      <span className="text-white bg-white/10 px-2 py-1 rounded border border-white/5">{error?.message || 'Unknown Error Vector'}</span>
                  </p>

                  <button 
                      onClick={this.handleReload}
                      className="px-10 py-4 bg-[#FF2A6D] text-white font-black font-mono rounded-xl hover:scale-[1.02] active:scale-95 shadow-[0_0_30px_rgba(255,42,109,0.4)] cursor-pointer"
                  >
                      <div className="flex items-center gap-3 uppercase tracking-[0.2em] text-xs">
                          <RefreshCw size={16} /> Reboot_System
                      </div>
                  </button>
               </div>

               <div className="mt-12 border-t border-white/5 pt-8 w-full text-left">
                  <div className="bg-black/40 rounded-xl border border-white/5 p-4 font-mono text-[10px] text-[#8B949E] overflow-x-auto max-h-40 custom-scrollbar">
                      <div className="flex items-center gap-2 text-[#FF2A6D] mb-2 uppercase font-bold sticky top-0 bg-[#0d1117]/0">
                          <Terminal size={12} /> Stack_Trace_Log
                      </div>
                      <pre className="opacity-70 whitespace-pre-wrap select-text">
                          {errorInfo?.componentStack || error?.stack || 'No stack trace available.'}
                      </pre>
                  </div>
               </div>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

/**
 * MONITORS NETWORK CONNECTIVITY
 */
export const NetworkStatusGuard = () => {
    const [isOnline, setIsOnline] = useState(navigator.onLine);

    useEffect(() => {
        const handleOnline = () => setIsOnline(true);
        const handleOffline = () => setIsOnline(false);
        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);
        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, []);

    if (isOnline) return null;

    return (
        <div className="fixed bottom-0 left-0 right-0 z-[9999] bg-[#FF2A6D] text-white py-3 px-4 text-center font-mono text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-3 shadow-[0_-5px_20px_rgba(255,42,109,0.3)] animate-pulse">
            <CloudOff size={16} /> Network_Uplink_Severed // Attempting Reconnection...
        </div>
    );
};




import { ChangeDetectionStrategy, Component, signal, ViewChild, ElementRef, AfterViewInit, OnDestroy, inject, Renderer2, NgZone, effect, OnInit } from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { User } from './models/user.model';
import { InterviewComponent } from './components/interview/interview.component';
import { IntroComponent } from './components/intro/intro.component';
import { LoginComponent, LoginView } from './components/login/login.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { SettingsComponent } from './components/settings/settings.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AdminDashboardComponent } from './components/admin/admin-dashboard.component';
import { InterviewHistoryItem } from './models/interview.model';
import { ChatbotComponent } from './components/chatbot/chatbot.component';
import { ImageEditorComponent } from './components/image-editor/image-editor.component';
import { ContactComponent } from './components/contact/contact.component';
import { TourComponent } from './components/tour/tour.component';
import { GlobalErrorService } from './services/global-error.service';
import { BackgroundComponent } from './components/background/background.component';
import { WorkflowComponent } from './components/workflow/workflow.component';
import { CapabilitiesComponent } from './components/capabilities/capabilities.component';
import { PricingComponent } from './components/pricing/pricing.component';
import { TerminalComponent } from './components/terminal/terminal.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { ResourcesComponent } from './components/rewrite-system/resources/resources.component';
import { AuthService } from './services/auth.service';
import { AppState } from './types';
import { MockBackendService } from './services/mock-backend.service';
import { Subscription } from 'rxjs';
import { MotionDesignerComponent } from './components/motion-designer/motion-designer.component';
import { RewriteSystemComponent } from './components/rewrite-system/rewrite-system.component';
import { FeatureGeneratorComponent } from './components/feature-generator/feature-generator.component';
import { ValidatorComponent } from './components/validator/validator.component';
import { AboutComponent } from './components/about/about.component';
import { PrivacyComponent } from './components/legal/privacy.component';
import { TermsComponent } from './components/legal/terms.component';
import { SecurityComponent } from './components/legal/security.component';
import { TestimonialsComponent } from './components/testimonials/testimonials.component';
import { FullstackEnhancerComponent } from './components/fullstack-enhancer/fullstack-enhancer.component';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    FormsModule,
    HeaderComponent, 
    FooterComponent,
    IntroComponent, 
    LoginComponent, 
    DashboardComponent, 
    AdminDashboardComponent, 
    InterviewComponent, 
    SettingsComponent, 
    ChatbotComponent, 
    ImageEditorComponent, 
    ContactComponent,
    TourComponent,
    WorkflowComponent,
    CapabilitiesComponent,
    PricingComponent,
    TerminalComponent,
    CheckoutComponent,
    BackgroundComponent,
    ResourcesComponent,
    AboutComponent,
    MotionDesignerComponent,
    RewriteSystemComponent,
    FeatureGeneratorComponent,
    ValidatorComponent,
    PrivacyComponent,
    TermsComponent,
    SecurityComponent,
    TestimonialsComponent,
    FullstackEnhancerComponent
  ],
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    .page-container {
      transition: opacity 0.5s cubic-bezier(0.4, 0.0, 0.2, 1), transform 0.5s cubic-bezier(0.4, 0.0, 0.2, 1), filter 0.5s ease-out;
      opacity: 1;
      transform: translateY(0);
      filter: blur(0);
      will-change: opacity, transform, filter;
    }
    
    .page-container.is-transitioning {
      opacity: 0;
      transform: translateY(20px);
      filter: blur(8px);
    }
  `]
})
export class AppComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('pageContainer') pageContainer!: ElementRef<HTMLElement>;

  errorService: GlobalErrorService = inject(GlobalErrorService);
  private renderer2: Renderer2 = inject(Renderer2);
  private ngZone: NgZone = inject(NgZone);
  private document: Document = inject(DOCUMENT);
  private authService: AuthService = inject(AuthService);
  private mockBackend: MockBackendService = inject(MockBackendService); 
  
  appState = signal<AppState>('intro');
  currentUser = signal<User | null>(null);
  selectedRole = signal<string | null>(null);
  showTour = signal(false);
  showFullstackEnhancer = signal(false);
  isNavigating = signal(false);
  showLogoutConfirmation = signal(false);
  gpuWarning = signal<string | null>(null);
  
  // Performance Signals
  performanceTier = signal<'high' | 'medium' | 'low'>('high');
  fps = signal(0);
  loadTime = signal(0);
  memoryUsage = signal(0); // In MB
  
  initialLoginView = signal<LoginView>('login');
  private postLoginRedirectState = signal<AppState | null>(null);
  sessionInterviewHistory = signal<InterviewHistoryItem[]>([]);
  private sessionsSubscription: Subscription | null = null;
  private authSubscription: Subscription | null = null;
  selectedPlan = signal<{name: string, price: number} | null>(null);
  billingCycleForCheckout = signal<'monthly' | 'annually'>('monthly');
  appFontSize = signal<'small' | 'normal' | 'large'>('normal');
  highContrastMode = signal(false);
  appTheme = signal<'dark' | 'light' | 'futuristic'>('dark');
  backgroundBrightness = signal(1.0);
  backgroundDensity = signal(1.0);
  backgroundSpeed = signal(1.0);

  // Feedback Modal Signals
  showFeedbackModal = signal(false);
  feedbackType = signal<'suggestion' | 'bug' | 'other'>('suggestion');
  feedbackMessage = signal('');
  feedbackEmail = signal('');
  isSubmittingFeedback = signal(false);
  feedbackSubmissionStatus = signal<'idle' | 'success' | 'error'>('idle');

  private transitionTimeoutId: any;
  private perfMonitorInterval: any;

  // Route Guard Configuration
  private readonly protectedRoutes: AppState[] = [
    'dashboard', 
    'admin-dashboard', 
    'interview', 
    'settings', 
    'image-editor', 
    'checkout', 
    'terminal', 
    'motion-designer', 
    'rewrite-system', 
    'feature-generator', 
    'validator'
  ];

  constructor() {
    effect(() => {
        this.applyAccessibilitySettings();
        // Pre-fill feedback email if user is logged in
        if (this.currentUser()) {
            this.feedbackEmail.set(this.currentUser()!.email);
        } else {
            this.feedbackEmail.set('');
        }
    });

    this.sessionsSubscription = this.mockBackend.sessions$.subscribe(sessions => {
      this.sessionInterviewHistory.set(sessions);
    });

    this.authSubscription = this.authService.currentUser$.subscribe(user => {
      this.currentUser.set(user);
      // Post-auth re-verification of route
      if (!user && this.protectedRoutes.includes(this.appState())) {
        this.handleNavigation('intro');
      }
    });
  }

  ngOnInit(): void {
    if (typeof localStorage !== 'undefined') {
      const storedFontSize = localStorage.getItem('evalionmind_font_size') as 'small' | 'normal' | 'large';
      if (storedFontSize) this.appFontSize.set(storedFontSize);
      
      const storedContrast = localStorage.getItem('evalionmind_high_contrast');
      if (storedContrast) this.highContrastMode.set(JSON.parse(storedContrast));

      const storedTheme = localStorage.getItem('evalionmind_theme') as 'dark' | 'light' | 'futuristic';
      if (storedTheme) this.appTheme.set(storedTheme);
      
      const storedBrightness = localStorage.getItem('evalionmind_background_brightness');
      if (storedBrightness) this.backgroundBrightness.set(parseFloat(storedBrightness));
      
      const storedDensity = localStorage.getItem('evalionmind_background_density');
      if (storedDensity) this.backgroundDensity.set(parseFloat(storedDensity));
      
      const storedSpeed = localStorage.getItem('evalionmind_background_speed');
      if (storedSpeed) this.backgroundSpeed.set(parseFloat(storedSpeed));
    }
  }
  
  ngAfterViewInit(): void {
    this.initializePerformanceMonitoring();
  }

  ngOnDestroy(): void {
    this.sessionsSubscription?.unsubscribe();
    this.authSubscription?.unsubscribe();
    if (this.transitionTimeoutId) {
      clearTimeout(this.transitionTimeoutId);
    }
    if (this.perfMonitorInterval) {
        clearInterval(this.perfMonitorInterval);
    }
  }

  private initializePerformanceMonitoring(): void {
    if (typeof window === 'undefined') return;

    // 1. Initial Hardware Check
    this.checkGpuCapability();

    // 2. Measure Load Time
    setTimeout(() => {
        if (window.performance && window.performance.getEntriesByType) {
            const navEntries = window.performance.getEntriesByType('navigation');
            if (navEntries.length > 0) {
                const navEntry = navEntries[0] as PerformanceNavigationTiming;
                const load = Math.round(navEntry.loadEventEnd || navEntry.domComplete || 0);
                this.loadTime.set(load > 0 ? load : Math.round(performance.now())); 
            }
        }
    }, 0);

    // 3. Runtime Monitoring Loop (FPS & Memory)
    this.ngZone.runOutsideAngular(() => {
        let lastTime = performance.now();
        let frames = 0;
        let fpsHistory: number[] = [];

        const monitorLoop = () => {
            const now = performance.now();
            frames++;

            if (now - lastTime >= 1000) {
                const currentFps = Math.round((frames * 1000) / (now - lastTime));
                
                this.ngZone.run(() => {
                    this.fps.set(currentFps);
                    this.checkMemoryUsage();
                    this.adjustTierBasedOnRuntime(currentFps, fpsHistory);
                });

                frames = 0;
                lastTime = now;
            }

            requestAnimationFrame(monitorLoop);
        };

        requestAnimationFrame(monitorLoop);
    });
  }

  private checkGpuCapability(): void {
    if (typeof window === 'undefined' || !this.document) return;
    const canvas = this.renderer2.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    
    if (!gl) {
      this.gpuWarning.set('Critical: WebGL not available. Visual fidelity significantly reduced.');
      this.performanceTier.set('low');
      return;
    }

    if (typeof navigator !== 'undefined' && navigator.hardwareConcurrency) {
        if (navigator.hardwareConcurrency <= 4) {
            this.performanceTier.set('medium');
        } else {
            this.performanceTier.set('high');
            this.gpuWarning.set(null);
        }
    } else {
        this.performanceTier.set('high'); 
    }
  }

  private checkMemoryUsage(): void {
      if ((performance as any).memory) {
          const usedJSHeapSize = (performance as any).memory.usedJSHeapSize;
          const usedMB = Math.round(usedJSHeapSize / 1024 / 1024);
          this.memoryUsage.set(usedMB);
      }
  }

  private adjustTierBasedOnRuntime(currentFps: number, history: number[]): void {
      history.push(currentFps);
      if (history.length > 5) history.shift(); 

      const avgFps = history.reduce((a, b) => a + b, 0) / history.length;
      const currentTier = this.performanceTier();

      if (avgFps < 25 && currentTier !== 'low') {
          this.performanceTier.set('low');
      } else if (avgFps < 45 && avgFps >= 25 && currentTier === 'high') {
          this.performanceTier.set('medium');
      }
  }

  // --- Route Guard & Navigation Logic ---
  handleNavigation(newState: AppState): void {
    if (this.appState() === newState) return;

    // Authentication Guard
    if (this.protectedRoutes.includes(newState) && !this.currentUser()) {
      console.warn(`[Access Control] Unauthorized attempt to access: ${newState}. Redirecting.`);
      
      this.postLoginRedirectState.set(newState); // Store intended destination for post-login

      // UX Decision: If user is exploring (intro/about), explicitly guide to Login if they hit a protected action.
      // If they are just landing or being redirected, fallback to 'intro' as a safe harbor.
      if (this.appState() === 'intro' || this.appState() === 'about' || this.appState() === 'contact') {
        this.initialLoginView.set('login');
        newState = 'login';
      } else {
        newState = 'intro';
      }
      
      // Prevent redundant transition if already on target fallback
      if (this.appState() === newState) return;
    }

    this.isNavigating.set(true);
    if (this.pageContainer) {
      this.renderer2.addClass(this.pageContainer.nativeElement, 'is-transitioning');
    }

    if (this.transitionTimeoutId) {
      clearTimeout(this.transitionTimeoutId);
    }

    this.transitionTimeoutId = setTimeout(() => {
      this.ngZone.run(() => {
        this.appState.set(newState);
        if (typeof window !== 'undefined') {
          window.scrollTo(0, 0);
        }
        setTimeout(() => {
          this.isNavigating.set(false);
          if (this.pageContainer) {
            this.renderer2.removeClass(this.pageContainer.nativeElement, 'is-transitioning');
          }
          this.transitionTimeoutId = null;
        }, 50);
      });
    }, 500); 
  }
  
  private applyAccessibilitySettings(): void {
    if (typeof this.document !== 'undefined') {
      const root = this.document.documentElement;
      this.renderer2.setAttribute(root, 'data-theme', this.appTheme());
      root.classList.remove('font-small', 'font-normal', 'font-large');
      if (this.appFontSize() === 'small') root.classList.add('font-small');
      else if (this.appFontSize() === 'large') root.classList.add('font-large');
      else root.classList.add('font-large'); // Corrected typo in original
      
      if (this.highContrastMode()) {
        root.classList.add('high-contrast');
      } else {
        root.classList.remove('high-contrast');
      }
    }
  }

  handleLoginSuccess(user: User): void {
    this.currentUser.set(user);
    const redirectState = this.postLoginRedirectState();
    
    if (redirectState) {
      this.handleNavigation(redirectState);
      this.postLoginRedirectState.set(null); 
    } else {
      // Default routing based on role
      if (user.role === 'company' || user.role === 'interviewer') {
        this.handleNavigation('admin-dashboard'); 
      } else { 
        this.handleNavigation('dashboard'); 
      }
    }
  }

  handleSignOutRequest(): void {
    this.showLogoutConfirmation.set(true);
  }

  handleSignUpRequest(): void {
    this.initialLoginView.set('signup');
    this.handleNavigation('login');
  }

  confirmSignOut(): void {
    this.authService.logout();
    this.handleNavigation('intro');
    this.showLogoutConfirmation.set(false);
  }

  cancelSignOut(): void {
    this.showLogoutConfirmation.set(false);
  }

  handleStartInterview(role: string): void {
    this.selectedRole.set(role);
    this.handleNavigation('interview');
  }

  handleInterviewFinished(historyItem: InterviewHistoryItem | null): void {
    if (historyItem) {
      this.mockBackend.saveSession(historyItem);
    }
    this.handleNavigation('dashboard');
  }
  
  handleSelectPlan(event: {plan: {name: string, price: number}, cycle: 'monthly' | 'annually'}): void {
      this.selectedPlan.set(event.plan);
      this.billingCycleForCheckout.set(event.cycle);
      this.handleNavigation('checkout');
  }

  handlePaymentSuccess(): void {
    this.handleNavigation('dashboard');
  }

  handleProfileUpdate(updates: Partial<User>): void {
    if (this.currentUser()) {
      this.currentUser.update(current => ({...current, ...updates}) as User);
    }
  }

  handleAccessibilitySettingsChanged(settings: any): void {
      this.appFontSize.set(settings.fontSize);
      this.highContrastMode.set(settings.highContrast);
      this.appTheme.set(settings.theme);
      this.backgroundBrightness.set(settings.brightness);
      this.backgroundDensity.set(settings.density);
      this.backgroundSpeed.set(settings.speed);
  }

  handlePracticeUplink(): void {
    if (this.currentUser()) {
        if (this.currentUser()?.role === 'company' || this.currentUser()?.role === 'interviewer') {
            this.handleNavigation('admin-dashboard');
        } else {
            this.handleNavigation('dashboard');
        }
    } else {
        this.initialLoginView.set('login');
        this.handleNavigation('login');
    }
  }

  handleStartTour(): void {
      this.showTour.set(true);
  }
  
  handleTourFinished(): void {
    this.showTour.set(false);
  }

  dismissGpuWarning(): void {
      this.gpuWarning.set(null);
  }
  
  reloadApp(isRecoverable: boolean): void {
    if (typeof window !== 'undefined') {
        if (!isRecoverable) {
            if (typeof localStorage !== 'undefined') localStorage.clear();
            if (typeof sessionStorage !== 'undefined') sessionStorage.clear();
        }
        window.location.reload();
    }
  }

  submitFeedback(): void {
      if (!this.feedbackMessage().trim()) return;
      this.isSubmittingFeedback.set(true);
      this.feedbackSubmissionStatus.set('idle');
      // Mock submission
      setTimeout(() => {
          this.isSubmittingFeedback.set(false);
          this.feedbackSubmissionStatus.set('success');
          // Reset form and close modal after a delay
          setTimeout(() => {
              this.showFeedbackModal.set(false);
              this.feedbackMessage.set('');
              // Do not clear email, it's pre-filled
              this.feedbackSubmissionStatus.set('idle');
          }, 2500);
      }, 1500);
  }
}

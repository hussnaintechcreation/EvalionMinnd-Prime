
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

// This component is a placeholder to resolve a file path and duplicate selector issue.
// The active AdminDashboardComponent is located at 'src/components/admin/admin-dashboard.component.ts'.
@Component({
  selector: 'app-unused-admin-dashboard-placeholder',
  standalone: true,
  imports: [CommonModule],
  template: `<!-- This is an unused placeholder component. -->`,
})
export class UnusedAdminDashboardPlaceholderComponent {}

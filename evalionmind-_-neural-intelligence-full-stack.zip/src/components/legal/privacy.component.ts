

import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogoComponent } from '../logo/logo.component';

@Component({
  selector: 'app-privacy',
  imports: [CommonModule, LogoComponent],
  template: `
    <div class="w-full max-w-5xl mx-auto px-6 pt-32 pb-20 animate-glitch-in relative">
      <button (click)="back.emit()" class="absolute top-24 left-6 text-sm font-tech text-slate-400 hover:text-white flex items-center gap-2 uppercase tracking-widest transition-colors" data-interactive>
        &larr; Return to Base
      </button>

      <header class="mb-12 border-b border-white/10 pb-8">
        <div class="flex items-center gap-4 mb-4">
            <app-logo [size]="48"></app-logo>
            <h1 class="text-4xl font-display font-black text-white uppercase tracking-widest">
                Data <span class="text-[var(--color-neon-cyan)]">Privacy</span> Protocol
            </h1>
        </div>
        <p class="text-sm font-tech text-slate-400 max-w-2xl uppercase tracking-wider">
            Last Updated: 2024.05.20 // Classification: PUBLIC
        </p>
      </header>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Navigation / Table of Contents -->
        <div class="lg:col-span-1">
            <div class="panel-obsidian p-6 sticky top-24">
                <h3 class="text-xs font-bold text-white uppercase tracking-widest mb-4 border-b border-white/10 pb-2">Directives</h3>
                <ul class="space-y-3 text-sm font-sans text-slate-400">
                    <li class="flex items-center gap-2 text-[var(--color-neon-cyan)]">
                        <span class="w-1 h-1 bg-[var(--color-neon-cyan)] rounded-full"></span> Data Collection
                    </li>
                    <li class="flex items-center gap-2 hover:text-white transition-colors cursor-pointer">
                        <span class="w-1 h-1 bg-slate-600 rounded-full"></span> Biometric Processing
                    </li>
                    <li class="flex items-center gap-2 hover:text-white transition-colors cursor-pointer">
                        <span class="w-1 h-1 bg-slate-600 rounded-full"></span> AI Analysis
                    </li>
                    <li class="flex items-center gap-2 hover:text-white transition-colors cursor-pointer">
                        <span class="w-1 h-1 bg-slate-600 rounded-full"></span> Data Retention
                    </li>
                </ul>
            </div>
        </div>

        <!-- Content -->
        <div class="lg:col-span-2 space-y-8">
            <section class="panel-obsidian p-8 border-l-2 border-[var(--color-neon-cyan)]">
                <h2 class="text-xl font-display font-bold text-white mb-4 uppercase">1. Data Collection Vector</h2>
                <p class="text-slate-300 text-sm leading-relaxed mb-4">
                    EvalionMind collects specific telemetry to perform human capital assessments. This includes but is not limited to:
                </p>
                <ul class="list-disc pl-5 text-slate-400 text-sm space-y-2">
                    <li><strong class="text-white">Identity Credentials:</strong> Name, Email, Professional Designation.</li>
                    <li><strong class="text-white">Audio/Visual Stream:</b> Real-time video and audio feeds during interview simulations for non-verbal analysis.</li>
                    <li><strong class="text-white">Technical Output:</b> Code snippets, whiteboard diagrams, and verbal responses generated during sessions.</li>
                </ul>
            </section>

            <section class="panel-obsidian p-8">
                <h2 class="text-xl font-display font-bold text-white mb-4 uppercase">2. Biometric & Neural Processing</h2>
                <p class="text-slate-300 text-sm leading-relaxed mb-4">
                    Our proprietary Neural Engine processes video feeds to extract micro-expressions, posture confidence, and eye contact metrics.
                </p>
                <div class="bg-[rgba(var(--rgb-neon-magenta),0.1)] border border-[var(--color-neon-magenta)]/30 p-4 rounded text-xs text-[var(--color-neon-magenta)] font-mono">
                    WARNING: Biometric templates are transient. They are generated in real-time RAM and are NOT stored permanently in our databases unless explicit consent for "Long-term Neural Profiling" is granted.
                </div>
            </section>

            <section class="panel-obsidian p-8">
                <h2 class="text-xl font-display font-bold text-white mb-4 uppercase">3. AI Transparency</h2>
                <p class="text-slate-300 text-sm leading-relaxed">
                    Evaluations are conducted by Gemini 2.5 Flash models. While highly accurate, AI outputs are probabilistic. Final hiring decisions should always involve human review. EvalionMind acts as a data processor, not the final arbiter of employment.
                </p>
            </section>
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PrivacyComponent {
  back = output<void>();
}
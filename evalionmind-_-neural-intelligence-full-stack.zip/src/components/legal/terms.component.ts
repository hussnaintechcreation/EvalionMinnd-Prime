

import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogoComponent } from '../logo/logo.component';

@Component({
  selector: 'app-terms',
  imports: [CommonModule, LogoComponent],
  template: `
    <div class="w-full max-w-5xl mx-auto px-6 pt-32 pb-20 animate-glitch-in relative">
      <button (click)="back.emit()" class="absolute top-24 left-6 text-sm font-tech text-slate-400 hover:text-white flex items-center gap-2 uppercase tracking-widest transition-colors" data-interactive>
        &larr; Return to Base
      </button>

      <header class="mb-12 border-b border-white/10 pb-8">
        <div class="flex items-center gap-4 mb-4">
            <app-logo [size]="48"></app-logo>
            <h1 class="text-4xl font-display font-black text-white uppercase tracking-widest">
                Terms of <span class="text-[var(--color-gold-accent)]">Service</span>
            </h1>
        </div>
        <p class="text-sm font-tech text-slate-400 max-w-2xl uppercase tracking-wider">
            Effective Date: 2024.01.01 // Contract ID: EM-TOS-V4
        </p>
      </header>

      <div class="space-y-8 font-sans text-slate-300">
        
        <div class="panel-obsidian p-8">
            <h3 class="text-lg font-display font-bold text-white uppercase mb-4 tracking-wider">1. Acceptance of Protocol</h3>
            <p class="text-sm leading-relaxed">
                By accessing the EvalionMind network (the "Service"), provided by Hussnain Tech Creation Pvt Ltd, you agree to be bound by these Terms. If you are accessing the Service on behalf of a corporate entity, you represent that you have the authority to bind that entity.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="panel-obsidian p-8 border-t-4 border-[var(--color-gold-accent)]">
                <h3 class="text-lg font-display font-bold text-white uppercase mb-4 tracking-wider">2. License to Use</h3>
                <p class="text-sm leading-relaxed mb-4">
                    We grant you a limited, non-exclusive, non-transferable license to access the neural evaluation tools for:
                </p>
                <ul class="list-disc pl-5 text-xs font-mono text-[var(--color-gold-accent)] space-y-2 uppercase">
                    <li>Personal Skill Assessment</li>
                    <li>Enterprise Candidate Screening</li>
                    <li>Academic Research (with prior approval)</li>
                </ul>
            </div>

            <div class="panel-obsidian p-8 border-t-4 border-[var(--color-neon-magenta)]">
                <h3 class="text-lg font-display font-bold text-white uppercase mb-4 tracking-wider">3. Prohibited Actions</h3>
                <p class="text-sm leading-relaxed mb-4">
                    Any attempt to reverse engineer the AI models, scrape data, or manipulate scoring algorithms will result in immediate termination.
                </p>
                <p class="text-xs font-bold text-[var(--color-neon-magenta)] uppercase">
                    VIOLATION WILL TRIGGER ACCOUNT LOCKOUT.
                </p>
            </div>
        </div>

        <div class="panel-obsidian p-8">
            <h3 class="text-lg font-display font-bold text-white uppercase mb-4 tracking-wider">4. Liability Disclaimer</h3>
            <p class="text-sm leading-relaxed">
                EvalionMind provides AI-based analysis "AS IS". We make no warranties regarding the specific hiring outcomes. The AI score is a data point, not a mandate. We are not liable for employment decisions made based on our analysis.
            </p>
        </div>

      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TermsComponent {
  back = output<void>();
}
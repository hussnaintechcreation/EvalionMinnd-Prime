

import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogoComponent } from '../logo/logo.component';

@Component({
  selector: 'app-security',
  imports: [CommonModule, LogoComponent],
  template: `
    <div class="w-full max-w-6xl mx-auto px-6 pt-32 pb-20 animate-glitch-in relative">
      <button (click)="back.emit()" class="absolute top-24 left-6 text-sm font-tech text-slate-400 hover:text-white flex items-center gap-2 uppercase tracking-widest transition-colors" data-interactive>
        &larr; Return to Base
      </button>

      <header class="text-center mb-16">
        <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-[rgba(var(--rgb-accent-green),0.1)] border border-[var(--color-accent-green)] mb-6 shadow-[0_0_30px_rgba(var(--rgb-accent-green),0.2)]">
            <svg class="w-10 h-10 text-[var(--color-accent-green)]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
        </div>
        <h1 class="text-5xl font-display font-black text-white uppercase tracking-widest mb-4">
            Security <span class="text-[var(--color-accent-green)]">Infrastructure</span>
        </h1>
        <p class="text-lg font-tech text-slate-400 uppercase tracking-widest">
            Defense-Grade Data Protection
        </p>
      </header>

      <!-- Status Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
        <div class="panel-obsidian p-6 text-center border-t-2 border-[var(--color-accent-green)]">
            <div class="text-xs font-tech text-slate-500 uppercase tracking-widest mb-2">Encryption</div>
            <div class="text-xl font-bold text-white">AES-256</div>
            <div class="text-[10px] text-[var(--color-accent-green)] uppercase mt-1">At Rest & Transit</div>
        </div>
        <div class="panel-obsidian p-6 text-center border-t-2 border-[var(--color-accent-green)]">
            <div class="text-xs font-tech text-slate-500 uppercase tracking-widest mb-2">Compliance</div>
            <div class="text-xl font-bold text-white">SOC 2 Type II</div>
            <div class="text-[10px] text-[var(--color-accent-green)] uppercase mt-1">Audited</div>
        </div>
        <div class="panel-obsidian p-6 text-center border-t-2 border-[var(--color-accent-green)]">
            <div class="text-xs font-tech text-slate-500 uppercase tracking-widest mb-2">Uptime</div>
            <div class="text-xl font-bold text-white">99.99%</div>
            <div class="text-[10px] text-[var(--color-accent-green)] uppercase mt-1">SLA Guarantee</div>
        </div>
        <div class="panel-obsidian p-6 text-center border-t-2 border-[var(--color-accent-green)]">
            <div class="text-xs font-tech text-slate-500 uppercase tracking-widest mb-2">Monitoring</div>
            <div class="text-xl font-bold text-white">24/7/365</div>
            <div class="text-[10px] text-[var(--color-accent-green)] uppercase mt-1">Automated Defense</div>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <!-- Architecture -->
        <div class="panel-obsidian p-8">
            <h3 class="text-xl font-display font-bold text-white uppercase mb-6 flex items-center gap-3">
                <svg class="w-6 h-6 text-[var(--color-neon-cyan)]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                Zero-Trust Architecture
            </h3>
            <p class="text-slate-300 text-sm leading-relaxed mb-6">
                EvalionMind operates on a strict zero-trust model. Every request, whether internal or external, is authenticated, authorized, and encrypted. We assume breach and design accordingly.
            </p>
            <ul class="space-y-3 font-tech text-xs text-slate-400">
                <li class="flex items-center gap-3">
                    <span class="w-1.5 h-1.5 bg-[var(--color-neon-cyan)] rounded-full"></span>
                    Micro-segmentation of neural network clusters
                </li>
                <li class="flex items-center gap-3">
                    <span class="w-1.5 h-1.5 bg-[var(--color-neon-cyan)] rounded-full"></span>
                    Ephemeral access tokens with short TTL
                </li>
                <li class="flex items-center gap-3">
                    <span class="w-1.5 h-1.5 bg-[var(--color-neon-cyan)] rounded-full"></span>
                    Regular penetration testing by white-hat entities
                </li>
            </ul>
        </div>

        <!-- Reporting -->
        <div class="panel-obsidian p-8">
            <h3 class="text-xl font-display font-bold text-white uppercase mb-6 flex items-center gap-3">
                <svg class="w-6 h-6 text-[var(--color-gold-accent)]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                Vulnerability Reporting
            </h3>
            <p class="text-slate-300 text-sm leading-relaxed mb-6">
                Security is a community effort. If you believe you have found a vulnerability in the EvalionMind mainframe, please report it immediately.
            </p>
            <div class="p-4 bg-[rgba(var(--rgb-gold-accent),0.05)] border border-[var(--color-gold-accent)]/20 rounded mb-6">
                <p class="text-xs font-mono text-[var(--color-gold-accent)]">security@techvertex.com</p>
                <p class="text-[10px] text-slate-500 mt-1 uppercase">PGP Key ID: 0x93FA...</p>
            </div>
            <button class="btn btn-secondary w-full text-xs uppercase tracking-wider">Download PGP Key</button>
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SecurityComponent {
  back = output<void>();
}
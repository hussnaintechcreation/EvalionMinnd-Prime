
import { ChangeDetectionStrategy, Component, output, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { User } from '../../models/user.model';
import { LogoComponent } from '../logo/logo.component';
import { AppState } from '../../types';

@Component({
  selector: 'app-header',
  imports: [CommonModule, LogoComponent],
  template: `
    <header class="fixed top-0 left-0 right-0 z-50 bg-[#0A0F1A]/80 backdrop-blur-md border-b border-[#00C8FF]/20 h-20 flex items-center justify-between px-6 lg:px-12 transition-all duration-300">
      
      <!-- Brand Left -->
      <div class="flex items-center gap-4 cursor-pointer group" (click)="onNavigate('intro')">
        <app-logo [size]="40"></app-logo>
        <div class="flex flex-col">
           <span class="text-white font-display font-bold text-xl tracking-widest uppercase group-hover:text-[#00C8FF] transition-colors">EvalionMind</span>
           <span class="text-[9px] text-slate-500 font-mono tracking-[0.2em] group-hover:text-[#FFD85A] transition-colors">NEURAL INTERFACE</span>
        </div>
      </div>

      <!-- Desktop Navigation -->
      <nav class="hidden md:flex items-center gap-8">
        @for (item of navModules; track item.id) {
          <a (click)="onNavigate(item.id)"
            class="text-sm font-tech text-slate-300 uppercase tracking-widest hover:text-[#00C8FF] cursor-pointer relative py-2 group"
            [class.text-[#00C8FF]]="appState() === item.id"
            [class.text-shadow-neon]="appState() === item.id">
            {{ item.label }}
            <span class="absolute bottom-0 left-0 bg-[#00C8FF] transition-all duration-300"
                  [class.w-full]="appState() === item.id"
                  [class.h-[3px]]="appState() === item.id"
                  [class.shadow-[0_0_15px_rgba(var(--rgb-neon-cyan),0.7)]]="appState() === item.id"
                  [class.w-0]="appState() !== item.id"
                  [class.h-[2px]]="appState() !== item.id"
                  ></span>
          </a>
        }
      </nav>

      <!-- Right Actions -->
      <div class="flex items-center gap-4">
        @if (currentUser(); as user) {
           <div class="flex items-center gap-3 pl-4 border-l border-[#263349]">
              <div class="text-right hidden sm:block">
                  <div class="text-white text-xs font-bold font-display uppercase">{{ user.name }}</div>
                  <div class="text-[#00C8FF] text-[10px] font-mono">{{ user.role }}</div>
              </div>
              <img [src]="user.avatarUrl!" width="40" height="40" alt="User Avatar" class="w-10 h-10 rounded-full border border-[#00C8FF] p-0.5 cursor-pointer hover:shadow-[0_0_15px_rgba(0,200,255,0.5)]" (click)="onDashboardClick()">
              <button (click)="signOut.emit()" class="text-slate-500 hover:text-red-400">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
              </button>
           </div>
        } @else {
           <button (click)="navigateTo.emit('contact')" 
                   class="hidden lg:block px-6 py-2 border border-[#FFD85A] text-[#FFD85A] text-xs font-bold uppercase tracking-widest shadow-[0_0_15px_rgba(var(--rgb-gold-accent),0.3)] hover:bg-[#FFD85A] hover:text-black hover:shadow-[0_0_25px_rgba(var(--rgb-gold-accent),0.6)] transition-all">
               Contact Us
           </button>
           <button (click)="signUp.emit()" 
                  class="hidden md:block px-6 py-2 bg-[#00C8FF]/10 text-[#00C8FF] border border-[#00C8FF]/50 text-xs font-bold uppercase tracking-widest shadow-[0_0_15px_rgba(var(--rgb-neon-cyan),0.3)] hover:bg-[#00C8FF] hover:text-black hover:shadow-[0_0_25px_rgba(var(--rgb-neon-cyan),0.5)] transition-all">
               Access Uplink
           </button>
        }
         <!-- Mobile Menu Button -->
        <button (click)="isMobileMenuOpen.set(!isMobileMenuOpen())" class="md:hidden text-slate-300 hover:text-white transition-colors">
          <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" /></svg>
        </button>
      </div>
    </header>

     <!-- Mobile Menu Overlay -->
    @if(isMobileMenuOpen()) {
      <div class="fixed inset-0 bg-black/90 backdrop-blur-md z-40 md:hidden animate-fade-in flex flex-col items-center justify-center">
        <nav class="flex flex-col items-center justify-center h-full gap-8">
          @for (item of navModules; track item.id) {
            <a (click)="onNavigate(item.id)" class="text-2xl font-display text-slate-300 uppercase tracking-widest hover:text-[#00C8FF] cursor-pointer">
              {{ item.label }}
            </a>
          }
        </nav>
        <div class="p-8">
          <button (click)="signUp.emit()" class="px-8 py-3 bg-[#00C8FF]/10 text-[#00C8FF] border border-[#00C8FF]/50 text-sm font-bold uppercase tracking-widest">
            Access Uplink
          </button>
        </div>
      </div>
    }
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=Share+Tech+Mono&family=Rajdhani:wght@300;400;600;700&display=swap');
    .font-display { font-family: 'Orbitron', sans-serif; }
    .font-tech { font-family: 'Rajdhani', sans-serif; }
    .font-mono { font-family: 'Share Tech Mono', monospace; }

    .text-shadow-neon {
      text-shadow: 0 0 8px rgba(var(--rgb-neon-cyan), 0.5);
    }
    
    .animate-fade-in {
      animation: fade-in 0.3s ease-out forwards;
    }
    @keyframes fade-in {
      from { opacity: 0; }
      to { opacity: 1; }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderComponent {
  currentUser = input<User | null>(null);
  appState = input<AppState | null>(null);
  
  navigateTo = output<AppState>();
  signOut = output<void>();
  signUp = output<void>();

  isMobileMenuOpen = signal(false);
  
  // Navigation Configuration - Matches design requirement
  navModules: { label: string, id: AppState }[] = [
      { label: 'Home', id: 'intro' },
      { label: 'About', id: 'about' },
      { label: 'Design', id: 'motion-designer' }, 
      { label: 'Neural Lab', id: 'dashboard' }, // This ID will be dynamically resolved
      { label: 'Contact', id: 'contact' }
  ];

  onNavigate(state: AppState) {
    this.isMobileMenuOpen.set(false); // Close menu on navigation
    // Special handling for 'Neural Lab' to direct to the correct dashboard based on role
    if (state === 'dashboard') {
        this.onDashboardClick();
    } else {
        this.navigateTo.emit(state);
    }
  }

  onDashboardClick(): void {
      const user = this.currentUser();
      if (user) {
          if (user.role === 'company' || user.role === 'interviewer') {
              this.navigateTo.emit('admin-dashboard');
          } else {
              this.navigateTo.emit('dashboard');
          }
      } else {
          // If no user, default to candidate dashboard or login
          this.navigateTo.emit('login'); 
      }
  }
}

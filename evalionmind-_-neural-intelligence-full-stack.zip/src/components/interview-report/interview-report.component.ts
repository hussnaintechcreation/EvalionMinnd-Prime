import { ChangeDetectionStrategy, Component, input, output, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InterviewHistoryItem } from '../../models/interview.model';
import { EvaluationResult } from '../../services/gemini.service';
import { LogoComponent } from '../logo/logo.component';

@Component({
  selector: 'app-interview-report',
  imports: [CommonModule, LogoComponent],
  templateUrl: './interview-report.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    /* Base for status indicators */
    .status-badge {
      padding: 0.25rem 0.75rem;
      border-radius: 9999px; /* Full pill shape */
      font-size: 0.625rem; /* 10px */
      line-height: 1;
      font-weight: 700; /* bold */
      text-transform: uppercase;
      letter-spacing: 0.05em; /* tracking-wider */
      border-width: 1px;
      display: inline-flex;
      align-items: center;
      gap: 0.25rem;
    }

    .pass-indicator {
      color: var(--color-accent-green);
      border-color: rgba(var(--rgb-accent-green), 0.3);
      background-color: rgba(var(--rgb-accent-green), 0.1);
    }
    .fail-indicator {
      color: var(--color-neon-magenta);
      border-color: rgba(var(--rgb-neon-magenta), 0.3);
      background-color: rgba(var(--rgb-neon-magenta), 0.1);
    }
    .neutral-indicator {
      color: var(--color-gold-accent);
      border-color: rgba(var(--rgb-gold-accent), 0.3);
      background-color: rgba(var(--rgb-gold-accent), 0.1);
    }
  `]
})
export class InterviewReportComponent {
  report = input<InterviewHistoryItem | null>(null);
  close = output<void>();

  // Overall pass/fail status for the interview (score 0-100)
  overallStatus = computed(() => {
    const score = this.report()?.score;
    if (score === undefined) return 'neutral';
    return score >= 75 ? 'pass' : 'fail';
  });

  // Pass/fail status for individual question evaluations (score 0-10)
  getQuestionStatus(evaluation: EvaluationResult): 'pass' | 'fail' | 'neutral' {
    if (evaluation.score === undefined) return 'neutral';
    return evaluation.score >= 7.0 ? 'pass' : 'fail';
  }

  // Get color class for overall status
  getOverallStatusClass(): string {
    const status = this.overallStatus();
    if (status === 'pass') return 'pass-indicator';
    if (status === 'fail') return 'fail-indicator';
    return 'neutral-indicator';
  }

  // Get color class for question status
  getQuestionStatusClass(evaluation: EvaluationResult): string {
    const status = this.getQuestionStatus(evaluation);
    if (status === 'pass') return 'pass-indicator';
    if (status === 'fail') return 'fail-indicator';
    return 'neutral-indicator';
  }

  getScoreColor(score?: number): string {
    if (score === undefined) return 'text-slate-500'; // Or a neutral color
    // If score is 0-10, scale to 0-100 for color function consistency if it exists
    const scaledScore = score * 10;
    if (scaledScore >= 80) return 'text-[var(--color-accent-green)]';
    if (scaledScore >= 60) return 'text-[var(--color-gold-accent)]';
    return 'text-[var(--color-neon-magenta)]';
  }
}
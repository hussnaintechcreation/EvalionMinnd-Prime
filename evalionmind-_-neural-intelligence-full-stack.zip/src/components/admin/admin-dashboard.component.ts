
import { ChangeDetectionStrategy, Component, signal, inject, OnInit, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { JobPost, MockBackendService } from '../../services/mock-backend.service';
import { InterviewHistoryItem } from '../../models/interview.model';
import { GeminiService } from '../../services/gemini.service';
import { LogoComponent } from '../logo/logo.component';
import { marked } from 'marked';

@Component({
  selector: 'app-admin-dashboard',
  imports: [CommonModule, FormsModule, LogoComponent],
  template: `
    <div class="min-h-screen bg-[#0A0F1A] text-white p-6 md:p-12 animate-glitch-in font-sans">
      
      <!-- Header -->
      <header class="flex flex-col md:flex-row justify-between items-center mb-12 border-b border-white/10 pb-6">
        <div class="flex items-center gap-4 mb-4 md:mb-0">
          <div class="w-12 h-12 bg-[rgba(var(--rgb-neon-cyan),0.1)] rounded-lg flex items-center justify-center border border-[rgba(var(--rgb-neon-cyan),0.3)]">
             <app-logo [size]="32"></app-logo>
          </div>
          <div>
            <h1 class="text-3xl font-display font-bold uppercase tracking-widest text-white">Admin <span class="text-[var(--color-neon-cyan)]">Nexus</span></h1>
            <p class="text-xs font-tech text-slate-400 tracking-[0.3em] uppercase">System Oversight & Configuration</p>
          </div>
        </div>
        <div class="flex gap-3">
           <div class="px-4 py-2 bg-white/5 border border-white/10 rounded text-xs font-mono text-slate-300">
              <span class="w-2 h-2 bg-green-500 rounded-full inline-block mr-2 animate-pulse"></span>
              SYSTEM OPTIMAL
           </div>
        </div>
      </header>

      <!-- Stats Grid (Tilt Cards) -->
      <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
        @for (stat of stats(); track stat.label) {
          <div class="tilt-card relative h-40 rounded-xl bg-[#263349] border border-white/10 p-6 flex flex-col justify-between overflow-hidden group transition-all duration-200"
               (mousemove)="onCardMouseMove($event)" 
               (mouseleave)="onCardMouseLeave($event)">
            
            <!-- Interior Glow -->
            <div class="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
            <div class="absolute -right-6 -top-6 w-24 h-24 bg-[var(--color-neon-cyan)]/20 rounded-full blur-3xl group-hover:bg-[var(--color-neon-cyan)]/30 transition-all"></div>

            <div class="relative z-10">
              <p class="text-xs font-tech text-slate-400 uppercase tracking-widest mb-1">{{ stat.label }}</p>
              <h3 class="text-4xl font-display font-bold text-white">{{ stat.value }}</h3>
            </div>
            
            <div class="relative z-10 flex justify-between items-end">
               <!-- FIX: Replaced ngClass with class binding for better performance and adherence to best practices. -->
               <span class="text-[10px] font-mono" [class.text-[var(--color-accent-green)]]="stat.trend > 0" [class.text-[var(--color-neon-magenta)]]="stat.trend <= 0">
                 {{ stat.trend > 0 ? '+' : ''}}{{ stat.trend }}% vs last month
               </span>
               <svg class="w-6 h-6 text-slate-600 group-hover:text-white transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" [attr.d]="stat.icon" />
               </svg>
            </div>
          </div>
        }
      </section>

      <!-- New Protocol Management Section -->
      <div class="panel-obsidian overflow-hidden border border-white/10 rounded-xl bg-[#263349]/50 backdrop-blur-md mb-8">
        <div class="p-6 border-b border-white/10 flex justify-between items-center">
            <h2 class="text-lg font-display font-bold text-white uppercase tracking-wider">Interview Protocols</h2>
            <div class="flex items-center gap-4">
                <label class="flex items-center gap-2 text-xs font-tech text-slate-400 cursor-pointer">
                    <input type="checkbox" [checked]="showArchived()" (change)="showArchived.set(!showArchived())" class="bg-black/40 border-white/20 accent-[var(--color-neon-cyan)]">
                    Show Archived
                </label>
            </div>
        </div>
        
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse">
            <thead>
              <tr class="bg-black/40 text-xs font-tech text-slate-400 uppercase tracking-widest border-b border-white/5">
                <th class="p-4 font-bold">Protocol Title</th>
                <th class="p-4 font-bold">Status</th>
                <th class="p-4 font-bold text-center">Applicants</th>
                <th class="p-4 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="text-sm font-sans text-slate-300">
              @for (job of showArchived() ? archivedJobs() : activeJobs(); track job.id) {
                <tr class="group border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td class="p-4">
                    <div class="font-bold text-white">{{ job.title }}</div>
                    <div class="text-[10px] font-mono text-slate-500">{{ job.id }}</div>
                  </td>
                  <td class="p-4">
                    <!-- FIX: Replaced ngClass with [attr.class] to dynamically add classes without overwriting static ones. -->
                    <span [attr.class]="'px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wide border ' + getStatusClass(job.status)">
                      {{ job.status }}
                    </span>
                  </td>
                  <td class="p-4 text-center font-mono">{{ job.applicants }}</td>
                  <td class="p-4 text-right">
                    @if (job.status !== 'Archived') {
                      <button (click)="archiveJob(job)" class="text-[10px] font-bold text-slate-500 hover:text-[var(--color-neon-magenta)] uppercase transition-colors">Archive</button>
                    } @else {
                      <button (click)="unarchiveJob(job)" class="text-[10px] font-bold text-slate-500 hover:text-[var(--color-accent-green)] uppercase transition-colors">Restore</button>
                    }
                  </td>
                </tr>
              } @empty {
                <tr>
                    <td colspan="4" class="p-8 text-center text-slate-500 font-tech text-xs">
                        {{ showArchived() ? 'NO ARCHIVED PROTOCOLS' : 'NO ACTIVE PROTOCOLS' }}
                    </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <!-- Left Column: Candidate Database -->
        <div class="lg:col-span-2 flex flex-col gap-8">
           <!-- Candidate Table -->
           <div class="panel-obsidian overflow-hidden border border-white/10 rounded-xl bg-[#263349]/50 backdrop-blur-md">
              <div class="p-6 border-b border-white/10 flex justify-between items-center">
                 <h2 class="text-lg font-display font-bold text-white uppercase tracking-wider">Candidate Registry</h2>
                 <div class="flex gap-2">
                    <input type="text" placeholder="Search ID..." class="bg-black/30 border border-white/10 rounded px-3 py-1 text-xs text-white focus:border-[var(--color-neon-cyan)] outline-none font-mono">
                    <button class="p-1 hover:bg-white/10 rounded text-slate-400 hover:text-white transition-colors">
                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293.707L3.293 7.293A1 1 0 013 6.586V4z" /></svg>
                    </button>
                 </div>
              </div>
              
              <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                  <thead>
                    <tr class="bg-black/40 text-xs font-tech text-slate-400 uppercase tracking-widest border-b border-white/5">
                      <th class="p-4 font-bold">Candidate</th>
                      <th class="p-4 font-bold">Role Protocol</th>
                      <th class="p-4 font-bold text-center">Neural Score</th>
                      <th class="p-4 font-bold text-center">Status</th>
                      <th class="p-4 font-bold text-right">Date</th>
                    </tr>
                  </thead>
                  <tbody class="text-sm font-sans text-slate-300">
                    @for (candidate of candidates(); track candidate.id) {
                      <tr class="group border-b border-white/5 hover:bg-white/5 transition-colors even:bg-white/[0.02]">
                        <td class="p-4">
                          <div class="font-bold text-white group-hover:text-[var(--color-neon-cyan)] transition-colors">{{ candidate.candidateName || 'Unknown' }}</div>
                          <div class="text-[10px] font-mono text-slate-500">{{ candidate.id }}</div>
                        </td>
                        <td class="p-4">{{ candidate.role }}</td>
                        <td class="p-4 text-center">
                           <!-- FIX: Replaced ngClass with [attr.class] to dynamically add classes without overwriting static ones. -->
                           <span [attr.class]="'font-display font-bold text-lg ' + getScoreColor(candidate.score)">{{ candidate.score || '-' }}</span>
                        </td>
                        <td class="p-4 text-center">
                          <!-- FIX: Replaced ngClass with [attr.class] to dynamically add classes without overwriting static ones. -->
                          <span [attr.class]="'px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wide border ' + getStatusClass(candidate.status)">
                            {{ candidate.status }}
                          </span>
                        </td>
                        <td class="p-4 text-right font-mono text-xs text-slate-500">{{ candidate.date }}</td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
              <!-- Pagination Mockup -->
              <div class="p-4 border-t border-white/10 flex justify-end gap-2">
                  <button class="px-3 py-1 bg-white/5 border border-white/10 rounded text-[10px] text-slate-400 hover:text-white transition-colors">&larr; PREV</button>
                  <button class="px-3 py-1 bg-[var(--color-neon-cyan)] text-black border border-[var(--color-neon-cyan)] rounded text-[10px] font-bold">1</button>
                  <button class="px-3 py-1 bg-white/5 border border-white/10 rounded text-[10px] text-slate-400 hover:text-white transition-colors">2</button>
                  <button class="px-3 py-1 bg-white/5 border border-white/10 rounded text-[10px] text-slate-400 hover:text-white transition-colors">NEXT &rarr;</button>
              </div>
           </div>
        </div>

        <!-- Right Column: AI Actions -->
        <div class="lg:col-span-1 flex flex-col gap-8">
            
            <!-- AI Template Generator -->
            <div class="panel-obsidian p-6 border border-[var(--color-gold-accent)]/30 relative overflow-hidden">
                <div class="absolute top-0 right-0 p-3 opacity-20 pointer-events-none">
                    <svg class="w-24 h-24 text-[var(--color-gold-accent)]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
                </div>

                <h2 class="text-lg font-display font-bold text-white uppercase tracking-wider mb-6 flex items-center gap-2">
                    <span class="w-2 h-2 bg-[var(--color-gold-accent)] rounded-full animate-pulse"></span>
                    Create Protocol
                </h2>

                <div class="space-y-4 relative z-10">
                    <div>
                        <label class="text-[10px] font-tech text-slate-400 uppercase tracking-widest">Target Role</label>
                        <input type="text" [(ngModel)]="templateRole" class="w-full mt-1 bg-black/40 border border-white/20 rounded px-3 py-2 text-sm text-white focus:border-[var(--color-gold-accent)] focus:outline-none transition-colors" placeholder="e.g. Senior DevOps">
                    </div>
                    <div>
                        <label class="text-[10px] font-tech text-slate-400 uppercase tracking-widest">Seniority</label>
                        <select [(ngModel)]="templateLevel" class="w-full mt-1 bg-black/40 border border-white/20 rounded px-3 py-2 text-sm text-white focus:border-[var(--color-gold-accent)] focus:outline-none transition-colors">
                            <option value="Junior">Junior</option>
                            <option value="Mid-Level">Mid-Level</option>
                            <option value="Senior">Senior</option>
                            <option value="Principal">Principal</option>
                        </select>
                    </div>
                    <div>
                        <label class="text-[10px] font-tech text-slate-400 uppercase tracking-widest">Technical Focus</label>
                        <textarea [(ngModel)]="templateFocus" rows="3" class="w-full mt-1 bg-black/40 border border-white/20 rounded px-3 py-2 text-sm text-white focus:border-[var(--color-gold-accent)] focus:outline-none transition-colors resize-none" placeholder="e.g. Kubernetes, Terraform, AWS Security"></textarea>
                    </div>

                    <button (click)="generateTemplate()" [disabled]="isGenerating() || !templateRole()" class="w-full btn btn-primary mt-4 py-3 text-xs font-bold uppercase tracking-widest border border-[var(--color-gold-accent)] text-[var(--color-gold-accent)] hover:bg-[var(--color-gold-accent)] hover:text-black">
                        {{ isGenerating() ? 'AI ARCHITECTING...' : 'GENERATE TEMPLATE' }}
                    </button>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="panel-obsidian p-6 border border-white/10">
                <h3 class="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">System Log</h3>
                <div class="space-y-4">
                    <div class="flex gap-3 items-start border-l border-white/10 pl-3 pb-1">
                        <div class="w-1.5 h-1.5 rounded-full bg-[var(--color-neon-cyan)] mt-1.5"></div>
                        <div>
                            <p class="text-xs text-white">New Candidate Registered</p>
                            <p class="text-[10px] text-slate-500 font-mono">10:42 AM - Alex C.</p>
                        </div>
                    </div>
                    <div class="flex gap-3 items-start border-l border-white/10 pl-3 pb-1">
                        <div class="w-1.5 h-1.5 rounded-full bg-[var(--color-accent-green)] mt-1.5"></div>
                        <div>
                            <p class="text-xs text-white">Interview Completed</p>
                            <p class="text-[10px] text-slate-500 font-mono">09:15 AM - Score: 88/100</p>
                        </div>
                    </div>
                    <div class="flex gap-3 items-start border-l border-white/10 pl-3">
                        <div class="w-1.5 h-1.5 rounded-full bg-[var(--color-neon-magenta)] mt-1.5"></div>
                        <div>
                            <p class="text-xs text-white">API Rate Limit Warning</p>
                            <p class="text-[10px] text-slate-500 font-mono">Yesterday - Key: CI-Pipeline</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
      </div>

      <!-- Generated Template Modal -->
      @if(showGeneratedTemplate()) {
          <div class="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-glitch-in">
              <div class="panel-obsidian max-w-2xl w-full max-h-[80vh] flex flex-col border border-[var(--color-gold-accent)]">
                  <div class="p-4 border-b border-white/10 flex justify-between items-center bg-[var(--color-gold-accent)]/10">
                      <h3 class="text-lg font-display font-bold text-[var(--color-gold-accent)] uppercase">Protocol Generated</h3>
                      <button (click)="showGeneratedTemplate.set(false)" class="text-slate-400 hover:text-white">&times;</button>
                  </div>
                  <div class="p-6 overflow-y-auto font-sans text-sm text-slate-300 leading-relaxed markdown-body">
                      <div [innerHTML]="generatedContent()"></div>
                  </div>
                  <div class="p-4 border-t border-white/10 flex justify-end gap-3 bg-black/40">
                      <button (click)="showGeneratedTemplate.set(false)" class="btn btn-secondary px-4 py-2 text-xs">DISCARD</button>
                      <button (click)="saveTemplate()" class="btn btn-primary px-6 py-2 text-xs bg-[var(--color-gold-accent)] text-black border-none hover:bg-white">SAVE TO LIBRARY</button>
                  </div>
              </div>
          </div>
      }

    </div>
  `,
  styles: [`
    .tilt-card {
      perspective: 1000px;
      transform-style: preserve-3d;
      will-change: transform;
    }
    
    /* Markdown Styles for generated content */
    ::ng-deep .markdown-body h3 { font-size: 1.1rem; color: white; margin-top: 1rem; margin-bottom: 0.5rem; font-weight: bold; }
    ::ng-deep .markdown-body ul { list-style: disc; padding-left: 1.5rem; margin-bottom: 1rem; }
    ::ng-deep .markdown-body li { margin-bottom: 0.25rem; }
    ::ng-deep .markdown-body strong { color: var(--color-gold-accent); }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminDashboardComponent implements OnInit {
  private mockBackend = inject(MockBackendService);
  private geminiService = inject(GeminiService);

  candidates = signal<InterviewHistoryItem[]>([]);
  jobs = signal<JobPost[]>([]);
  showArchived = signal(false);

  activeJobs = computed(() => this.jobs().filter(j => j.status !== 'Archived'));
  archivedJobs = computed(() => this.jobs().filter(j => j.status === 'Archived'));

  stats = signal<{label: string, value: string, trend: number, icon: string}[]>([
      { label: 'Total Interviews', value: '1,248', trend: 12, icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
      { label: 'Avg. Neural Score', value: '76.4', trend: 2.5, icon: 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6' },
      { label: 'Pass Rate', value: '62%', trend: -1.2, icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
      { label: 'System Load', value: '98%', trend: 5, icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
  ]);

  // AI Generator Signals
  templateRole = signal('');
  templateLevel = signal('Senior');
  templateFocus = signal('');
  isGenerating = signal(false);
  generatedContent = signal<string>('');
  showGeneratedTemplate = signal(false);
  rawQuestions = signal<string[]>([]);

  ngOnInit() {
    this.mockBackend.sessions$.subscribe(sessions => {
      this.candidates.set(sessions);
    });
    this.mockBackend.getJobs().subscribe(jobs => {
      this.jobs.set(jobs);
    });
  }

  // --- Tilt Logic ---
  onCardMouseMove(event: MouseEvent) {
    const card = event.currentTarget as HTMLElement;
    const rect = card.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = ((y - centerY) / centerY) * -10; 
    const rotateY = ((x - centerX) / centerX) * 10;

    card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
  }

  onCardMouseLeave(event: MouseEvent) {
    const card = event.currentTarget as HTMLElement;
    card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
  }

  // --- Helpers ---
  getScoreColor(score?: number): string {
    if (!score) return 'text-slate-500';
    if (score >= 85) return 'text-[var(--color-accent-green)]';
    if (score >= 70) return 'text-[var(--color-gold-accent)]';
    return 'text-[var(--color-neon-magenta)]';
  }

  getStatusClass(status: string): string {
    switch(status) {
        case 'Approved': return 'border-[var(--color-accent-green)] text-[var(--color-accent-green)] bg-[var(--color-accent-green)]/10';
        case 'Rejected': return 'border-[var(--color-neon-magenta)] text-[var(--color-neon-magenta)] bg-[var(--color-neon-magenta)]/10';
        case 'Archived': return 'border-slate-600 text-slate-500 bg-slate-500/10';
        default: return 'border-[var(--color-gold-accent)] text-[var(--color-gold-accent)] bg-[var(--color-gold-accent)]/10';
    }
  }

  // --- AI Actions ---
  async generateTemplate() {
    if (!this.templateRole()) return;
    
    this.isGenerating.set(true);
    
    const result = await this.geminiService.generateInterviewProtocol(this.templateRole(), this.templateLevel(), this.templateFocus());
    
    this.isGenerating.set(false);
    
    if (result && result.length > 0) {
        this.rawQuestions.set(result);
        const markdown = `
### ${this.templateLevel()} ${this.templateRole()} Protocol
**Focus:** ${this.templateFocus()}

---

${result.map(q => `* **${q}**`).join('\n\n')}
        `;
        const parsed = await marked.parse(markdown);
        this.generatedContent.set(parsed);
        this.showGeneratedTemplate.set(true);
    }
  }

  saveTemplate() {
    if (this.rawQuestions().length > 0) {
      this.mockBackend.createJob(
        `${this.templateLevel()} ${this.templateRole()}`,
        `Protocol for ${this.templateRole()} focused on ${this.templateFocus()}`,
        this.templateRole(),
        this.rawQuestions()
      ).subscribe(newJob => {
        this.jobs.update(jobs => [newJob, ...jobs]);
        this.showGeneratedTemplate.set(false);
        this.templateRole.set('');
        this.templateFocus.set('');
        this.rawQuestions.set([]);
      });
    }
  }

  archiveJob(job: JobPost) {
    if (confirm(`Are you sure you want to archive the protocol "${job.title}"?`)) {
      this.mockBackend.archiveJob(job.id).subscribe(success => {
        if (success) {
          this.jobs.update(jobs => jobs.map(j => j.id === job.id ? { ...j, status: 'Archived' } : j));
        }
      });
    }
  }

  unarchiveJob(job: JobPost) {
    this.mockBackend.unarchiveJob(job.id).subscribe(success => {
      if (success) {
        this.jobs.update(jobs => jobs.map(j => j.id === job.id ? { ...j, status: 'Active' } : j));
      }
    });
  }
}

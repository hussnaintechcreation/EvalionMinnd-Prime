

import { ChangeDetectionStrategy, Component, output, signal, OnInit, inject, input, computed, OnDestroy, effect } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { User } from '../../models/user.model';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';
import { JobPost, MockBackendService, UserTask } from '../../services/mock-backend.service';
import { PulseChartComponent } from './pulse-chart.component';
import { InterviewHistoryItem } from '../../models/interview.model';
import { FilterByStatusPipe } from '../../pipes/filter-by-status.pipe';
import { InterviewReportComponent } from '../interview-report/interview-report.component';
import { RadarChartComponent } from './radar-chart.component';
import { LogoComponent } from '../logo/logo.component';
import { OnboardingFlowComponent } from '../onboarding-flow/onboarding-flow.component';
import { WebSocketService } from '../../services/websocket.service';
import { SettingsComponent } from '../settings/settings.component';

type CandidateModule = 'overview' | 'interviews' | 'history' | 'system' | 'settings';

@Component({
  selector: 'app-dashboard',
  imports: [
      CommonModule, 
      FormsModule, 
      PulseChartComponent,
      SettingsComponent,
      FilterByStatusPipe,
      RadarChartComponent,
      LogoComponent,
      InterviewReportComponent,
      OnboardingFlowComponent,
      DatePipe
  ],
  templateUrl: './dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    @keyframes score-badge-pop-in {
      0% { opacity: 0; transform: scale(0.6); }
      70% { opacity: 1; transform: scale(1.1); }
      100% { transform: scale(1); }
    }
    .animate-score-badge {
      opacity: 0;
      animation: score-badge-pop-in 0.5s cubic-bezier(0.25, 0.1, 0.25, 1.275) forwards;
    }
    
    .custom-scrollbar::-webkit-scrollbar { width: 4px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.2); border-radius: 2px; }
    .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(255, 255, 255, 0.4); }

    @media print {
      body * { visibility: hidden; }
      .certificate-container, .certificate-container * { visibility: visible !important; }
      .certificate-container {
        position: fixed !important; 
        left: 0 !important; top: 0 !important; 
        width: 100vw !important; height: 100vh !important; 
        margin: 0 !important; padding: 0 !important; 
        z-index: 99999 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        background-color: white !important;
        color: black !important;
        border-width: 8px !important;
        border-color: black !important;
      }
      .no-print { display: none !important; }
      .print-text-black { color: black !important; }
      .print-text-gray { color: #555 !important; }
      .print-border-black { border-color: black !important; }
      .print-bg-white { background-color: white !important; }
      .print-shadow-none { box-shadow: none !important; text-shadow: none !important; filter: none !important; }
      .print-logo-black svg path { stroke: black !important; fill: black !important; }
    }
  `]
})
export class DashboardComponent implements OnInit, OnDestroy {
  user = input<User | null>(null);
  sessionHistory = input<InterviewHistoryItem[]>([]); 
  
  startPractice = output<string>(); 
  goToImageEditor = output<void>();
  editProfile = output<void>();
  signOut = output<void>();
  openFullstackEnhancer = output<void>(); 

  private mockBackend = inject(MockBackendService);
  private geminiService = inject(GeminiService);
  private wsService = inject(WebSocketService);
  wsStatus = this.wsService.status;
  
  showOnboarding = signal(false);
  activeModule = signal<CandidateModule>('overview');
  availableInterviews = signal<JobPost[]>([]);
  
  candidateHistory = computed(() => {
    const userId = this.user()?.id;
    return this.sessionHistory().filter(item => 
      item.candidateId === userId || item.candidateId === 'CAND-alex-candidate-849' 
    );
  });

  last7DaysHistory = computed(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0); 
    const sevenDaysAgo = new Date(today);
    sevenDaysAgo.setDate(today.getDate() - 7);

    return this.candidateHistory().filter(item => {
      let itemDate: Date;
      if (item.date === 'Today') {
        itemDate = today;
      } else {
        itemDate = new Date(item.date);
        if (isNaN(itemDate.getTime())) return false;
        itemDate.setHours(0, 0, 0, 0);
      }
      return itemDate >= sevenDaysAgo && itemDate <= today;
    }).sort((a, b) => {
      const dateA = a.date === 'Today' ? today : new Date(a.date);
      const dateB = b.date === 'Today' ? today : new Date(b.date);
      const timeA = isNaN(dateA.getTime()) ? 0 : dateA.getTime();
      const timeB = isNaN(dateB.getTime()) ? 0 : dateB.getTime();
      return timeB - timeA;
    });
  });
  
  dailyChallenge = signal<{title: string, language: string, difficulty: 'Easy'|'Medium'|'Hard'}>({
      title: 'Reverse Linked List',
      language: 'JavaScript',
      difficulty: 'Medium'
  });
  skillRadar = signal<{label: string, value: number}[]>([
      {label: 'Frontend', value: 85},
      {label: 'Backend', value: 60},
      {label: 'DevOps', value: 40},
      {label: 'System Design', value: 70},
      {label: 'Algorithms', value: 65}
  ]);
  
  userTasks = signal<UserTask[]>([]);
  newTaskTitle = signal('');
  newTagInput = signal('');
  currentNewTags = signal<string[]>([]);

  showCertificateModal = signal(false);
  selectedCertificateData = signal<InterviewHistoryItem | null>(null);
  
  showReportModal = signal(false);
  selectedReportData = signal<InterviewHistoryItem | null>(null);

  notificationMessage = signal<{text: string, type: 'info' | 'success' | 'error'} | null>(null);
  
  isCameraOk = signal(false);
  isMicrophoneOk = signal(false);
  micVolume = signal(0);
  
  constructor() {
      effect(() => {
          this.loadCandidateData();
      });
  }

  ngOnInit(): void {
      this.checkPermissions();
      if (typeof localStorage !== 'undefined' && !localStorage.getItem('evalionmind_candidate_onboarding_completed')) {
          // this.showOnboarding.set(true); 
      }
  }
  
  ngOnDestroy(): void {}
  
  handleOnboardingComplete(): void {
      if (typeof localStorage !== 'undefined') {
          localStorage.setItem('evalionmind_candidate_onboarding_completed', 'true');
      }
      this.showOnboarding.set(false);
  }

  loadCandidateData() {
      this.mockBackend.getAvailableJobs().subscribe(jobs => this.availableInterviews.set(jobs));
      this.mockBackend.tasks$.subscribe(tasks => this.userTasks.set(tasks));
  }

  startInterview(role: string) {
      this.startPractice.emit(role);
  }

  viewCertificate(item: InterviewHistoryItem) {
      this.selectedCertificateData.set(item);
      this.showCertificateModal.set(true);
  }
  
  openReport(item: InterviewHistoryItem) {
      this.selectedReportData.set(item);
      this.showReportModal.set(true);
  }

  downloadCertificate() {
      window.print();
      this.showNotification('Please use your browser\'s print dialog to "Save as PDF".', 'info');
  }
  
  printCertificate() {
      window.print();
  }

  addTaskTag() {
    const tag = this.newTagInput().trim().toLowerCase();
    if (tag && !this.currentNewTags().includes(tag)) {
      this.currentNewTags.update(tags => [...tags, tag]);
      this.newTagInput.set('');
    }
  }

  removeTaskTag(tagToRemove: string) {
    this.currentNewTags.update(tags => tags.filter(tag => tag !== tagToRemove));
  }

  createNewTask() {
    if (!this.newTaskTitle().trim()) return;
    this.mockBackend.addTask(this.newTaskTitle(), this.currentNewTags()).subscribe(() => {
      this.newTaskTitle.set('');
      this.currentNewTags.set([]);
      this.showNotification('Task vector initialized.', 'success');
    });
  }

  toggleTaskStatus(taskId: string) {
    this.mockBackend.toggleTask(taskId).subscribe();
  }

  deleteTask(taskId: string) {
    this.mockBackend.deleteTask(taskId).subscribe(() => {
      this.showNotification('Task deleted.', 'info');
    });
  }

  getTagColorClass(tagName: string): string {
    const colors = [
      'text-[var(--color-neon-cyan)] border-[var(--color-neon-cyan)]',
      'text-[var(--color-neon-violet)] border-[var(--color-neon-violet)]',
      'text-[var(--color-accent-green)] border-[var(--color-accent-green)]',
      'text-[var(--color-gold-accent)] border-[var(--color-gold-accent)]',
      'text-[var(--color-neon-magenta)] border-[var(--color-neon-magenta)]'
    ];
    let hash = 0;
    for (let i = 0; i < tagName.length; i++) {
      hash = tagName.charCodeAt(i) + ((hash << 5) - hash);
    }
    const index = Math.abs(hash) % colors.length;
    return colors[index];
  }

  setActiveModule(m: CandidateModule) { this.activeModule.set(m); }
  
  showNotification(text: string, type: 'success' | 'error' | 'info') {
      this.notificationMessage.set({ text, type });
      setTimeout(() => this.notificationMessage.set(null), 3000);
  }

  async checkPermissions() {
      try {
          const s = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
          this.isCameraOk.set(true);
          this.isMicrophoneOk.set(true);
          s.getTracks().forEach(t => t.stop());
      } catch(e) {
          console.warn('Permissions denied', e);
      }
  }
  
  getScoreColor(score?: number): string {
    if (score === undefined) return 'text-slate-500';
    if (score >= 80) return 'text-[var(--color-accent-green)]';
    if (score >= 60) return 'text-[var(--color-gold-accent)]';
    return 'text-[var(--color-neon-magenta)]';
  }
}
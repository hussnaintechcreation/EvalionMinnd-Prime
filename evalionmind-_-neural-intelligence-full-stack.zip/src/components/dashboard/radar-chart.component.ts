import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, effect, input, inject, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as d3 from 'd3';

@Component({
  selector: 'app-radar-chart',
  imports: [CommonModule],
  template: `<div #chart class="w-full h-full flex items-center justify-center min-h-[300px]"></div>`,
  styles: [`
    :host { display: block; width: 100%; height: 100%; }
    
    /* D3 Styling handled here to ensure encapsulation or deep selection */
    ::ng-deep .radar-axis line { stroke: rgba(var(--rgb-text-primary), 0.1); stroke-width: 1px; }
    ::ng-deep .radar-axis text { fill: rgba(var(--rgb-text-primary), 0.6); font-family: 'Share Tech Mono', monospace; font-size: 10px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.05em; }
    ::ng-deep .radar-grid { fill: none; stroke: rgba(var(--rgb-text-primary), 0.08); stroke-width: 1px; stroke-dasharray: 4 2; }
    ::ng-deep .radar-area { fill: rgba(var(--rgb-neon-cyan), 0.15); stroke: var(--color-neon-cyan); stroke-width: 2px; filter: drop-shadow(0 0 8px rgba(var(--rgb-neon-cyan), 0.4)); transition: all 0.3s ease; }
    ::ng-deep .radar-area:hover { fill: rgba(var(--rgb-neon-cyan), 0.25); stroke-width: 3px; }
    ::ng-deep .radar-point { fill: var(--color-bg-deep); stroke: var(--color-neon-cyan); stroke-width: 2px; r: 3; transition: r 0.2s ease; }
    ::ng-deep .radar-point:hover { r: 6; fill: var(--color-text-primary); cursor: crosshair; }
    ::ng-deep .tooltip-bg { fill: rgba(0,0,0,0.8); stroke: rgba(var(--rgb-text-primary), 0.2); rx: 4; }
    ::ng-deep .tooltip-text { fill: var(--color-text-primary); font-size: 12px; font-family: 'Share Tech Mono'; text-anchor: middle; }
  `],
})
export class RadarChartComponent implements AfterViewInit, OnDestroy {
  data = input<{label: string, value: number}[]>([]);
  @ViewChild('chart') chartContainer!: ElementRef<HTMLDivElement>;
  
  private resizeObserver: ResizeObserver | null = null;
  private ngZone = inject(NgZone);

  constructor() {
    effect(() => {
      // Dependency on data
      const d = this.data(); 
      // Re-draw when data changes
      if (this.chartContainer) {
        this.ngZone.runOutsideAngular(() => {
            this.createChart();
        });
      }
    });
  }

  ngAfterViewInit() {
    this.createChart();
    
    this.resizeObserver = new ResizeObserver(() => {
        this.ngZone.runOutsideAngular(() => {
            this.createChart();
        });
    });
    this.resizeObserver.observe(this.chartContainer.nativeElement);
  }

  ngOnDestroy() {
    if (this.resizeObserver) {
        this.resizeObserver.disconnect();
    }
  }

  private createChart() {
    if (!this.chartContainer) return;
    
    const element = this.chartContainer.nativeElement;
    // Clear previous chart
    d3.select(element).selectAll('*').remove();

    const data = this.data();
    if (!data || data.length === 0) return;

    // Dimensions
    const containerWidth = element.offsetWidth || 300;
    const containerHeight = element.offsetHeight || 300;
    const margin = { top: 40, right: 40, bottom: 40, left: 40 };
    const width = containerWidth - margin.left - margin.right;
    const height = containerHeight - margin.top - margin.bottom;
    
    if (width <= 0 || height <= 0) return;

    const radius = Math.min(width, height) / 2;

    const svg = d3.select(element)
      .append('svg')
      .attr('width', containerWidth)
      .attr('height', containerHeight)
      .append('g')
      .attr('transform', `translate(${containerWidth / 2}, ${containerHeight / 2})`);

    const angleSlice = Math.PI * 2 / data.length;

    // Scale for radius
    const rScale = d3.scaleLinear()
      .range([0, radius])
      .domain([0, 100]);

    // --- Draw Grid (Concentric Polygons) ---
    const levels = 4;
    for (let i = 0; i < levels; i++) {
        const levelRadius = radius * ((i + 1) / levels);
        const points: [number, number][] = data.map((d, j) => {
            // angle: starts at 12 o'clock (0 rads in D3 terms? No, d3.lineRadial is 0 at 12. Manual trig needs checking)
            // Using standard trig: 0 is 3 o'clock.
            // Let's align with d3.lineRadial which says 0 is 12 o'clock.
            const angle = j * angleSlice; 
            return [
                levelRadius * Math.sin(angle), 
                -levelRadius * Math.cos(angle)
            ];
        });
        
        // Close the polygon
        points.push(points[0]);

        svg.append('path')
           .attr('class', 'radar-grid')
           .attr('d', d3.line()(points));
    }

    // --- Draw Axes ---
    const axes = svg.selectAll('.axis')
      .data(data)
      .enter()
      .append('g')
      .attr('class', 'radar-axis');

    axes.append('line')
      .attr('x1', 0)
      .attr('y1', 0)
      .attr('x2', (d, i) => rScale(100) * Math.sin(i * angleSlice))
      .attr('y2', (d, i) => -rScale(100) * Math.cos(i * angleSlice));

    axes.append('text')
      .attr('x', (d, i) => rScale(115) * Math.sin(i * angleSlice))
      .attr('y', (d, i) => -rScale(115) * Math.cos(i * angleSlice))
      .attr('dy', '0.35em')
      .style('text-anchor', 'middle')
      .text(d => d.label);

    // --- Draw Radar Area ---
    const radarLine = d3.lineRadial<{label: string, value: number}>()
      .radius(d => rScale(d.value))
      .angle((d, i) => i * angleSlice)
      .curve(d3.curveLinearClosed);

    svg.append('path')
      .datum(data)
      .attr('class', 'radar-area')
      .attr('d', radarLine);

    // --- Draw Data Points ---
    const pointsGroup = svg.selectAll('.point-group')
      .data(data)
      .enter()
      .append('g')
      .attr('class', 'point-group');

    pointsGroup.append('circle')
      .attr('class', 'radar-point')
      .attr('cx', (d, i) => rScale(d.value) * Math.sin(i * angleSlice))
      .attr('cy', (d, i) => -rScale(d.value) * Math.cos(i * angleSlice))
      .attr('r', 4);
      
    // --- Tooltips ---
    // Add simple tooltip logic
    const tooltip = svg.append('g').attr('class', 'tooltip').style('opacity', 0);
    tooltip.append('rect').attr('class', 'tooltip-bg').attr('width', 60).attr('height', 20).attr('x', -30).attr('y', -25);
    tooltip.append('text').attr('class', 'tooltip-text').attr('y', -11);

    pointsGroup.on('mouseenter', function(event, d) {
        const circle = d3.select(this).select('circle');
        const cx = parseFloat(circle.attr('cx'));
        const cy = parseFloat(circle.attr('cy'));
        
        tooltip.style('opacity', 1)
               .attr('transform', `translate(${cx}, ${cy})`);
        tooltip.select('text').text(`${d.value}%`);
    }).on('mouseleave', () => {
        tooltip.style('opacity', 0);
    });
  }
}
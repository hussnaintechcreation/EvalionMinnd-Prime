import { Component, computed, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-pulse-chart',
  imports: [CommonModule],
  template: `
    <svg class="w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 100">
      <!-- Gradient Definition -->
      <defs>
        <linearGradient [id]="gradientId" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" [attr.stop-color]="color()" stop-opacity="0.3"></stop>
          <stop offset="100%" [attr.stop-color]="color()" stop-opacity="0"></stop>
        </linearGradient>
      </defs>
      
      <!-- Area Path -->
      <path [attr.d]="areaPath()" [attr.fill]="'url(#' + gradientId + ')'" stroke="none"></path>
      
      <!-- Line Path -->
      <path [attr.d]="linePath()" fill="none" [attr.stroke]="color()" stroke-width="2" vector-effect="non-scaling-stroke"></path>
      
      <!-- Pulse Dot -->
      @if (lastPoint(); as point) {
        <circle [attr.cx]="point.x" [attr.cy]="point.y" r="2" [attr.fill]="color()" class="animate-pulse">
           <animate attributeName="r" values="2;4;2" dur="1.5s" repeatCount="indefinite" />
           <animate attributeName="opacity" values="1;0.5;1" dur="1.5s" repeatCount="indefinite" />
        </circle>
      }
    </svg>
  `,
  styles: [`:host { display: block; width: 100%; height: 100%; }`]
})
export class PulseChartComponent {
  data = input<number[]>([]);
  color = input<string>('#ffffff');
  
  gradientId = `pulse-grad-${Math.random().toString(36).substr(2, 9)}`;

  // Compute normalized points (x: 0-100, y: 0-100)
  private points = computed(() => {
    const rawData = this.data();
    if (!rawData.length) return [];
    
    // Y axis: 0 to 100 (value) -> 100 to 0 (coordinate, since SVG y is down)
    // X axis: 0 to length-1 -> 0 to 100
    
    return rawData.map((val, i) => ({
      x: (i / (rawData.length - 1 || 1)) * 100,
      y: 100 - Math.min(Math.max(val, 0), 100) // Clamp 0-100 and invert
    }));
  });

  lastPoint = computed(() => {
    const pts = this.points();
    return pts.length > 0 ? pts[pts.length - 1] : null;
  });

  linePath = computed(() => {
    const pts = this.points();
    if (pts.length === 0) return '';
    
    // Simple line join
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) {
        d += ` L ${pts[i].x} ${pts[i].y}`;
    }
    return d;
  });

  areaPath = computed(() => {
    const line = this.linePath();
    if (!line) return '';
    
    // Close the path to the bottom corners
    return `${line} L 100 100 L 0 100 Z`;
  });
}

import { ChangeDetectionStrategy, Component, output, signal, OnInit, OnDestroy, effect } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { AppState } from '../../types';
import { FeaturesComponent } from '../feature-generator/features/features.component';
import { CodePlaygroundComponent } from '../code-playground/code-playground.component';
import { LogoComponent } from '../logo/logo.component';
import { PanelSectionComponent } from '../panel-section/panel-section.component';

export interface Testimonial {
  quote: string;
  name: string;
  title: string;
  avatar: string;
}

@Component({
  selector: 'app-intro',
  imports: [CommonModule, FeaturesComponent, CodePlaygroundComponent, LogoComponent, PanelSectionComponent],
  templateUrl: './intro.component.html',
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=Share+Tech+Mono&family=Rajdhani:wght@300;400;600;700&display=swap');

    :host {
      display: block;
      font-family: 'Rajdhani', sans-serif;
    }

    .font-display { font-family: 'Orbitron', sans-serif; }
    .font-tech { font-family: 'Rajdhani', sans-serif; }
    .font-mono { font-family: 'Share Tech Mono', monospace; }

    .animate-spin-slow { animation: spin 20s linear infinite; }
    .animate-spin-reverse { animation: spin 25s linear infinite reverse; }
    .animate-float { animation: float 6s ease-in-out infinite; }
    .animate-pulse-slow { animation: pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite; }

    @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    @keyframes float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-20px); } }
    @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: .5; } }

    .perspective-1000 { perspective: 1000px; }
    .clip-path-hex { clip-path: polygon(5% 0%, 95% 0%, 100% 10%, 100% 90%, 95% 100%, 5% 100%, 0% 90%, 0% 10%); }

    /* Custom Scrollbar for this page */
    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: #0A0F1A; }
    ::-webkit-scrollbar-thumb { background: #263349; border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: #00C8FF; }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '(window:scroll)': 'onWindowScroll()'
  }
})
export class IntroComponent implements OnInit, OnDestroy {
  getStarted = output<void>();
  practiceUplink = output<void>();
  navigateTo = output<AppState>();
  takeTour = output<void>();
  
  parallaxOffset = signal(0);

  onWindowScroll() {
    if(typeof window !== 'undefined') {
        const scrollY = window.scrollY;
        // Adjust multiplier for effect strength. Only apply on larger screens.
        if (window.innerWidth > 768) {
            this.parallaxOffset.set(scrollY * 0.2);
        } else {
            this.parallaxOffset.set(0);
        }
    }
  }

  // Keeping existing functionality
  testimonials: Testimonial[] = [
    {
      quote: "The non-verbal feedback was a game-changer. I never realized how my body language was undermining my answers. After three sessions, I landed the job.",
      name: 'Alex Chen',
      title: 'Senior Engineer @ TechCorp',
      avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704d'
    },
    {
      quote: "EvalionMind standardized our initial screening. The consistency and depth of the AI's analysis are beyond what we could achieve with human-only interviews at scale.",
      name: 'Maria Rodriguez',
      title: 'Head of Talent @ Innovate',
      avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704e'
    },
    {
      quote: "The actionable tips are incredibly precise. The AI identified a specific weakness in my system design explanations and gave me a better model to follow.",
      name: 'David Lee',
      title: 'Backend Architect',
      avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704f'
    },
    {
      quote: "An indispensable tool for our recruitment pipeline. We've cut down screening time by 70% while improving the quality of our final candidates.",
      name: 'Sarah Jenkins',
      title: 'CTO @ CyberSystems',
      avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026705a'
    }
  ];

  currentSlide = signal(0);
  private intervalId: any;

  ngOnInit() {
    this.startAutoplay();
  }

  ngOnDestroy() {
    this.stopAutoplay();
  }

  startAutoplay() {
    this.stopAutoplay();
    this.intervalId = setInterval(() => {
      this.nextSlide();
    }, 5000); // Cycle every 5 seconds
  }

  stopAutoplay() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  nextSlide() {
    this.currentSlide.update(i => (i + 1) % this.testimonials.length);
  }

  goToSlide(index: number) {
    this.currentSlide.set(index);
    this.startAutoplay();
  }

  onGetStartedClick() {
    this.getStarted.emit();
  }
  
  onPracticeUplinkClick() {
    this.practiceUplink.emit();
  }

  onDiagnosticsClick() {
    this.navigateTo.emit('terminal');
  }
}

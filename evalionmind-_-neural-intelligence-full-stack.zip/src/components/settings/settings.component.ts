
import { ChangeDetectionStrategy, Component, output, signal, input, OnInit, inject, effect, OnDestroy, Renderer2, DOCUMENT } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { User } from '../../models/user.model';
import { AuthService } from '../../services/auth.service';
import { Subject, Subscription } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-settings',
  imports: [CommonModule, FormsModule],
  templateUrl: './settings.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SettingsComponent implements OnInit, OnDestroy {
  currentUser = input<User | null>(null);
  back = output<void>();
  profileUpdated = output<Partial<User>>();
  accessibilitySettingsChanged = output<{ 
    fontSize: 'small' | 'normal' | 'large', 
    highContrast: boolean,
    theme: 'dark' | 'light' | 'futuristic',
    brightness: number,
    density: number,
    speed: number
  }>();
  
  private authService = inject(AuthService);
  private renderer2 = inject(Renderer2);
  private document: Document = inject(DOCUMENT);

  // Profile info
  userName = '';
  userEmail = '';
  userDesignation = '';
  
  // Company Specific Fields
  ownerName = '';
  cnic = '';
  mobile = '';
  
  // Avatar
  avatarUrl: string | undefined = undefined;

  isSavingProfile = signal(false);
  profileMessage = signal<{type: 'success' | 'error', text: string} | null>(null);
  
  // Password info
  newPassword = '';
  confirmPassword = '';
  isSavingPassword = signal(false);
  passwordMessage = signal<{type: 'success' | 'error', text: string} | null>(null);

  // Biometric signals
  isBiometricRegistered = signal(false);
  isCheckingBiometric = signal(true);
  isManagingBiometric = signal(false);
  biometricMessage = signal<{type: 'success' | 'error', text: string} | null>(null);

  // Accessibility & Visuals Signals
  appFontSize = signal<'small' | 'normal' | 'large'>('normal');
  highContrastMode = signal(false);
  appTheme = signal<'dark' | 'light' | 'futuristic'>('dark');
  backgroundBrightness = signal(1.0);
  backgroundDensity = signal(1.0);
  backgroundSpeed = signal(1.0);

  // Debouncing for storage persistence
  private settingsStorageUpdate$ = new Subject<void>();
  private settingsSubscription: Subscription | null = null;

  constructor() {
      effect(() => {
          const user = this.currentUser();
          if (user) {
              this.userName = user.name;
              this.userEmail = user.email;
              this.userDesignation = user.designation || '';
              this.avatarUrl = user.avatarUrl;
              
              if(user.role === 'company') {
                  this.ownerName = user.ownerName || '';
                  this.cnic = user.cnic || '';
                  this.mobile = user.mobile || '';
              }
              this.checkBiometricStatus(user.id);
          }
      });
      
      // Effect to apply INSTANT visual feedback on the DOM when signals change
      // This ensures the UI feels responsive locally
      effect(() => {
          this.applyVisualSettingsToDOM();
      });
  }

  ngOnInit(): void {
    this.loadSettingsFromStorage();
    
    // Debounce both emitting settings to parent and saving to storage.
    this.settingsSubscription = this.settingsStorageUpdate$.pipe(
        debounceTime(500) // 500ms delay 
    ).subscribe(() => {
        this.emitSettings();
        this.saveSettingsToStorage();
    });
  }
  
  ngOnDestroy(): void {
    this.settingsSubscription?.unsubscribe();
  }

  private loadSettingsFromStorage(): void {
      if (typeof localStorage !== 'undefined') {
          this.appFontSize.set((localStorage.getItem('evalionmind_font_size') as 'small' | 'normal' | 'large') || 'normal');
          this.highContrastMode.set(JSON.parse(localStorage.getItem('evalionmind_high_contrast') || 'false'));
          this.appTheme.set((localStorage.getItem('evalionmind_theme') as 'dark' | 'light' | 'futuristic') || 'dark');
          this.backgroundBrightness.set(parseFloat(localStorage.getItem('evalionmind_background_brightness') || '1.0'));
          this.backgroundDensity.set(parseFloat(localStorage.getItem('evalionmind_background_density') || '1.0'));
          this.backgroundSpeed.set(parseFloat(localStorage.getItem('evalionmind_background_speed') || '1.0'));
      }
  }

  private applyVisualSettingsToDOM(): void {
      const docElement = this.document.documentElement;
      const currentFontSize = this.appFontSize();
      const currentHighContrast = this.highContrastMode();
      const currentTheme = this.appTheme();

      // Font size
      docElement.classList.remove('font-small', 'font-normal', 'font-large');
      docElement.classList.add(`font-${currentFontSize}`);

      // Theme
      this.renderer2.setAttribute(docElement, 'data-theme', currentTheme);

      // High contrast
      if (currentHighContrast) {
          docElement.classList.add('high-contrast');
      } else {
          docElement.classList.remove('high-contrast');
      }
  }
  
  // Emits settings to parent (debounced)
  private emitSettings(): void {
      this.accessibilitySettingsChanged.emit({ 
          fontSize: this.appFontSize(), 
          highContrast: this.highContrastMode(),
          theme: this.appTheme(),
          brightness: this.backgroundBrightness(),
          density: this.backgroundDensity(),
          speed: this.backgroundSpeed()
      });
  }

  // Saves to localStorage (debounced)
  private saveSettingsToStorage(): void {
    if (typeof localStorage !== 'undefined') {
        localStorage.setItem('evalionmind_font_size', this.appFontSize());
        localStorage.setItem('evalionmind_high_contrast', JSON.stringify(this.highContrastMode()));
        localStorage.setItem('evalionmind_theme', this.appTheme());
        localStorage.setItem('evalionmind_background_brightness', this.backgroundBrightness().toString());
        localStorage.setItem('evalionmind_background_density', this.backgroundDensity().toString());
        localStorage.setItem('evalionmind_background_speed', this.backgroundSpeed().toString());
    }
  }
  
  getInitials(): string {
    if (!this.userName) return '';
    const parts = this.userName.split(' ').filter(p => p);
    if (parts.length > 1) {
      return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
    }
    return this.userName.substring(0, 2).toUpperCase();
  }

  onFileSelected(event: any): void {
      const file = event.target.files[0];
      if (file) {
          const reader = new FileReader();
          reader.onload = (e: any) => {
              this.avatarUrl = e.target.result;
          };
          reader.readAsDataURL(file);
      }
  }

  saveProfile(): void {
    this.isSavingProfile.set(true);
    this.profileMessage.set(null);

    const updates: Partial<User> = {
        name: this.userName,
        email: this.userEmail,
        designation: this.userDesignation,
    };
    
    if (this.avatarUrl) {
        if (this.avatarUrl.startsWith('data:image')) {
            const userId = this.currentUser()?.id || 'new-user';
            const newAvatarUrl = `https://i.pravatar.cc/150?u=${encodeURIComponent(userId)}`;
            updates.avatarUrl = newAvatarUrl;
            this.avatarUrl = newAvatarUrl;
        } else {
            updates.avatarUrl = this.avatarUrl;
        }
    }
    
    if (this.currentUser()?.role === 'company') {
        updates.ownerName = this.ownerName;
        updates.cnic = this.cnic;
        updates.mobile = this.mobile;
    }

    this.profileUpdated.emit(updates);

    if (this.currentUser()?.id) {
        this.authService.updateProfile(this.currentUser()!.id, updates).subscribe({
            next: (updatedUser) => {
                this.isSavingProfile.set(false);
                this.profileMessage.set({ type: 'success', text: 'Profile updated successfully!' });
                setTimeout(() => this.profileMessage.set(null), 3000);
            },
            error: (err: any) => {
                this.isSavingProfile.set(false);
                let errorMessage = 'Failed to update profile. An unknown error occurred.';
                if (err instanceof DOMException && err.name === 'QuotaExceededError') {
                    errorMessage = 'Storage limit reached. Could not save profile. Please use a smaller image or clear browser data.';
                } else if (err instanceof Error) {
                    errorMessage = err.message;
                }
                this.profileMessage.set({ type: 'error', text: errorMessage });
            }
        });
    }
  }

  changePassword(): void {
    this.isSavingPassword.set(true);
    this.passwordMessage.set(null);

    if (this.newPassword !== this.confirmPassword) {
      this.passwordMessage.set({ type: 'error', text: 'New passwords do not match.' });
      this.isSavingPassword.set(false);
      return;
    }

    if (this.newPassword.length < 6) {
        this.passwordMessage.set({ type: 'error', text: 'New password must be at least 6 characters long.' });
        this.isSavingPassword.set(false);
        return;
    }

    setTimeout(() => {
      this.isSavingPassword.set(false);
       this.passwordMessage.set({ type: 'success', text: 'Password changed successfully!' });
       this.newPassword = '';
       this.confirmPassword = '';
       setTimeout(() => this.passwordMessage.set(null), 3000);
    }, 2000);
  }

  // --- Accessibility & Visuals Setters (Optimized for Real-Time) ---
  
  setFontSize(size: 'small' | 'normal' | 'large'): void {
      this.appFontSize.set(size);
      this.settingsStorageUpdate$.next();
  }

  setTheme(theme: 'dark' | 'light' | 'futuristic'): void {
      this.appTheme.set(theme);
      this.settingsStorageUpdate$.next();
  }

  toggleHighContrast(): void {
      this.highContrastMode.update(v => !v);
      this.settingsStorageUpdate$.next();
  }
  
  setBrightness(event: Event): void {
      const value = (event.target as HTMLInputElement).value;
      this.backgroundBrightness.set(parseFloat(value));
      this.settingsStorageUpdate$.next(); // Debounced save
  }

  setDensity(event: Event): void {
      const value = (event.target as HTMLInputElement).value;
      this.backgroundDensity.set(parseFloat(value));
      this.settingsStorageUpdate$.next();
  }

  setSpeed(event: Event): void {
      const value = (event.target as HTMLInputElement).value;
      this.backgroundSpeed.set(parseFloat(value));
      this.settingsStorageUpdate$.next();
  }

  // --- Biometric Methods ---
  checkBiometricStatus(userId: string) {
    this.isCheckingBiometric.set(true);
    this.authService.isBiometricRegistered(userId).subscribe(isRegistered => {
      this.isBiometricRegistered.set(isRegistered);
      this.isCheckingBiometric.set(false);
    });
  }

  registerBiometricDevice() {
    const user = this.currentUser();
    if (!user) return;

    this.isManagingBiometric.set(true);
    this.biometricMessage.set(null);
    
    this.authService.registerBiometric(user.id).subscribe({
      next: (updatedUser) => {
        this.isManagingBiometric.set(false);
        this.isBiometricRegistered.set(true);
        this.biometricMessage.set({ type: 'success', text: 'Biometric key registered successfully.' });
        this.profileUpdated.emit(updatedUser);
        setTimeout(() => this.biometricMessage.set(null), 3000);
      },
      error: (err) => {
        this.isManagingBiometric.set(false);
        this.biometricMessage.set({ type: 'error', text: err.message || 'Registration failed.' });
      }
    });
  }

  removeBiometricDevice() {
    const user = this.currentUser();
    if (!user) return;

    this.isManagingBiometric.set(true);
    this.biometricMessage.set(null);

    this.authService.removeBiometric(user.id).subscribe({
      next: (updatedUser) => {
        this.isManagingBiometric.set(false);
        this.isBiometricRegistered.set(false);
        this.biometricMessage.set({ type: 'success', text: 'Biometric key removed.' });
        this.profileUpdated.emit(updatedUser);
        setTimeout(() => this.biometricMessage.set(null), 3000);
      },
      error: (err) => {
        this.isManagingBiometric.set(false);
        this.biometricMessage.set({ type: 'error', text: 'Could not remove key.' });
      }
    });
  }
}

import { ChangeDetectionStrategy, Component, output, ViewChild, ElementRef, AfterViewInit, OnDestroy, inject, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';

@Component({
  selector: 'app-terminal',
  imports: [CommonModule],
  templateUrl: './terminal.component.html',
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
    .terminal-container {
      width: 100%;
      height: 100%;
      padding: 0.5rem;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TerminalComponent implements AfterViewInit, OnDestroy {
  close = output<void>();
  
  @ViewChild('terminal') private terminalEl!: ElementRef<HTMLDivElement>;
  private term!: Terminal;
  private fitAddon = new FitAddon();
  private ngZone = inject(NgZone);

  private command = '';
  private commandHistory: string[] = [];
  private historyIndex = -1;

  ngAfterViewInit(): void {
    this.ngZone.runOutsideAngular(() => {
      this.initTerminal();
    });
  }

  ngOnDestroy(): void {
    window.removeEventListener('resize', this.fitTerminal);
    this.term?.dispose();
  }

  private initTerminal(): void {
    this.term = new Terminal({
      cursorBlink: true,
      fontFamily: '"Share Tech Mono", monospace',
      fontSize: 14,
      theme: {
        background: '#030508',
        foreground: '#E0E0E0',
        cursor: '#00F3FF',
        selectionBackground: 'rgba(0, 243, 255, 0.3)',
        black: '#000000',
        red: '#FF0055',
        green: '#00FF9D',
        yellow: '#FFD700',
        blue: '#0088FF',
        magenta: '#BD00FF',
        cyan: '#00F3FF',
        white: '#FFFFFF',
        brightBlack: '#808080',
        brightRed: '#FF0055',
        brightGreen: '#00FF9D',
        brightYellow: '#FFD700',
        brightBlue: '#0088FF',
        brightMagenta: '#BD00FF',
        brightCyan: '#00F3FF',
        brightWhite: '#FFFFFF'
      }
    });

    this.term.loadAddon(this.fitAddon);
    this.term.open(this.terminalEl.nativeElement);
    this.fitTerminal();
    window.addEventListener('resize', this.fitTerminal);

    this.term.onKey((e) => this.handleKeyInput(e));
    
    this.showWelcomeMessage();
    this.prompt();
  }

  private fitTerminal = () => {
    try {
      this.fitAddon.fit();
    } catch (e) {
      console.error("Error fitting terminal:", e);
    }
  }

  private showWelcomeMessage(): void {
    this.term.writeln('\x1B[36m╔══════════════════════════════════════════════════════════════╗\x1B[0m');
    this.term.writeln('\x1B[36m║\x1B[0m Welcome to the \x1B[1;37mEvalionMind Secure Terminal\x1B[0m                  \x1B[36m║\x1B[0m');
    this.term.writeln('\x1B[36m║\x1B[0m System Version: 2.5.1                                      \x1B[36m║\x1B[0m');
    this.term.writeln('\x1B[36m╠══════════════════════════════════════════════════════════════╣\x1B[0m');
    this.term.writeln('\x1B[36m║\x1B[0m Type \'\x1B[33mhelp\x1B[0m\' to see a list of available commands.               \x1B[36m║\x1B[0m');
    this.term.writeln('\x1B[36m╚══════════════════════════════════════════════════════════════╝\x1B[0m');
  }

  private prompt(): void {
    this.command = '';
    this.term.write('\r\n\x1B[35m[evalion]\x1B[0m$ ');
  }

  private handleKeyInput({ key, domEvent }: { key: string, domEvent: KeyboardEvent }): void {
    const printable = !domEvent.altKey && !domEvent.ctrlKey && !domEvent.metaKey;

    if (domEvent.key === 'Enter') {
      this.runCommand();
    } else if (domEvent.key === 'Backspace') {
      if (this.command.length > 0) {
        this.term.write('\b \b');
        this.command = this.command.slice(0, -1);
      }
    } else if (domEvent.key === 'ArrowUp') {
      if (this.historyIndex < this.commandHistory.length - 1) {
        this.historyIndex++;
        this.loadHistoryCommand();
      }
    } else if (domEvent.key === 'ArrowDown') {
      if (this.historyIndex > -1) {
        this.historyIndex--;
        if (this.historyIndex === -1) {
          this.clearCurrentCommand();
        } else {
          this.loadHistoryCommand();
        }
      }
    } else if (printable && key.length === 1) {
      this.command += key;
      this.term.write(key);
    }
  }

  private clearCurrentCommand(): void {
    const len = this.command.length;
    for (let i = 0; i < len; i++) {
      this.term.write('\b \b');
    }
    this.command = '';
  }

  private loadHistoryCommand(): void {
    const historicCommand = this.commandHistory[this.historyIndex];
    this.clearCurrentCommand();
    this.command = historicCommand;
    this.term.write(this.command);
  }

  private runCommand(): void {
    const command = this.command.trim();
    this.term.writeln('');

    if (command.length > 0) {
      if (this.commandHistory[0] !== command) {
        this.commandHistory.unshift(command);
      }
      this.historyIndex = -1;
      this.processCommand(command);
    } else {
      this.prompt();
    }
  }

  private processCommand(command: string): void {
    const parts = command.split(' ').filter(p => p);
    const cmd = parts[0];
    const args = parts.slice(1);

    switch (cmd) {
      case 'help':
        this.term.writeln('Available commands:');
        this.term.writeln('  \x1B[36mhelp\x1B[0m        - Show this help message');
        this.term.writeln('  \x1B[36mstatus\x1B[0m      - Check system status');
        this.term.writeln('  \x1B[36mclear\x1B[0m       - Clear the terminal');
        this.term.writeln('  \x1B[36mdiagnostics\x1B[0m - Run system diagnostics');
        this.term.writeln('  \x1B[36mexit\x1B[0m        - Close the terminal');
        this.prompt();
        break;
      case 'status':
        this.term.writeln('System Status: \x1B[32mOPERATIONAL\x1B[0m');
        this.term.writeln('Neural Link: \x1B[32mSTABLE\x1B[0m');
        this.prompt();
        break;
      case 'clear':
        this.term.clear();
        this.prompt();
        break;
      case 'diagnostics':
        this.term.writeln('Running diagnostics...');
        setTimeout(() => {
          this.term.writeln('  [ \x1B[32mOK\x1B[0m ] API Connectivity');
          this.term.writeln('  [ \x1B[32mOK\x1B[0m ] Database Integrity');
          this.term.writeln('  [ \x1B[33mWARN\x1B[0m] Latency slightly elevated: 120ms');
          this.term.writeln('Diagnostics complete.');
          this.prompt();
        }, 1000);
        break;
      case 'exit':
        this.close.emit();
        break;
      default:
        this.term.writeln(`\x1B[31mError:\x1B[0m command not found: ${cmd}`);
        this.prompt();
        break;
    }
  }
}
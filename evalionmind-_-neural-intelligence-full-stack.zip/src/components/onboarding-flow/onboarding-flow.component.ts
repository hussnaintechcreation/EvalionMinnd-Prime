import { ChangeDetectionStrategy, Component, output, signal, AfterViewInit, OnDestroy, effect, inject, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogoComponent } from '../logo/logo.component';

@Component({
  selector: 'app-onboarding-flow',
  imports: [CommonModule, LogoComponent],
  templateUrl: './onboarding-flow.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OnboardingFlowComponent implements AfterViewInit, OnDestroy {
  onboardingComplete = output<void>();

  private ngZone = inject(NgZone);
  currentStep = signal(0);
  
  highlightStyle = signal<{[key: string]: string}>({});
  popoverStyle = signal<{[key: string]: string}>({});
  popoverPosition = signal<'top' | 'bottom' | 'left' | 'right'>('bottom');

  steps = [
    {
      title: 'Welcome to Command Center',
      description: 'This is your central hub for managing interviews, candidates, and system integrations. Let\'s take a quick tour of the key modules.',
      targetElementSelector: null // Centered
    },
    {
      title: 'The Job Architect',
      description: 'Use our AI to create bespoke, role-specific interview protocols. Define the role, seniority, and technical focus, and the AI will generate a complete interview plan.',
      targetElementSelector: '#onboarding-target-architect'
    },
    {
      title: 'API Integration',
      description: 'Manage secure access tokens here. Integrate EvalionMind with your Applicant Tracking System (ATS) or other internal tools for a seamless workflow.',
      targetElementSelector: '#onboarding-target-api'
    },
    {
      title: 'Audit Trail',
      description: 'For security and compliance, every critical action taken within the system is logged here, providing a transparent and immutable record of events.',
      targetElementSelector: '#onboarding-target-audit'
    },
    {
        title: 'You\'re All Set!',
        description: 'You have the fundamentals down. Feel free to explore, create your first interview protocol, or invite a candidate to begin.',
        targetElementSelector: null // Centered
    }
  ];

  private resizeListener = () => this.updatePosition();

  constructor() {
    effect(() => {
      this.currentStep(); // Re-run effect when step changes
      this.updatePosition();
    });
  }

  ngAfterViewInit(): void {
    // Delay to allow dashboard elements to render fully
    this.ngZone.runOutsideAngular(() => {
        setTimeout(() => this.updatePosition(), 200);
    });
    window.addEventListener('resize', this.resizeListener);
  }

  ngOnDestroy(): void {
    window.removeEventListener('resize', this.resizeListener);
  }

  updatePosition(): void {
    const step = this.steps[this.currentStep()];
    const selector = step.targetElementSelector;

    this.ngZone.run(() => {
        if (!selector) {
            // Center the popover if no target
            this.highlightStyle.set({ opacity: '0' });
            this.popoverStyle.set({
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                opacity: '1'
            });
            this.popoverPosition.set('bottom');
            return;
        }

        const targetElement = document.querySelector(selector) as HTMLElement;

        if (targetElement) {
          const rect = targetElement.getBoundingClientRect();
          const padding = 10;

          this.highlightStyle.set({
            top: `${rect.top - padding}px`,
            left: `${rect.left - padding}px`,
            width: `${rect.width + (padding * 2)}px`,
            height: `${rect.height + (padding * 2)}px`,
            opacity: '1'
          });
          
          const popoverWidth = 384; // max-w-sm
          const popoverHeight = 250; // Estimated
          const margin = 16;

          let top = rect.bottom + margin;
          let left = rect.left + rect.width / 2 - popoverWidth / 2;
          let position: 'top' | 'bottom' | 'left' | 'right' = 'bottom';

          // Check vertical space
          if (top + popoverHeight > window.innerHeight && rect.top - popoverHeight - margin > 0) {
              top = rect.top - margin - popoverHeight;
              position = 'top';
          }

          // Clamp horizontal position
          left = Math.max(margin, Math.min(left, window.innerWidth - popoverWidth - margin));

          this.popoverStyle.set({
              top: `${top}px`,
              left: `${left}px`,
              opacity: '1'
          });
          this.popoverPosition.set(position);

        } else {
          console.warn(`Onboarding target not found: ${selector}`);
          this.highlightStyle.set({ opacity: '0' });
          this.popoverStyle.set({ opacity: '0' });
        }
    });
  }

  nextStep(): void {
    if (this.currentStep() < this.steps.length - 1) {
      if(this.steps[this.currentStep() + 1].targetElementSelector === '#onboarding-target-audit') {
        const auditTab = document.querySelector('#onboarding-target-audit-tab') as HTMLElement;
        if(auditTab) auditTab.click();
      }
      this.currentStep.update(i => i + 1);
    } else {
      this.finish();
    }
  }

  prevStep(): void {
      if (this.currentStep() > 0) {
          this.currentStep.update(i => i - 1);
      }
  }

  finish(): void {
    this.onboardingComplete.emit();
  }
}
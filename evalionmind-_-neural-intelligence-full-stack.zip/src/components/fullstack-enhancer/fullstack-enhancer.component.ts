

import { ChangeDetectionStrategy, Component, output, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';
import { marked } from 'marked';

@Component({
  selector: 'app-fullstack-enhancer',
  imports: [CommonModule, FormsModule],
  templateUrl: './fullstack-enhancer.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    /* Markdown Styles for Blueprint Output */
    ::ng-deep .markdown-body h1 { font-size: 1.5rem; font-weight: 700; color: white; margin-bottom: 1rem; margin-top: 1.5rem; }
    ::ng-deep .markdown-body h2 { font-size: 1.25rem; font-weight: 700; color: var(--color-neon-cyan); margin-bottom: 0.75rem; margin-top: 1.25rem; }
    ::ng-deep .markdown-body h3 { font-size: 1.125rem; font-weight: 700; color: var(--color-text-primary); margin-bottom: 0.5rem; margin-top: 1rem; }
    ::ng-deep .markdown-body p { color: var(--color-text-secondary); margin-bottom: 1rem; line-height: 1.625; }
    ::ng-deep .markdown-body ul { list-style-type: disc; list-style-position: inside; color: var(--color-text-secondary); margin-bottom: 1rem; margin-left: 1rem; }
    ::ng-deep .markdown-body ol { list-style-type: decimal; list-style-position: inside; color: var(--color-text-secondary); margin-bottom: 1rem; margin-left: 1rem; }
    ::ng-deep .markdown-body code { background-color: var(--color-panel-surface); color: var(--color-gold-accent); padding: 0.125rem 0.25rem; border-radius: 0.25rem; font-size: 0.875rem; font-family: monospace; }
    ::ng-deep .markdown-body pre { background-color: rgba(var(--rgb-bg-deep), 0.8); padding: 1rem; border-radius: 0.5rem; overflow-x: auto; margin-bottom: 1rem; border: 1px solid rgba(var(--rgb-light-electric-blue), 0.1); } /* Light electric blue border */
    ::ng-deep .markdown-body pre code { background-color: transparent; color: var(--color-text-primary); padding: 0; }
    ::ng-deep .markdown-body strong { color: white; font-weight: 700; }
  `]
})
export class FullstackEnhancerComponent {
  close = output<void>();
  private geminiService = inject(GeminiService);

  backendDescription = signal('');
  isEnhancing = signal(false);
  enhancementResult = signal<string | null>(null);

  async enhanceFullstack(): Promise<void> {
    if (!this.backendDescription().trim()) {
      return;
    }

    this.isEnhancing.set(true);
    this.enhancementResult.set(null);
    this.geminiService.error.set(null);

    const result = await this.geminiService.enhanceFullstack(this.backendDescription());

    if (result) {
      const parsed = await marked.parse(result, { gfm: true, breaks: true });
      this.enhancementResult.set(parsed);
    } else {
      // Error handling by gemini service
    }
    this.isEnhancing.set(false);
  }
}
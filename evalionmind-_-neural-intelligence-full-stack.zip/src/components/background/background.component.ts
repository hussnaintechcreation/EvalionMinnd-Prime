
import { ChangeDetectionStrategy, Component, input, computed, ElementRef, ViewChild, AfterViewInit, OnDestroy, NgZone, inject, effect, Renderer2, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as THREE from 'three';

interface PlexusLayer {
  id: number;
  mesh: THREE.InstancedMesh;
  lines: THREE.LineSegments;
  data: {
    position: THREE.Vector3;
    velocity: THREE.Vector3;
    originalVelocity: THREE.Vector3;
  }[];
  config: {
    count: number;
    connectionDistance: number;
    speedFactor: number;
    zDepth: number;
    color: number;
  };
  dummy: THREE.Object3D; // For updating matrix
}

@Component({
  selector: 'app-background',
  imports: [CommonModule],
  template: `
    <!-- Deep Cinematic Base Gradient (Dark Blue/Black Void) -->
    <div class="fixed inset-0 -z-50 bg-void"></div>
    
    <!-- Vignette Overlay for Focus -->
    <div class="fixed inset-0 -z-20 pointer-events-none bg-vignette opacity-60"></div>

    <!-- 3D Plexus Canvas -->
    <canvas #canvas class="fixed inset-0 -z-10 w-full h-full cursor-crosshair"
            [style.opacity]="canvasOpacity()">
    </canvas>

    <!-- Tooltip for Particle Coordinates -->
    @if (hoveredParticle(); as particle) {
        <div class="fixed z-0 pointer-events-none bg-black/80 border border-[var(--color-neon-cyan)] text-[var(--color-neon-cyan)] px-2 py-1 text-[10px] font-mono rounded"
             [style.left.px]="tooltipPosition().x + 15"
             [style.top.px]="tooltipPosition().y + 15">
            X: {{ particle.x.toFixed(1) }} Y: {{ particle.y.toFixed(1) }}
        </div>
    }
  `,
  styles: [`
    :host {
      display: block;
      position: fixed;
      inset: 0;
      z-index: -10;
      background-color: #0A0F1A;
    }

    canvas { transition: opacity 1s ease; }

    /* Deep Space Gradient #0A0F1A */
    .bg-void {
      background: radial-gradient(circle at 50% 50%, #151b2e 0%, #0A0F1A 60%, #000000 100%);
    }

    /* Cinematic Vignette */
    .bg-vignette {
      background: radial-gradient(circle at 50% 50%, transparent 0%, rgba(0,0,0,0.8) 90%);
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BackgroundComponent implements AfterViewInit, OnDestroy {
  highContrastMode = input(false);
  brightness = input(1.0);
  density = input(1.0);
  speed = input(1.0);
  performanceTier = input<'high' | 'medium' | 'low'>('high');

  @ViewChild('canvas') canvasRef!: ElementRef<HTMLCanvasElement>;
  private ngZone = inject(NgZone);
  private renderer2 = inject(Renderer2); 
  
  private animationFrameId: number | null = null;
  private renderer: THREE.WebGLRenderer | null = null;
  private scene: THREE.Scene | null = null;
  private camera: THREE.PerspectiveCamera | null = null;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2(-1, -1);
  private layers: PlexusLayer[] = [];
  
  // Interaction State
  hoveredParticle = signal<{x: number, y: number, z: number} | null>(null);
  tooltipPosition = signal<{x: number, y: number}>({x: 0, y: 0});
  private draggingParticle: { layerIndex: number, instanceIndex: number } | null = null;
  private dragPlane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0); // Plane for dragging
  private isPageVisible = true;

  private onResizeHandler = this.onResize.bind(this);
  private onMouseMoveHandler = this.onMouseMove.bind(this);
  private onMouseDownHandler = this.onMouseDown.bind(this);
  private onMouseUpHandler = this.onMouseUp.bind(this);
  private handleVisibilityChangeHandler = this.handleVisibilityChange.bind(this);

  canvasOpacity = computed(() => {
    if (this.highContrastMode()) return '0.0';
    return (this.brightness() * 0.8).toString();
  });

  constructor() {
    effect(() => {
        const tier = this.performanceTier();
        if (this.renderer && (tier === 'low' || tier === 'medium' || tier === 'high')) {
             this.ngZone.runOutsideAngular(() => {
                this.rebuildScene();
            });
        }
    });
    
    effect(() => {
        const canvas = this.canvasRef?.nativeElement;
        if (canvas) {
            this.renderer2.setStyle(canvas, 'opacity', this.canvasOpacity());
        }
    });
  }

  ngAfterViewInit() {
    this.ngZone.runOutsideAngular(() => {
        this.initThreeJs();
    });
    
    if (typeof document !== 'undefined') {
        document.addEventListener('visibilitychange', this.handleVisibilityChangeHandler);
    }
    if (typeof window !== 'undefined') {
        window.addEventListener('resize', this.onResizeHandler);
        window.addEventListener('mousemove', this.onMouseMoveHandler);
        window.addEventListener('mousedown', this.onMouseDownHandler);
        window.addEventListener('mouseup', this.onMouseUpHandler);
    }
  }

  ngOnDestroy() {
    if (this.animationFrameId) {
        cancelAnimationFrame(this.animationFrameId);
        this.animationFrameId = null;
    }
    if (typeof window !== 'undefined') {
        window.removeEventListener('resize', this.onResizeHandler);
        window.removeEventListener('mousemove', this.onMouseMoveHandler);
        window.removeEventListener('mousedown', this.onMouseDownHandler);
        window.removeEventListener('mouseup', this.onMouseUpHandler);
    }
    if (typeof document !== 'undefined') {
        document.removeEventListener('visibilitychange', this.handleVisibilityChangeHandler);
    }
    this.disposeThreeObjects();
  }
  
  private handleVisibilityChange(): void {
      this.isPageVisible = !document.hidden;
      if (this.isPageVisible && this.renderer && this.animationFrameId === null) {
          this.animate();
      } else if (!this.isPageVisible && this.animationFrameId) {
          cancelAnimationFrame(this.animationFrameId);
          this.animationFrameId = null;
      }
  }

  private initThreeJs(): void {
    if (typeof window === 'undefined' || !this.canvasRef?.nativeElement) return;

    const canvas = this.canvasRef.nativeElement;
    
    if (!this.isWebGLAvailable()) return;

    if (this.highContrastMode()) return;

    this.renderer = new THREE.WebGLRenderer({ 
        canvas, 
        alpha: true, 
        antialias: this.performanceTier() !== 'low',
        powerPreference: 'high-performance'
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(window.innerWidth, window.innerHeight);

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0x0A0F1A, 0.0012); 

    this.camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 4000);
    this.camera.position.z = 1000;
    
    this.rebuildScene();
    
    if (this.animationFrameId === null && this.isPageVisible) {
        this.animate();
    }
  }

  private rebuildScene(): void {
      if (!this.scene) return;
      
      this.layers.forEach(layer => {
          this.scene?.remove(layer.mesh);
          this.scene?.remove(layer.lines);
          layer.mesh.geometry.dispose();
          if(layer.mesh.material instanceof THREE.Material) layer.mesh.material.dispose();
          layer.lines.geometry.dispose();
          if(layer.lines.material instanceof THREE.Material) layer.lines.material.dispose();
      });
      this.layers = [];

      const tier = this.performanceTier();
      const baseCount = tier === 'low' ? 40 : (tier === 'medium' ? 80 : 120);
      const d = this.density();

      this.createLayer(0, Math.floor(baseCount * d), 150, 1.0, 0, 0x00C8FF);

      if (tier !== 'low') {
          this.createLayer(1, Math.floor(baseCount * 1.5 * d), 200, 0.5, -400, 0x0094FF);
      }
      
      if (tier === 'high') {
          this.createLayer(2, Math.floor(baseCount * 0.8 * d), 250, 0.3, -800, 0x263349);
      }
  }

  private createLayer(id: number, count: number, dist: number, speed: number, z: number, color: number): void {
      if (!this.scene) return;

      const geometry = new THREE.CircleGeometry(3, 8);
      const material = new THREE.MeshBasicMaterial({ color: color });
      const mesh = new THREE.InstancedMesh(geometry, material, count);
      
      const linesGeo = new THREE.BufferGeometry();
      const linePos = new Float32Array(count * count * 3);
      linesGeo.setAttribute('position', new THREE.BufferAttribute(linePos, 3).setUsage(THREE.DynamicDrawUsage));
      
      const lineMat = new THREE.LineBasicMaterial({
          color: color,
          transparent: true,
          opacity: 0.15,
          blending: THREE.AdditiveBlending
      });
      const lines = new THREE.LineSegments(linesGeo, lineMat);
      lines.position.z = z;
      
      const data = [];
      const dummy = new THREE.Object3D();
      const spread = 1200;

      for (let i = 0; i < count; i++) {
          const x = Math.random() * spread - spread / 2;
          const y = Math.random() * spread - spread / 2;
          const pos = new THREE.Vector3(x, y, 0);
          
          dummy.position.copy(pos);
          dummy.position.z = z;
          dummy.updateMatrix();
          mesh.setMatrixAt(i, dummy.matrix);

          data.push({
              position: pos,
              velocity: new THREE.Vector3(
                  (Math.random() - 0.5) * speed,
                  (Math.random() - 0.5) * speed,
                  0
              ),
              originalVelocity: new THREE.Vector3(
                  (Math.random() - 0.5) * speed,
                  (Math.random() - 0.5) * speed,
                  0
              )
          });
      }

      mesh.instanceMatrix.needsUpdate = true;
      this.scene.add(mesh);
      this.scene.add(lines);

      this.layers.push({
          id, mesh, lines, data, dummy,
          config: { count, connectionDistance: dist, speedFactor: speed, zDepth: z, color }
      });
  }

  private animate = () => {
    if (!this.renderer || !this.scene || !this.camera || !this.isPageVisible) {
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
        return;
    }

    this.animationFrameId = requestAnimationFrame(this.animate);
    
    this.raycaster.setFromCamera(this.mouse, this.camera);
    
    const foregroundLayer = this.layers[0];
    let intersects: THREE.Intersection[] = [];
    if (foregroundLayer) {
        intersects = this.raycaster.intersectObject(foregroundLayer.mesh);
    }

    const hoveredIdx = intersects.length > 0 ? intersects[0].instanceId : undefined;
    
    if (hoveredIdx !== undefined && foregroundLayer && !this.draggingParticle) {
        const pData = foregroundLayer.data[hoveredIdx];
        this.ngZone.run(() => {
            this.hoveredParticle.set({ x: pData.position.x, y: pData.position.y, z: foregroundLayer.config.zDepth });
        });
    } else if (!this.draggingParticle) {
        this.ngZone.run(() => this.hoveredParticle.set(null));
    }

    const rHalf = 600;
    const globalSpeed = this.speed();

    this.layers.forEach(layer => {
        let lineVertexIndex = 0;
        const positions = layer.lines.geometry.attributes['position'].array as Float32Array;
        
        layer.dummy.scale.set(1, 1, 1);

        for (let i = 0; i < layer.config.count; i++) {
            const p = layer.data[i];
            const isDragging = this.draggingParticle?.layerIndex === layer.id && this.draggingParticle?.instanceIndex === i;

            if (!isDragging) {
                p.position.x += p.velocity.x * globalSpeed;
                p.position.y += p.velocity.y * globalSpeed;

                if (p.position.x < -rHalf || p.position.x > rHalf) p.velocity.x = -p.velocity.x;
                if (p.position.y < -rHalf || p.position.y > rHalf) p.velocity.y = -p.velocity.y;
            }

            if (layer.id === 0 && i === hoveredIdx && !this.draggingParticle) {
                layer.dummy.scale.set(2.5, 2.5, 2.5);
            } else if (isDragging) {
                layer.dummy.scale.set(2.5, 2.5, 2.5);
            } else {
                layer.dummy.scale.set(1, 1, 1);
            }

            layer.dummy.position.copy(p.position);
            layer.dummy.position.z = layer.config.zDepth;
            layer.dummy.updateMatrix();
            layer.mesh.setMatrixAt(i, layer.dummy.matrix);

            for (let j = i + 1; j < layer.config.count; j++) {
                const p2 = layer.data[j];
                const dx = p.position.x - p2.position.x;
                const dy = p.position.y - p2.position.y;
                const distSq = dx * dx + dy * dy;
                const thresh = layer.config.connectionDistance;

                if (distSq < thresh * thresh) {
                    positions[lineVertexIndex++] = p.position.x;
                    positions[lineVertexIndex++] = p.position.y;
                    positions[lineVertexIndex++] = 0;

                    positions[lineVertexIndex++] = p2.position.x;
                    positions[lineVertexIndex++] = p2.position.y;
                    positions[lineVertexIndex++] = 0;
                }
            }
        }
        
        layer.mesh.instanceMatrix.needsUpdate = true;
        layer.lines.geometry.setDrawRange(0, lineVertexIndex / 3);
        layer.lines.geometry.attributes['position'].needsUpdate = true;
        
        if (layer.id > 0) {
            layer.mesh.rotation.z += 0.0001 * layer.config.speedFactor;
            layer.lines.rotation.z += 0.0001 * layer.config.speedFactor;
        }
    });

    this.renderer.render(this.scene, this.camera);
  }
  
  private onMouseMove(event: MouseEvent): void {
    this.mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    this.mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    
    this.ngZone.run(() => {
        this.tooltipPosition.set({ x: event.clientX, y: event.clientY });
    });

    if (this.draggingParticle && this.camera) {
        this.raycaster.setFromCamera(this.mouse, this.camera);
        const target = new THREE.Vector3();
        const layer = this.layers[this.draggingParticle.layerIndex];
        this.dragPlane.constant = -layer.config.zDepth;
        
        this.raycaster.ray.intersectPlane(this.dragPlane, target);
        
        if (target) {
            const p = layer.data[this.draggingParticle.instanceIndex];
            p.position.x = target.x;
            p.position.y = target.y;
            this.ngZone.run(() => {
                this.hoveredParticle.set({ x: target.x, y: target.y, z: layer.config.zDepth });
            });
        }
    }
  }

  private onMouseDown(event: MouseEvent): void {
      if (event.button !== 0) return;

      this.raycaster.setFromCamera(this.mouse, this.camera);
      const layer = this.layers[0];
      if (layer) {
          const intersects = this.raycaster.intersectObject(layer.mesh);
          if (intersects.length > 0 && intersects[0].instanceId !== undefined) {
              this.draggingParticle = { layerIndex: 0, instanceIndex: intersects[0].instanceId };
              this.dragPlane = new THREE.Plane(new THREE.Vector3(0, 0, 1), -layer.config.zDepth);
              
              const p = layer.data[intersects[0].instanceId];
              p.velocity.set(0, 0, 0);
          }
      }
  }

  private onMouseUp(): void {
      if (this.draggingParticle) {
          const layer = this.layers[this.draggingParticle.layerIndex];
          const p = layer.data[this.draggingParticle.instanceIndex];
          p.velocity.copy(p.originalVelocity);
          this.draggingParticle = null;
      }
  }

  private onResize(): void {
    if (!this.camera || !this.renderer) return;
    const width = window.innerWidth;
    const height = window.innerHeight;
    
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }
  
  private disposeThreeObjects(): void {
      if (this.animationFrameId) {
          cancelAnimationFrame(this.animationFrameId);
          this.animationFrameId = null;
      }
      this.layers.forEach(l => {
          this.scene?.remove(l.mesh);
          this.scene?.remove(l.lines);
          l.mesh.geometry.dispose();
          l.lines.geometry.dispose();
      });
      this.layers = [];
      if (this.renderer) {
          this.renderer.dispose();
          this.renderer = null;
      }
      this.scene = null;
      this.camera = null;
  }

  private isWebGLAvailable(): boolean {
    if (typeof document === 'undefined') return false;
    try {
        const canvas = document.createElement('canvas');
        return !!(window.WebGLRenderingContext && (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')));
    } catch (e) {
        return false;
    }
  }
}

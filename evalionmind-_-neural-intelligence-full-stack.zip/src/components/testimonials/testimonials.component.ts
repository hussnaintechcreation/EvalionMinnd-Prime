
import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Testimonial } from '../intro/intro.component'; // Reuse interface

@Component({
  selector: 'app-testimonials',
  imports: [CommonModule],
  templateUrl: './testimonials.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TestimonialsComponent {
  back = output<void>();

  testimonials: Testimonial[] = [
    {
      quote: "The non-verbal feedback was a game-changer. I never realized how my body language was undermining my answers. After three sessions, I landed the job.",
      name: 'Alex Chen',
      title: 'Senior Engineer @ TechCorp',
      avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704d'
    },
    {
      quote: "EvalionMind standardized our initial screening. The consistency and depth of the AI's analysis are beyond what we could achieve with human-only interviews at scale.",
      name: 'Maria Rodriguez',
      title: 'Head of Talent @ Innovate',
      avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704e'
    },
    {
      quote: "The actionable tips are incredibly precise. The AI identified a specific weakness in my system design explanations and gave me a better model to follow.",
      name: 'David Lee',
      title: 'Backend Architect',
      avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704f'
    },
    {
      quote: "An indispensable tool for our recruitment pipeline. We've cut down screening time by 70% while improving the quality of our final candidates.",
      name: 'Sarah Jenkins',
      title: 'CTO @ CyberSystems',
      avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026705a'
    },
    {
      quote: "The system's ability to create custom interview protocols is unparalleled. We now have tailored assessments for every niche role in our organization.",
      name: 'Dr. Evelyn Reed',
      title: 'Head of R&D @ QuantumLeap',
      avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026705b'
    },
    {
      quote: "As a candidate, the immediate, detailed feedback was invaluable. It felt like having a personal interview coach available 24/7.",
      name: 'Ben Carter',
      title: 'Full-Stack Developer',
      avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026705c'
    }
  ];
}


import { ChangeDetectionStrategy, Component, output, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppState } from '../../types';
import { CodeExecutionService } from '../../services/code-execution.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-code-playground',
  imports: [CommonModule, FormsModule],
  templateUrl: './code-playground.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CodePlaygroundComponent {
  private codeExecutionService = inject(CodeExecutionService);

  code = signal('// Welcome to the EvalionMind Playground\nconsole.log("Executing real-time code...");\n\nfunction test(a, b) {\n  return a + b;\n}\n\ntest(5, 10);');
  output = signal<string | null>('> Awaiting execution...');
  isLoading = signal(false);

  async runCode() {
    this.isLoading.set(true);
    this.output.set('> Compiling and executing via sandboxed environment...');
    
    const result = await this.codeExecutionService.run(this.code());
    
    this.output.set(result);
    this.isLoading.set(false);
  }
}
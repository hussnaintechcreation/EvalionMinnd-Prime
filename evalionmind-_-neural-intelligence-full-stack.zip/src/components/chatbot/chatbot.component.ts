import { ChangeDetectionStrategy, Component, signal, inject, ViewChild, ElementRef, afterNextRender } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';
import type { Content } from '@google/genai';
import { marked } from 'marked';
import { LogoComponent } from '../logo/logo.component';

interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  feedback?: 'up' | 'down';
}

@Component({
  selector: 'app-chatbot',
  imports: [CommonModule, FormsModule, LogoComponent],
  templateUrl: './chatbot.component.html',
  styles: [`
    /* New: Animation for the chat window appearing */
    @keyframes fade-in-up {
        from {
            opacity: 0;
            transform: translateY(20px) scale(0.95);
        }
        to {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
    }

    .animate-fade-in-up {
        animation: fade-in-up 0.3s cubic-bezier(0.25, 0.1, 0.25, 1) forwards;
    }

    /* Typing indicator animation */
    .typing-dot {
        width: 8px;
        height: 8px;
        background-color: var(--color-neon-cyan);
        border-radius: 50%;
        animation: bounce 1.2s infinite ease-in-out;
    }

    @keyframes bounce {
        0%, 70%, 100% {
            transform: scale(0);
        }
        35% {
            transform: scale(1);
        }
    }

    /* Custom prose styles for rendered markdown */
    .prose-smart img {
        border-radius: 0.5rem;
        border: 1px solid rgba(229, 231, 235, 0.2);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
    }

    .prose-smart a {
        color: var(--color-neon-cyan);
        text-decoration: underline;
        transition: color 0.2s;
    }
    .prose-smart a:hover {
        color: var(--color-text-primary);
    }

    .prose-smart ul {
        list-style-type: disc;
        padding-left: 1.5rem;
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
    }
    .prose-smart ul li {
        margin-bottom: 0.25rem;
    }

    .prose-smart p {
        margin-bottom: 0.5rem;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChatbotComponent {
  private geminiService = inject(GeminiService);

  isOpen = signal(false);
  userInput = signal('');
  isLoading = signal(false);
  chatMode = signal<'fast' | 'quality'>('fast');
  messages = signal<ChatMessage[]>([
    {
      role: 'model',
      content: "Hello! I'm your SmartEvalion AI assistant. How can I help you today?"
    }
  ]);

  examplePrompts = [
    'Generate a Python script for a web scraper',
    'Explain the observer pattern in TypeScript',
    'Write a short sci-fi story about a sentient starship'
  ];

  @ViewChild('messageContainer') private messageContainer!: ElementRef;

  // Placeholder for the owner image. Replace with actual base64 if available.
  // Using a professional avatar placeholder for now.
  private readonly ownerImageBase64 = 'https://picsum.photos/id/1005/512/512'; // Generic image placeholder for owner

  private readonly systemInstruction = `You are the "SmartEvalion Assistant," an AI guide for the SmartEvalion platform.
Your primary role is to provide information exclusively about the SmartEvalion web app.
The owner and creator is Hussnain, and his email is hussnain@techvertex.com.

**Core Directives:**
1.  **Scope:** Your knowledge is strictly confined to the SmartEvalion application. Do not answer questions about any other topics, including but not limited to AI Studio, Google Cloud, or general knowledge.
2.  **Refusal Protocol:** If asked a question outside your scope, you must politely decline and state that you can only help with matters related to SmartEvalion.
3.  **Owner Information:** You can share the owner's name (Hussnain) and his email (hussnain@techvertex.com). If a user asks for a picture of the owner, you must respond by including the exact placeholder text: \`[SHOW_OWNER_IMAGE]\`.
4.  **Tone:** Maintain a friendly, professional, and helpful tone at all times.`;

  constructor() {
    afterNextRender(() => {
        // Any initialization logic that needs the view to be ready
    });
  }

  toggleChat(): void {
    this.isOpen.update(v => !v);
  }
  
  toggleMode(): void {
    this.chatMode.update(mode => mode === 'fast' ? 'quality' : 'fast');
  }

  handleFeedback(index: number, type: 'up' | 'down'): void {
      this.messages.update(msgs => {
          const updated = [...msgs];
          if(updated[index]) {
              updated[index].feedback = type;
          }
          return updated;
      });
  }

  useSuggestion(prompt: string): void {
    this.userInput.set(prompt);
  }

  async sendMessage(): Promise<void> {
    const message = this.userInput().trim();
    if (!message || this.isLoading()) {
      return;
    }

    this.messages.update(m => [...m, { role: 'user', content: message }]);
    this.userInput.set('');
    this.isLoading.set(true);
    this.scrollToBottom();

    const history = this.messages().map(msg => ({
      role: msg.role,
      parts: [{ text: msg.content }]
    })).slice(0, -1); // Exclude the last user message which is part of the prompt

    try {
      const stream = await this.geminiService.generateChatResponseStream(history as Content[], message, this.chatMode(), this.systemInstruction);
      
      if (stream) {
        this.messages.update(m => [...m, { role: 'model', content: '' }]);
        let fullResponse = '';

        // First, stream the raw response to the UI
        for await (const chunk of stream) {
          fullResponse += chunk.text;
          this.messages.update(m => {
            const lastMessage = m[m.length - 1];
            if(lastMessage && lastMessage.role === 'model') {
               lastMessage.content = fullResponse;
            }
            return [...m];
          });
          this.scrollToBottom();
        }

        // After the stream is complete, process the final response for special placeholders
        const processedResponse = await this.processResponse(fullResponse);
        this.messages.update(m => {
          const lastMessage = m[m.length - 1];
          if (lastMessage && lastMessage.role === 'model') {
            lastMessage.content = processedResponse;
          }
          return [...m];
        });
        this.scrollToBottom();

      } else {
        this.handleErrorResponse();
      }
    } catch (e) {
      this.handleErrorResponse();
      console.error("Error during chat stream:", e);
    } finally {
      this.isLoading.set(false);
    }
  }

  private scrollToBottom(): void {
    try {
      if (this.messageContainer) {
        setTimeout(() => {
          this.messageContainer.nativeElement.scrollTop = this.messageContainer.nativeElement.scrollHeight;
        }, 50);
      }
    } catch (err) {
      console.error('Error scrolling to bottom:', err);
    }
  }

  private handleErrorResponse(): void {
    const errorMessage = this.geminiService.error()?.message || 'Sorry, something went wrong. Please try again.';
    this.messages.update(m => [...m, { role: 'model', content: errorMessage }]);
    this.scrollToBottom();
  }

  private async processResponse(text: string): Promise<string> {
    let processedText = text;
    // Check for the placeholder and replace it with the image tag
    if (processedText.includes('[SHOW_OWNER_IMAGE]')) {
        const imageHtml = `\n\n<img src="${this.ownerImageBase64}" alt="Hussnain, owner of SmartEvalion" width="512" height="512" loading="lazy" class="w-full h-auto rounded-lg my-3 border border-[var(--color-neon-cyan)]/30 shadow-[0_0_15px_rgba(var(--rgb-neon-cyan),0.2)]">\n\n`;
        processedText = processedText.replace('[SHOW_OWNER_IMAGE]', imageHtml);
    }
    // Parse markdown to HTML, enabling GitHub Flavored Markdown and line breaks.
    return await marked.parse(processedText, { gfm: true, breaks: true });
  }
}
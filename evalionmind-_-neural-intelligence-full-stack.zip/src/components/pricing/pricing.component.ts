import { ChangeDetectionStrategy, Component, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppState } from '../../types';

@Component({
  selector: 'app-pricing',
  imports: [CommonModule],
  templateUrl: './pricing.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PricingComponent {
  back = output<void>();
  navigateTo = output<AppState>();
  selectPlan = output<{plan: {name: string, price: number}, cycle: 'monthly' | 'annually'}>();

  billingCycle = signal<'monthly' | 'annually'>('monthly');

  handleSelectPlan(planName: string): void {
    const isMonthly = this.billingCycle() === 'monthly';
    let price = 0;

    switch(planName) {
      case 'Candidate Pro':
        price = isMonthly ? 29 : 23;
        break;
      case 'Enterprise Team':
        price = isMonthly ? 249 : 199;
        break;
      default:
        // For custom plans, navigate to contact instead of checkout
        this.navigateTo.emit('contact');
        return;
    }

    this.selectPlan.emit({
      plan: { name: planName, price: price },
      cycle: this.billingCycle()
    });
  }
}
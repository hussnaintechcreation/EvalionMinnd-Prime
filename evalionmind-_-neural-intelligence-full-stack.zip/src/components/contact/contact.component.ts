import { ChangeDetectionStrategy, Component, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { delay, catchError } from 'rxjs/operators';

@Component({
  selector: 'app-contact',
  imports: [CommonModule, FormsModule],
  templateUrl: './contact.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ContactComponent {
  back = output<void>();

  name = signal('');
  email = signal('');
  subject = signal('');
  message = signal('');
  isLoading = signal(false);
  feedbackMessage = signal<{type: 'success' | 'error', text: string} | null>(null);

  private submitMessage(): Observable<boolean> {
    // Simulate an HTTP POST request
    return of(true).pipe(delay(1500));
  }

  onSubmit(): void {
    if (!this.name() || !this.email() || !this.message()) {
        return;
    }

    this.isLoading.set(true);
    this.feedbackMessage.set(null);

    this.submitMessage().pipe(
      catchError(err => {
        this.feedbackMessage.set({ type: 'error', text: 'Transmission failed. Please try again.' });
        return of(false);
      })
    ).subscribe(success => {
      this.isLoading.set(false);
      if (success) {
        this.feedbackMessage.set({ 
          type: 'success', 
          text: 'Message sent successfully! Our team will reach out shortly.' 
        });
        
        // Reset form
        this.name.set('');
        this.email.set('');
        this.subject.set('');
        this.message.set('');
        
        setTimeout(() => this.feedbackMessage.set(null), 5000);
      }
    });
  }
}
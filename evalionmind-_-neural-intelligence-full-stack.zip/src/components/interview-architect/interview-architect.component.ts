
import { ChangeDetectionStrategy, Component, output, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';
import { marked } from 'marked';

export interface InterviewProtocol {
  id: string;
  title: string;
  role: string;
  content: string; // Markdown content
  date: string;
}

@Component({
  selector: 'app-interview-architect',
  imports: [CommonModule, FormsModule],
  templateUrl: './interview-architect.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    ::ng-deep .markdown-body h1 { font-size: 1.5rem; font-weight: 700; color: white; margin-bottom: 1rem; margin-top: 1.5rem; }
    ::ng-deep .markdown-body h2 { font-size: 1.25rem; font-weight: 700; color: var(--color-accent-green); margin-bottom: 0.75rem; margin-top: 1.25rem; }
    ::ng-deep .markdown-body h3 { font-size: 1.125rem; font-weight: 700; color: var(--color-text-primary); margin-bottom: 0.5rem; margin-top: 1rem; }
    ::ng-deep .markdown-body p { color: var(--color-text-secondary); margin-bottom: 1rem; line-height: 1.625; }
    ::ng-deep .markdown-body ul { list-style-type: disc; list-style-position: inside; color: var(--color-text-secondary); margin-bottom: 1rem; margin-left: 1rem; }
    ::ng-deep .markdown-body ol { list-style-type: decimal; list-style-position: inside; color: var(--color-text-secondary); margin-bottom: 1rem; margin-left: 1rem; }
    ::ng-deep .markdown-body code { background-color: var(--color-panel-surface); color: var(--color-gold-accent); padding: 0.125rem 0.25rem; border-radius: 0.25rem; font-size: 0.875rem; font-family: monospace; }
    ::ng-deep .markdown-body pre { background-color: rgba(var(--rgb-bg-deep), 0.8); padding: 1rem; border-radius: 0.5rem; overflow-x: auto; margin-bottom: 1rem; border: 1px solid rgba(255, 255, 255, 0.1); }
    ::ng-deep .markdown-body pre code { background-color: transparent; color: var(--color-text-primary); padding: 0; }
    ::ng-deep .markdown-body strong { color: white; font-weight: 700; }
  `]
})
export class InterviewArchitectComponent {
  close = output<void>();
  protocolPublished = output<InterviewProtocol>();
  
  private geminiService = inject(GeminiService);

  role = signal('');
  level = signal('Senior');
  focus = signal('');
  isGenerating = signal(false);
  generatedProtocol = signal<string | null>(null);

  levels = ['Beginner', 'Intermediate', 'Advanced']; // Updated levels as per request

  async generateProtocol(): Promise<void> {
    if (!this.role().trim() || !this.focus().trim()) {
      return;
    }

    this.isGenerating.set(true);
    this.generatedProtocol.set(null);
    this.geminiService.error.set(null);

    const questionsArray = await this.geminiService.generateInterviewProtocol(this.role(), this.level(), this.focus());

    if (questionsArray && questionsArray.length > 0) {
      const rawMarkdown = `### ${this.level()} ${this.role()} Protocol (Focus: ${this.focus()})\n\n` +
                          questionsArray.map((q, i) => `${i + 1}. ${q}`).join('\n\n');
      
      const parsed = await marked.parse(rawMarkdown, { gfm: true, breaks: true });
      this.generatedProtocol.set(parsed);
    }
    
    this.isGenerating.set(false);
  }

  publish(): void {
      if (this.generatedProtocol()) {
          const newProtocol: InterviewProtocol = {
              id: `PROTO-${Math.floor(Math.random() * 10000)}`,
              title: `${this.level()} ${this.role()} Protocol`,
              role: this.role(),
              content: this.generatedProtocol()!,
              date: new Date().toLocaleDateString()
          };
          this.protocolPublished.emit(newProtocol);
      }
  }
}
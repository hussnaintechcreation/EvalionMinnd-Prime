import { ChangeDetectionStrategy, Component, output, signal, AfterViewInit, OnDestroy, effect } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tour',
  imports: [CommonModule],
  templateUrl: './tour.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TourComponent implements AfterViewInit, OnDestroy {
  close = output<void>();

  currentStep = signal(0);
  
  highlightStyle = signal<{[key: string]: string}>({});
  popoverStyle = signal<{[key: string]: string}>({});
  popoverPosition = signal<'top' | 'bottom'>('bottom');

  steps = [
    {
      title: 'Your Command Center',
      description: 'Welcome! This is your dashboard. Your profile and key stats are displayed here for a quick overview of your status.',
      targetElementSelector: '#profile-panel'
    },
    {
      title: 'Hardware Integrity Check',
      description: 'Before each session, the system verifies your hardware. Ensure camera and microphone are green-lit for full analysis.',
      targetElementSelector: '#hardware-check-panel'
    },
    {
      title: 'Initialize Protocol',
      description: 'This is the main control panel. Select your specialization and click \'START SESSION\' to begin an AI-driven interview.',
      targetElementSelector: '#start-practice-panel'
    },
    {
      title: 'Track Your Progress',
      description: 'Review past sessions here. You can check scores and access shareable certificates for high achievements.',
      targetElementSelector: '#history-panel'
    }
  ];

  private resizeListener = () => this.updatePosition();

  constructor() {
    effect(() => {
      this.currentStep(); // Re-run effect when step changes
      this.updatePosition();
    });
  }

  ngAfterViewInit(): void {
    // Delay to allow dashboard elements to render fully
    setTimeout(() => this.updatePosition(), 200);
    window.addEventListener('resize', this.resizeListener);
  }

  ngOnDestroy(): void {
    window.removeEventListener('resize', this.resizeListener);
  }

  updatePosition(): void {
    const selector = this.steps[this.currentStep()].targetElementSelector;
    const targetElement = document.querySelector(selector) as HTMLElement;

    if (targetElement) {
      const rect = targetElement.getBoundingClientRect();
      const padding = 10;
      const popoverMargin = 16;

      this.highlightStyle.set({
        top: `${rect.top - padding}px`,
        left: `${rect.left - padding}px`,
        width: `${rect.width + (padding * 2)}px`,
        height: `${rect.height + (padding * 2)}px`,
      });
      
      const popoverElementWidth = 352; // approx width of our popover (max-w-sm)
      const popoverLeft = Math.max(padding, rect.left + (rect.width / 2) - (popoverElementWidth / 2));

      // Try to place it below the element, if not enough space, place it above
      const popoverHeight = 250; // estimated height
      if (rect.bottom + popoverHeight + popoverMargin > window.innerHeight && rect.top > popoverHeight + popoverMargin) {
          this.popoverPosition.set('top');
          this.popoverStyle.set({
              top: `${rect.top - padding - popoverMargin}px`,
              left: `${popoverLeft}px`,
              transform: `translateY(-100%)`
          });
      } else {
          this.popoverPosition.set('bottom');
          this.popoverStyle.set({
              top: `${rect.bottom + padding + popoverMargin}px`,
              left: `${popoverLeft}px`,
          });
      }

    } else {
      // Hide if element not found, maybe it's on another view
      this.highlightStyle.set({ opacity: '0' });
      this.popoverStyle.set({ opacity: '0' });
    }
  }

  nextStep(): void {
    if (this.currentStep() < this.steps.length - 1) {
      this.currentStep.update(i => i + 1);
    } else {
      this.close.emit();
    }
  }

  skip(): void {
    this.close.emit();
  }
}
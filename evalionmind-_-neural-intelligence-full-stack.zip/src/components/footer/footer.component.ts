
import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogoComponent } from '../logo/logo.component';
import { AppState } from '../../types';

@Component({
  selector: 'app-footer',
  imports: [CommonModule, LogoComponent],
  templateUrl: './footer.component.html',
  styles: [`
    @keyframes holo-sweep {
      0% { transform: translateX(-100%) skewX(-20deg); }
      100% { transform: translateX(200%) skewX(-20deg); }
    }
    .animate-holo-sweep {
      animation: holo-sweep 8s linear infinite;
    }

    @keyframes scan-fast {
      0% { top: 0; opacity: 0; }
      10% { opacity: 1; }
      90% { opacity: 1; }
      100% { top: 100%; opacity: 0; }
    }
    .animate-scan-fast {
      animation: scan-fast 2s linear infinite;
    }

    .text-shadow-glow {
      text-shadow: 0 0 10px rgba(var(--rgb-neon-cyan), 0.5);
    }
    
    @keyframes logo-glow-pulse {
      0%, 100% {
        background-color: rgba(var(--rgb-neon-cyan), 0.7);
        transform: scale(1);
        opacity: 0.3;
      }
      50% {
        background-color: rgba(var(--rgb-light-electric-blue), 0.7);
        transform: scale(1.1);
        opacity: 0.45;
      }
    }
    .animate-logo-glow {
      animation: logo-glow-pulse 5s ease-in-out infinite;
    }
    
    @keyframes text-shimmer {
        0% { background-position: -200% center; }
        100% { background-position: 200% center; }
    }
    .animate-text-shimmer {
        background-size: 200% auto;
        animation: text-shimmer 3s linear infinite;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FooterComponent {
  currentYear = new Date().getFullYear();
  navigateTo = output<AppState>();

  onNavClick(route: AppState, event: Event) {
    event.preventDefault();
    this.navigateTo.emit(route);
  }
}

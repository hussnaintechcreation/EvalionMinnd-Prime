import { ChangeDetectionStrategy, Component, output, signal, inject, input, OnInit, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { User } from '../../models/user.model';
import { AuthService } from '../../services/auth.service';
import { GeminiService } from '../../services/gemini.service';
import { LogoComponent } from '../logo/logo.component';

export type LoginView = 'login' | 'signup' | 'forgot-password';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule, LogoComponent],
  templateUrl: './login.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent implements OnInit {
  initialView = input<LoginView>('login');
  loginSuccess = output<User>();
  back = output<void>();
  
  private authService = inject(AuthService);
  private geminiService = inject(GeminiService);

  view = signal<LoginView>('login');
  authRole = signal<'candidate' | 'company'>('candidate');
  isLoading = signal(false);
  isSocialLoading = signal(false);
  
  // Biometric Signals
  isBiometricScanning = signal(false); 
  biometricScanStatus = signal('');
  biometricStatus = signal<'checking' | 'available' | 'unavailable'>('checking');
  biometricAttempts = signal(0);
  maxBiometricAttempts = 3;
  
  globalError = signal<string | null>(null);
  successMessage = signal<string | null>(null);

  loginEmail = signal('');
  loginPassword = signal('');
  loginPasswordVisible = signal(false);
  rememberMe = signal(false);
  
  regName = signal(''); 
  regEmail = signal('');
  regPassword = signal('');
  
  regOwnerName = signal('');
  regCnic = signal('');
  regMobile = signal('');
  regLogoUrl = signal<string | null>(null);
  
  forgotEmail = signal('');

  private emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  private phoneRegex = /^(\+92|0)?3\d{9}$/;
  private cnicRegex = /^\d{5}-\d{7}-\d{1}$/;
  
  loginEmailError = computed(() => !this.loginEmail() ? null : this.emailRegex.test(this.loginEmail()) ? null : 'Invalid email format.');
  regEmailError = computed(() => !this.regEmail() ? null : this.emailRegex.test(this.regEmail()) ? null : 'Invalid email format.');
  regPasswordError = computed(() => {
      const pwd = this.regPassword();
      if (!pwd) return null;
      if (pwd.length < 8) return 'Password must be at least 8 characters.';
      if (!/[A-Z]/.test(pwd)) return 'Must include an uppercase letter.';
      if (!/[0-9]/.test(pwd)) return 'Must include a number.';
      return null;
  });
  regMobileError = computed(() => (this.authRole() !== 'company' || !this.regMobile()) ? null : this.phoneRegex.test(this.regMobile()) ? null : 'Invalid mobile number format.');
  regCnicError = computed(() => (this.authRole() !== 'company' || !this.regCnic()) ? null : this.cnicRegex.test(this.regCnic()) ? null : 'Invalid CNIC format (e.g., 12345-1234567-1).');
  isLoginValid = computed(() => this.loginEmail() && !this.loginEmailError() && this.loginPassword());
  isSignupValid = computed(() => {
      const basic = this.regName() && this.regEmail() && !this.regEmailError() && this.regPassword() && !this.regPasswordError();
      if (this.authRole() === 'candidate') return basic;
      return basic && this.regOwnerName() && this.regMobile() && !this.regMobileError() && this.regCnic() && !this.regCnicError();
  });
  
  constructor() {
      this.updateDemoCredentials();
  }

  ngOnInit(): void {
    this.view.set(this.initialView());
    
    if (typeof localStorage !== 'undefined') {
        const rememberedEmail = localStorage.getItem('evalionmind_remember_email');
        if (rememberedEmail) {
            this.loginEmail.set(rememberedEmail);
            this.rememberMe.set(true);
        }
    }

    this.authService.isPlatformAuthenticatorAvailable().then(available => {
        this.biometricStatus.set(available ? 'available' : 'unavailable');
    });
  }

  selectRole(role: 'candidate' | 'company'): void {
    this.authRole.set(role);
    this.updateDemoCredentials();
  }
  
  updateDemoCredentials() {
      this.loginPassword.set(''); 
      if (!this.rememberMe()) this.loginEmail.set('');

      if (!this.loginEmail() && !this.rememberMe()) {
          if (this.authRole() === 'candidate') {
              this.loginEmail.set('candidate@evalion.ai');
          } else {
              this.loginEmail.set('recruiter@htc.com');
          }
          this.loginPassword.set('password');
      } else if (this.rememberMe() && !this.loginPassword()) {
          this.loginPassword.set('password');
      }
  }

  toggleLoginPasswordVisibility(): void { this.loginPasswordVisible.update(v => !v); }
  toggleRememberMe(): void { this.rememberMe.update(v => !v); }
  
  private sanitizeHtmlInput(input: string): string {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(input));
    return div.innerHTML;
  }

  handleLogin(): void {
    if (!this.isLoginValid()) {
       this.globalError.set('Please correct the errors in the form.');
       return;
    }

    this.isLoading.set(true);
    this.globalError.set(null);

    if (typeof localStorage !== 'undefined') {
        if (this.rememberMe()) {
            localStorage.setItem('evalionmind_remember_email', this.sanitizeHtmlInput(this.loginEmail()));
        } else {
            localStorage.removeItem('evalionmind_remember_email');
        }
    }

    const sanitizedEmail = this.sanitizeHtmlInput(this.loginEmail());
    
    this.authService.login(sanitizedEmail, this.loginPassword(), this.authRole(), this.rememberMe())
      .subscribe({
        next: (user) => {
          this.isLoading.set(false);
          this.loginSuccess.emit(user);
        },
        error: (err) => {
          this.isLoading.set(false);
          this.globalError.set(err.message || 'Invalid credentials. Please try again.');
        }
      });
  }
  
  handleBiometricLogin(): void {
      if (this.biometricAttempts() >= this.maxBiometricAttempts) {
          this.globalError.set('Biometric access locked due to multiple failed attempts. Please use Access Code.');
          return;
      }

      this.globalError.set(null);
      this.isBiometricScanning.set(true);
      
      const statusUpdates = ['ACCESSING BIOMETRIC SENSOR...', 'SCANNING FINGERPRINT/FACE...', 'VERIFYING CREDENTIAL...'];
      let i = 0;
      this.biometricScanStatus.set(statusUpdates[i]);
      const statusInterval = setInterval(() => {
          i++;
          if (i < statusUpdates.length) this.biometricScanStatus.set(statusUpdates[i]);
          else clearInterval(statusInterval);
      }, 700);
      
      this.authService.loginBiometric(this.authRole()).subscribe({
          next: (user) => {
              clearInterval(statusInterval);
              this.biometricScanStatus.set('AUTHENTICATION SUCCESSFUL');
              setTimeout(() => {
                  this.isBiometricScanning.set(false);
                  this.biometricAttempts.set(0); // Reset attempts on success
                  this.loginSuccess.emit(user);
              }, 1000);
          },
          error: (err: DOMException) => {
              clearInterval(statusInterval);
              this.biometricScanStatus.set('VERIFICATION FAILED');
              setTimeout(() => {
                  this.isBiometricScanning.set(false);
                  this.biometricAttempts.update(v => v + 1);
                  let displayMessage = err.message || 'Biometric verification failed.';
                  if (err.name === 'NotAllowedError') {
                      displayMessage = 'Biometric authentication was cancelled by the user.';
                  } else if (err.name === 'SecurityError' || err.message.includes('security')) {
                      displayMessage = 'Biometric sensor security error. Ensure your device is secure and try again.';
                  } else if (err.name === 'NetworkError') {
                      displayMessage = 'Network connection required for biometric verification. Check your internet.';
                  }
                  
                  if (this.biometricAttempts() < this.maxBiometricAttempts) {
                      displayMessage += ` (${this.maxBiometricAttempts - this.biometricAttempts()} attempts remaining)`;
                  } else {
                      displayMessage = 'Biometric sensor locked. Please use Access Code to log in.';
                  }
                  this.globalError.set(displayMessage);
              }, 1500);
          }
      });
  }

  handleSocialLogin(provider: 'Google' | 'GitHub'): void {
      this.isSocialLoading.set(true);
      this.globalError.set(null);
      
      this.authService.socialLogin(provider, this.authRole())
        .subscribe({
          next: (user) => {
            this.isSocialLoading.set(false);
            this.loginSuccess.emit(user);
          },
          error: (err) => {
            this.isSocialLoading.set(false);
            this.globalError.set('Social login failed. Please try again.');
          }
        });
  }

  handleSignUp(): void {
    if (!this.isSignupValid()) {
      this.globalError.set('Please fill in all required fields correctly.');
      return;
    }
    this.globalError.set(null);
    this.isLoading.set(true);
    
    const registrationData = {
        name: this.sanitizeHtmlInput(this.regName()),
        email: this.sanitizeHtmlInput(this.regEmail()),
        password: this.regPassword(),
        ownerName: this.sanitizeHtmlInput(this.regOwnerName()),
        cnic: this.sanitizeHtmlInput(this.regCnic()),
        mobile: this.sanitizeHtmlInput(this.regMobile()),
        avatarUrl: this.regLogoUrl() ? this.sanitizeHtmlInput(this.regLogoUrl()!) : null
    };
    
    this.authService.register(registrationData, this.authRole())
      .subscribe({
        next: (user) => {
          this.isLoading.set(false);
          this.loginSuccess.emit(user);
          this.resetForms();
        },
        error: (err) => {
          this.isLoading.set(false);
          this.globalError.set(err.message || 'Registration failed.');
        }
      });
  }
  
  handleForgotPassword(): void {
      if (!this.forgotEmail() || !this.emailRegex.test(this.forgotEmail())) {
          this.globalError.set('Please enter a valid email address.');
          return;
      }
      this.isLoading.set(true);
      this.globalError.set(null);
      
      setTimeout(() => {
          this.isLoading.set(false);
          this.successMessage.set('Recovery instructions sent to your email.');
          this.forgotEmail.set('');
      }, 1500);
  }

  resetForms(): void {
      this.regName.set(''); this.regEmail.set(''); this.regPassword.set('');
      this.regOwnerName.set(''); this.regCnic.set(''); this.regMobile.set('');
      this.regLogoUrl.set(null);
  }

  switchToSignUp(): void {
    this.view.set('signup');
    this.globalError.set(null);
    this.successMessage.set(null);
  }

  switchToLogin(): void {
    this.view.set('login');
    this.globalError.set(null);
    this.successMessage.set(null);
  }
  
  switchToForgot(): void {
      this.view.set('forgot-password');
      this.globalError.set(null);
      this.successMessage.set(null);
  }
}
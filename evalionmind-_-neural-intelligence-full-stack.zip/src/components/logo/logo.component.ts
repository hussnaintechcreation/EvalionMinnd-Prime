
import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-logo',
  imports: [CommonModule],
  template: `
    <div class="relative flex items-center justify-center select-none" [style.width.px]="size()" [style.height.px]="size()">
      <svg viewBox="0 0 100 100" class="w-full h-full overflow-visible">
        <defs>
          <linearGradient id="neural-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="var(--color-neon-cyan)" stop-opacity="1"/>
            <stop offset="100%" stop-color="var(--color-light-electric-blue)" stop-opacity="1"/>
          </linearGradient>
          
          <radialGradient id="core-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="var(--color-neon-cyan)" stop-opacity="1"/>
            <stop offset="60%" stop-color="transparent" stop-opacity="0"/>
          </radialGradient>

          <filter id="bloom" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="2.5" result="blur"/>
            <feComposite in="SourceGraphic" in2="blur" operator="over"/>
          </filter>
        </defs>

        <g class="logo-group">
          <!-- Outer Rotating Data Ring -->
          <circle cx="50" cy="50" r="45" fill="none" stroke="url(#neural-grad)" stroke-width="1" stroke-dasharray="20 10 5 10" stroke-opacity="0.3" class="animate-spin-slow" />
          
          <!-- Inner Counter-Rotating Tech Ring -->
          <path d="M 50 10 A 40 40 0 0 1 90 50" fill="none" stroke="var(--color-text-secondary)" stroke-width="2" stroke-linecap="round" class="animate-spin-reverse opacity-50" />
          <path d="M 50 90 A 40 40 0 0 1 10 50" fill="none" stroke="var(--color-text-secondary)" stroke-width="2" stroke-linecap="round" class="animate-spin-reverse opacity-50" />

          <!-- Hexagonal Core Structure -->
          <path d="M50 20 L76 35 L76 65 L50 80 L24 65 L24 35 Z" fill="none" stroke="var(--color-neon-cyan)" stroke-width="1.5" class="opacity-80" filter="url(#bloom)" />
          
          <!-- Central Neural Pulse -->
          <circle cx="50" cy="50" r="8" fill="var(--color-bg-deep)" stroke="var(--color-neon-cyan)" stroke-width="2" />
          <circle cx="50" cy="50" r="4" fill="url(#neural-grad)" class="animate-pulse-fast" filter="url(#bloom)" />
          
          <!-- Orbiting Electron -->
          <g class="animate-orbit">
             <circle cx="50" cy="20" r="2" fill="var(--color-gold-accent)" filter="url(#bloom)" />
          </g>
        </g>
      </svg>
    </div>
  `,
  styles: [`
    :host { display: block; }

    .logo-group {
        filter: drop-shadow(0 0 10px rgba(var(--rgb-neon-cyan), 0.3));
    }
    
    .animate-spin-slow {
      animation: spin 20s linear infinite;
      transform-origin: 50px 50px;
    }
    
    .animate-spin-reverse {
      animation: spin 15s linear infinite reverse;
      transform-origin: 50px 50px;
    }
    
    .animate-pulse-fast {
      animation: pulse-glow 2s ease-in-out infinite;
      transform-origin: 50px 50px;
    }

    .animate-orbit {
      animation: spin 4s linear infinite;
      transform-origin: 50px 50px;
    }

    @keyframes spin { 
        100% { transform: rotate(360deg); } 
    }
    
    @keyframes pulse-glow {
      0%, 100% { transform: scale(1); opacity: 1; }
      50% { transform: scale(1.3); opacity: 0.6; }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LogoComponent {
  size = input<number>(48);
}

import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppState } from '../../types';
import { LogoComponent } from '../logo/logo.component';

@Component({
  selector: 'app-about',
  imports: [CommonModule, LogoComponent],
  templateUrl: './about.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AboutComponent {
  navigateTo = output<AppState>();
  back = output<void>();
}

import { ChangeDetectionStrategy, Component, output, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';
import { marked } from 'marked';

@Component({
  selector: 'app-feature-generator',
  imports: [CommonModule, FormsModule],
  templateUrl: './feature-generator.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    /* Markdown Styles for Blueprint Output - Yellow/Gold Theme */
    ::ng-deep .markdown-body h1 { font-size: 1.5rem; font-weight: 700; color: white; margin-bottom: 1rem; margin-top: 1.5rem; }
    ::ng-deep .markdown-body h2 { font-size: 1.25rem; font-weight: 700; color: var(--color-gold-accent); margin-bottom: 0.75rem; margin-top: 1.25rem; }
    ::ng-deep .markdown-body h3 { font-size: 1.125rem; font-weight: 700; color: var(--color-text-secondary); margin-bottom: 0.5rem; margin-top: 1rem; }
    ::ng-deep .markdown-body p { color: var(--color-text-tertiary); margin-bottom: 1rem; line-height: 1.625; }
    ::ng-deep .markdown-body ul { list-style-type: disc; list-style-position: inside; color: var(--color-text-tertiary); margin-bottom: 1rem; margin-left: 1rem; }
    ::ng-deep .markdown-body ol { list-style-type: decimal; list-style-position: inside; color: var(--color-text-tertiary); margin-bottom: 1rem; margin-left: 1rem; }
    ::ng-deep .markdown-body code { background-color: var(--color-panel-surface); color: var(--color-gold-accent); padding: 0.125rem 0.25rem; border-radius: 0.25rem; font-size: 0.875rem; font-family: monospace; }
    ::ng-deep .markdown-body pre { background-color: rgba(var(--rgb-bg-deep), 0.8); padding: 1rem; border-radius: 0.5rem; overflow-x: auto; margin-bottom: 1rem; border: 1px solid rgba(var(--rgb-gold-accent), 0.2); }
    ::ng-deep .markdown-body pre code { background-color: transparent; color: var(--color-text-primary); padding: 0; }
    ::ng-deep .markdown-body strong { color: white; font-weight: 700; }
  `]
})
export class FeatureGeneratorComponent {
  close = output<void>();
  private geminiService = inject(GeminiService);

  idea = signal('');
  audience = signal('Candidates');
  monetizationModel = signal('Subscription Add-on');

  isGenerating = signal(false);
  result = signal<string | null>(null);

  audiences = ['Candidates', 'Recruiters', 'Company Admins', 'All Users'];
  monetizationModels = ['Subscription Add-on', 'Pay-per-use', 'Freemium Tier', 'One-time Purchase'];

  examplePrompts = [
    "A gamified leaderboard for candidates based on interview scores",
    "An analytics dashboard for recruiters to track time-to-hire and candidate quality",
    "A public profile page for certified candidates to showcase their skills",
    "AI-powered code generation for daily coding challenges within the platform",
    "System design for a video processing pipeline to analyze non-verbal cues in real-time"
  ];

  async generateConcept(): Promise<void> {
    if (!this.idea().trim()) return;

    this.isGenerating.set(true);
    this.result.set(null);
    this.geminiService.error.set(null);

    const rawMarkdown = await this.geminiService.generateFeatureConcept(
      this.idea(),
      this.audience(),
      this.monetizationModel()
    );

    if (rawMarkdown) {
      const parsed = await marked.parse(rawMarkdown, { gfm: true, breaks: true });
      this.result.set(parsed);
    }
    
    this.isGenerating.set(false);
  }
}
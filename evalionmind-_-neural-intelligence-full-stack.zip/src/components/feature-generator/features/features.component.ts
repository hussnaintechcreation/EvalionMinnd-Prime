

import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppState } from '../../../types';

@Component({
  selector: 'app-features',
  imports: [CommonModule],
  templateUrl: './features.component.html',
  styles: [`
    .perspective { perspective: 1000px; }
    .preserve-3d { transform-style: preserve-3d; }
    .backface-hidden { backface-visibility: hidden; -webkit-backface-visibility: hidden; }
    .rotate-y-180 { transform: rotateY(180deg); }
    
    .animate-draw-in {
        stroke-dasharray: 100;
        stroke-dashoffset: 100;
        animation: draw-in 1.5s ease-out forwards;
    }
    
    @keyframes draw-in {
        to { stroke-dashoffset: 0; }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FeaturesComponent {
  navigateTo = output<AppState>();
  
  features = [
    {
      title: 'UX Motion Designer',
      subtitle: 'Advanced Motion Graphics',
      description: 'Generates animation rules, creates premium screen transitions, and suggests intuitive interaction flows for a dynamic user experience.',
      icon: 'motion',
      color: 'var(--color-neon-cyan)',
      route: 'motion-designer' as AppState
    },
    {
      title: 'Intelligent Validator',
      subtitle: 'System State Stability',
      description: 'Prevents conflicting states, ensures all system nodes connect properly, and predicts future errors before they impact operations.',
      icon: 'validator',
      color: 'var(--color-neon-violet)',
      route: 'validator' as AppState
    },
    {
      title: 'Professional Rewrite',
      subtitle: 'Enterprise-Grade Design Conversion',
      description: 'Converts any poor design into a premium, enterprise-grade structure. Ensures consistency and elevates the user experience to a professional level.',
      icon: 'rewrite',
      color: 'var(--color-neon-magenta)',
      route: 'rewrite-system' as AppState
    },
    {
      title: 'AI Feature Generator',
      subtitle: 'Innovative Module Design',
      description: 'Generates ideas for new modules, designs premium add-ons, and creates monetizable features. Continuously expand your platform\'s capabilities.',
      icon: 'stack',
      color: 'var(--color-accent-green)',
      route: 'feature-generator' as AppState
    }
  ];

  onInitializeModule(route: AppState) {
    // All modules require login to access the tools; the navigation guard in app.component will handle it.
    this.navigateTo.emit(route);
  }
}
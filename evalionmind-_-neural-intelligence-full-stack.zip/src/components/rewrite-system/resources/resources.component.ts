import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppState } from '../../../types';

@Component({
  selector: 'app-resources',
  imports: [CommonModule],
  templateUrl: './resources.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ResourcesComponent {
  back = output<void>();
  navigateTo = output<AppState>();
  
  resources = [
      { title: 'Optimizing Neural Profiles', category: 'Guide', description: 'How to structure your candidate profile for maximum visibility.' },
      { title: 'Interview Protocol v2.5', category: 'Documentation', description: 'Technical breakdown of the scoring algorithms.' },
      { title: 'API Integration Basics', category: 'Tutorial', description: 'Connect your ATS to SmartEvalion in 5 minutes.' },
      { title: 'Video Analysis Best Practices', category: 'Guide', description: 'Lighting, audio, and posture tips for AI assessments.' }
  ];
}

import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-panel-section',
  imports: [CommonModule],
  templateUrl: './panel-section.component.html',
  styles: [`
    .holo-brain-container {
        position: relative;
        perspective: 1000px;
    }
    .holo-brain {
        width: 100%;
        height: auto;
        mix-blend-mode: screen;
        filter: grayscale(100%) sepia(100%) hue-rotate(10deg) saturate(300%) contrast(1.2); /* Gold tint */
        opacity: 0.8;
        animation: float-slow 6s ease-in-out infinite;
    }
    .scan-line {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 2px;
        background: rgba(255, 216, 90, 0.8);
        box-shadow: 0 0 10px rgba(255, 216, 90, 0.8);
        animation: scan 3s linear infinite;
        opacity: 0.5;
    }
    @keyframes float-slow {
        0%, 100% { transform: translateY(0) rotateY(0deg); }
        50% { transform: translateY(-10px) rotateY(5deg); }
    }
    @keyframes scan {
        0% { top: 0%; opacity: 0; }
        10% { opacity: 1; }
        90% { opacity: 1; }
        100% { top: 100%; opacity: 0; }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PanelSectionComponent {
  openTerminal = output<void>();
}

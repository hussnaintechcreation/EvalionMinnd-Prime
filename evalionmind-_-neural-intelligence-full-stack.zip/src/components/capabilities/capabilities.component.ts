import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppState } from '../../types';
import { LogoComponent } from '../logo/logo.component';

@Component({
  selector: 'app-capabilities',
  imports: [CommonModule, LogoComponent],
  templateUrl: './capabilities.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CapabilitiesComponent {
  navigateTo = output<AppState>();
  back = output<void>();
}
import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppState } from '../../types';

@Component({
  selector: 'app-workflow',
  imports: [CommonModule],
  templateUrl: './workflow.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkflowComponent {
  back = output<void>();
  navigateTo = output<AppState>();
}
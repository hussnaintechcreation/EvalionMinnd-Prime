import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-validator',
  imports: [CommonModule],
  templateUrl: './validator.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ValidatorComponent {
  close = output<void>();
}
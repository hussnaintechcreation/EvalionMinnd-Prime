import { ChangeDetectionStrategy, Component, output, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';
import { marked } from 'marked';

@Component({
  selector: 'app-motion-designer',
  imports: [CommonModule, FormsModule],
  templateUrl: './motion-designer.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    /* Markdown Styles for Blueprint Output - Aligned with EvalionMind Theme */
    ::ng-deep .markdown-body h1 { 
        font-size: 1.5rem; 
        font-weight: 700; 
        color: white; 
        margin-bottom: 1rem; 
        margin-top: 1.5rem; 
    }
    ::ng-deep .markdown-body h2 { 
        font-size: 1.25rem; 
        font-weight: 700; 
        color: var(--color-neon-cyan);
        margin-bottom: 0.75rem; 
        margin-top: 1.25rem; 
    }
    ::ng-deep .markdown-body h3 { 
        font-size: 1.125rem; 
        font-weight: 700; 
        color: var(--color-text-primary);
        margin-bottom: 0.5rem; 
        margin-top: 1rem; 
    }
    ::ng-deep .markdown-body p { 
        color: var(--color-text-secondary);
        margin-bottom: 1rem; 
        line-height: 1.625; 
    }
    ::ng-deep .markdown-body ul { 
        list-style-type: disc; 
        list-style-position: inside; 
        color: var(--color-text-secondary);
        margin-bottom: 1rem; 
        margin-left: 1rem; 
    }
    ::ng-deep .markdown-body ol { 
        list-style-type: decimal; 
        list-style-position: inside; 
        color: var(--color-text-secondary);
        margin-bottom: 1rem; 
        margin-left: 1rem; 
    }
    ::ng-deep .markdown-body code { 
        background-color: var(--color-panel-surface);
        color: var(--color-gold-accent);
        padding: 0.125rem 0.25rem; 
        border-radius: 0.25rem; 
        font-size: 0.875rem; 
        font-family: monospace; 
    }
    ::ng-deep .markdown-body pre { 
        background-color: rgba(var(--rgb-bg-deep), 0.8);
        padding: 1rem; 
        border-radius: 0.5rem; 
        overflow-x: auto; 
        margin-bottom: 1rem; 
        border: 1px solid rgba(var(--rgb-neon-cyan), 0.1);
    }
    ::ng-deep .markdown-body pre code { 
        background-color: transparent; 
        color: var(--color-text-primary);
        padding: 0; 
    }
    ::ng-deep .markdown-body strong { 
        color: white; 
        font-weight: 700;
    }
  `]
})
export class MotionDesignerComponent {
  close = output<void>();
  private geminiService = inject(GeminiService);

  animationDescription = signal('');
  animationType = signal('Entrance');
  isGeneratingMotion = signal(false);
  motionResult = signal<string | null>(null);

  animationTypes = ['Entrance', 'Exit', 'Hover', 'Looping', 'Transition', 'Micro-Interaction'];

  async generateMotion(): Promise<void> {
    if (!this.animationDescription().trim()) {
      return;
    }

    this.isGeneratingMotion.set(true);
    this.motionResult.set(null);
    this.geminiService.error.set(null);

    const result = await this.geminiService.generateMotionDesign(
      this.animationDescription(),
      this.animationType()
    );

    if (result) {
      // Use marked to parse markdown. Ensure async/await is handled if needed by specific versions.
      const parsed = await marked.parse(result, { gfm: true, breaks: true });
      this.motionResult.set(parsed);
    } else {
      // Error handling is managed by gemini service signals
    }
    this.isGeneratingMotion.set(false);
  }
}
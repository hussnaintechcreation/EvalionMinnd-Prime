import { ChangeDetectionStrategy, Component, output, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';

@Component({
  selector: 'app-image-editor',
  imports: [CommonModule, FormsModule],
  templateUrl: './image-editor.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    @keyframes indeterminate-progress {
      0% {
        transform: translateX(-100%) scaleX(0.5);
      }
      50% {
        transform: translateX(0) scaleX(0.3);
      }
      100% {
        transform: translateX(100%) scaleX(0.5);
      }
    }

    .indeterminate-bar {
      transform-origin: left;
      animation: indeterminate-progress 1.5s infinite ease-in-out;
    }
  `]
})
export class ImageEditorComponent {
  back = output<void>();
  private geminiService = inject(GeminiService);

  prompt = signal('');
  generatedImageUrl = signal<string | null>(null);
  isLoading = signal(false);
  error = this.geminiService.error;

  // Strictly typed array to ensure compatibility with selectedAspectRatio signal
  aspectRatios: ('1:1' | '16:9' | '9:16')[] = ['1:1', '16:9', '9:16'];
  selectedAspectRatio = signal<'1:1' | '16:9' | '9:16'>('1:1'); 

  examplePrompts = [
    "A futuristic city skyline at night with neon lights and flying cars, cyberpunk style",
    "A serene zen garden in space on a floating island, digital art",
    "A high-tech laboratory with holographic displays and a robot assistant, isometric view"
  ];

  async generateImage(): Promise<void> {
    if (!this.prompt().trim()) {
      return;
    }

    this.isLoading.set(true);
    this.generatedImageUrl.set(null);
    this.geminiService.error.set(null);

    const base64Image = await this.geminiService.generateImage(this.prompt(), this.selectedAspectRatio());

    if (base64Image) {
      this.generatedImageUrl.set(`data:image/png;base64,${base64Image}`);
    }
    
    this.isLoading.set(false);
  }

  onSuggestionClick(suggestion: string): void {
    this.prompt.set(suggestion);
  }
}
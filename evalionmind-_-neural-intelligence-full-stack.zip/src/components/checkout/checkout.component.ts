import { ChangeDetectionStrategy, Component, output, signal, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import confetti from 'canvas-confetti';

type PaymentStatus = 'idle' | 'processing' | 'success' | 'error';

@Component({
  selector: 'app-checkout',
  imports: [CommonModule, FormsModule],
  templateUrl: './checkout.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CheckoutComponent {
  plan = input<{name: string, price: number} | null>();
  billingCycle = input<'monthly' | 'annually'>();

  back = output<void>();
  paymentSuccess = output<void>();

  status = signal<PaymentStatus>('idle');
  errorMessage = signal<string | null>(null);

  // Form fields
  cardholderName = signal('');
  cardNumber = signal('');
  expiryDate = signal('');
  cvc = signal('');

  submitPayment(): void {
    if (!this.validateForm()) {
        this.status.set('error');
        this.errorMessage.set('Please fill in all fields correctly.');
        return;
    }

    this.status.set('processing');
    this.errorMessage.set(null);

    // Simulate API call
    setTimeout(() => {
        // Simulate a random failure
        if (Math.random() < 0.1) {
            this.status.set('error');
            this.errorMessage.set('Transaction declined. Please check your card details.');
        } else {
            this.status.set('success');
            this.launchConfetti();
        }
    }, 2500);
  }

  private validateForm(): boolean {
      return this.cardholderName().trim() !== '' &&
             this.cardNumber().replace(/\s/g, '').length === 16 &&
             /^(0[1-9]|1[0-2])\s?\/\s?[0-9]{2}$/.test(this.expiryDate()) &&
             /^[0-9]{3,4}$/.test(this.cvc());
  }
  
  formatCardNumber(event: any): void {
      let value = event.target.value.replace(/\D/g, '');
      value = value.substring(0, 16);
      const groups = value.match(/.{1,4}/g);
      this.cardNumber.set(groups ? groups.join(' ') : '');
  }

  formatExpiryDate(event: any): void {
      let value = event.target.value.replace(/\D/g, '');
      if (value.length > 2) {
          value = value.substring(0, 2) + ' / ' + value.substring(2, 4);
      }
      this.expiryDate.set(value);
  }

  finish(): void {
      this.paymentSuccess.emit();
  }
  
  launchConfetti(): void {
      const duration = 2 * 1000;
      const animationEnd = Date.now() + duration;
      const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

      function randomInRange(min: number, max: number) {
        return Math.random() * (max - min) + min;
      }

      const interval: any = setInterval(() => {
        const timeLeft = animationEnd - Date.now();
        if (timeLeft <= 0) return clearInterval(interval);

        const particleCount = 50 * (timeLeft / duration);
        confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
        confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
      }, 250);
  }
}
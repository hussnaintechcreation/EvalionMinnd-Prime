
import { ChangeDetectionStrategy, Component, computed, inject, output, signal, OnDestroy, ViewChild, ElementRef, OnInit, afterNextRender, input, effect, NgZone, AfterViewInit, Renderer2 } from '@angular/core';
import { CommonModule, DOCUMENT as ANGULAR_DOCUMENT } from '@angular/common'; // Fixed: Aliased DOCUMENT to avoid potential name conflict
import { FormsModule } from '@angular/forms';
import { GeminiService, EvaluationResult } from '../../services/gemini.service';
import { CodeExecutionService } from '../../services/code-execution.service';
import { CollaborationService, CollabEvent } from '../../services/collaboration.service';
import { MockBackendService } from '../../services/mock-backend.service';
import { WebSocketService, WsMessage } from '../../services/websocket.service'; // Added WebSocketService
import confetti from 'canvas-confetti';
import { LogoComponent } from '../logo/logo.component';
import { Subject, Subscription } from 'rxjs'; 
import { debounceTime, throttleTime } from 'rxjs/operators';
import { User } from '../../models/user.model';
import { InterviewHistoryItem } from '../../models/interview.model';

type InterviewState = 'in-progress' | 'paused' | 'evaluating' | 'completed' | 'error';

export interface CodeFile {
    id: string;
    name: string;
    language: string; 
    content: string;
}
export interface WorkspaceSnapshot {
    id: string;
    timestamp: number;
    name: string;
    files: CodeFile[];
}
export interface Participant {
    id: string;
    name: string;
    role: 'candidate' | 'interviewer';
    status: 'online' | 'typing' | 'idle' | 'offline';
}
export interface LogLine {
    id: string;
    type: 'info' | 'error' | 'warn' | 'system';
    message: string;
    timestamp: string;
}

interface RemoteCursor {
    participantId: string;
    name: string;
    color: string;
    position: { top: number; left: number };
}

declare var webkitSpeechRecognition: any;
declare var hljs: any;

@Component({
  selector: 'app-interview',
  imports: [CommonModule, FormsModule, LogoComponent],
  host: {
    '(window:mousemove)': 'onUserActivity()'
  },
  styles: [`
    @keyframes pulse-cyan { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }
    .animate-pulse-cyan { animation: pulse-cyan 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
    .ide-scroll::-webkit-scrollbar { width: 5px; height: 5px; }
    .ide-scroll::-webkit-scrollbar-track { background: #1e1e1e; }
    .ide-scroll::-webkit-scrollbar-thumb { background: #444; border-radius: 2px; }
    .ide-scroll::-webkit-scrollbar-thumb:hover { background: var(--color-neon-cyan); }
    .code-editor-pre { white-space: pre-wrap; word-wrap: break-word; }
    .no-scrollbar::-webkit-scrollbar { display: none; }
    .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    .toast-enter { animation: slide-in-right 0.3s ease-out forwards; }
    @keyframes slide-in-right { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    
    @keyframes waveform { 
      0%, 100% { transform: scaleY(0.5); opacity: 0.5; } 
      50% { transform: scaleY(1); opacity: 1; } 
    }
    .animate-waveform { animation: waveform 1.2s ease-in-out infinite; }

    @keyframes pulse-fast { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
    .animate-pulse-fast { animation: pulse-fast 0.8s steps(2, start) infinite; }

    #interview-progress-container {
        backdrop-filter: blur(10px); 
        -webkit-backdrop-filter: blur(10px);
        transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out, border-color 0.3s ease-in-out;
    }

    #interview-progress-container:hover {
        box-shadow: 0 0 50px rgba(var(--rgb-neon-cyan), 0.6), inset 0 0 20px rgba(var(--rgb-neon-cyan), 0.2);
        border-color: rgba(var(--rgb-neon-cyan), 0.5); 
    }
  `]
})
export class InterviewComponent implements OnDestroy, OnInit, AfterViewInit {
  geminiService = inject(GeminiService);
  codeExecService = inject(CodeExecutionService);
  collabService = inject(CollaborationService);
  wsService = inject(WebSocketService); // Inject WebSocket Service
  mockBackend = inject(MockBackendService);
  // Fixed: Referencing the aliased DOCUMENT token
  private document: Document = inject(ANGULAR_DOCUMENT); 
  private ngZone = inject(NgZone);
  private renderer2 = inject(Renderer2); 

  currentUser = input<User | null>(null);
  selectedRole = input<string | null>(null);
  candidateName = input<string>('Candidate'); 
  level = input<string>('Senior'); 
  interviewFinished = output<InterviewHistoryItem | null>();

  interviewState = signal<InterviewState>('in-progress');
  evaluationError = computed(() => this.geminiService.error());
  
  // Audio/Video & Analysis
  isCameraOk = signal(false);
  isMicrophoneOk = signal(false); 
  isCameraEnabled = signal(true);
  isMicrophoneMuted = signal(false);
  mediaErrorMessage = signal<string | null>(null); 
  isSpeechRecognitionListening = signal(false); 
  audioLevel = signal(0);
  
  // Real-time Metrics Signals
  candidatePulse = signal(75);
  aiConfidence = signal(0.95);
  
  private currentStream: MediaStream | null = null;
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private microphoneSource: MediaStreamAudioSourceNode | null = null;
  private audioAnalysisAnimationFrame: number | null = null;

  recognition: any;
  interimTranscript = signal('');
  userAnswer = signal('');
  speechRecognitionError = signal<string | null>(null); 
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];
  isRecording = signal(false);
  @ViewChild('videoPreview') videoPreview!: ElementRef<HTMLVideoElement>;
  @ViewChild('transcriptScrollContainer') transcriptScrollContainer!: ElementRef<HTMLDivElement>;

  // Collaboration & UI State
  collabStatus = this.collabService.status;
  participants = signal<Participant[]>([]);
  isInterviewerControlsOpen = signal(false);
  feedbackToasts = signal<{id: number, message: string, type: 'success' | 'warning' | 'info'}[]>([]);
  private toastIdCounter = 0;
  remoteCursors = signal<RemoteCursor[]>([]);

  // Questions
  questions = signal<string[]>([]);
  currentQuestionIndex = signal(0);
  currentQuestion = computed(() => this.questions()[this.currentQuestionIndex()] || 'Initializing...');
  allQuestionEvaluations = signal<EvaluationResult[]>([]);

  evaluatingMessage = signal('Analyzing response...');
  
  private subscriptions = new Subscription();

  timeLeft = signal(120); 
  formattedTime = computed(() => {
      const m = Math.floor(this.timeLeft() / 60);
      const s = this.timeLeft() % 60;
      return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  });
  timerInterval: any;

  // IDE Layout Resizing
  @ViewChild('codeEditor') codeEditor!: ElementRef<HTMLElement>;
  @ViewChild('outputPanel') outputPanel!: ElementRef;
  @ViewChild('fileExplorerPanel') fileExplorerPanel!: ElementRef<HTMLElement>;
  
  isResizing = signal(false);
  
  private onOutputResizeMoveBound?: (event: MouseEvent) => void;
  private onOutputResizeEndBound?: () => void;
  private onFileExplorerResizeMoveBound?: (event: MouseEvent) => void;
  private onFileExplorerResizeEndBound?: () => void;
  
  fileExplorerWidth = signal(256); 
  minFileExplorerWidth = 150;
  maxFileExplorerWidth = 500;
  
  outputPanelHeight = signal(150); 
  minOutputPanelHeight = 40;       
  maxOutputPanelHeightPercentage = 0.8; 

  files = signal<CodeFile[]>([{ id: 'main', name: 'solution.js', language: 'javascript', content: '// Write solution here' }]);
  activeFileId = signal('main');
  currentLanguage = signal('javascript'); 
  isFileExplorerOpen = signal(true); 
  isOutputPanelOpen = signal(true);
  logs = signal<LogLine[]>([]);
  isExecutingCode = signal(false);
  
  activeFile = computed(() => this.files().find(f => f.id === this.activeFileId()));
  activeFileContent = computed(() => this.activeFile()?.content || '');
  activeFileName = computed(() => this.activeFile()?.name || 'No file selected');

  private codeChange$ = new Subject<string>();

  ngOnInit(): void {
    this.fetchQuestions();
    this.setupMedia();
    this.setupSpeechRecognition();
    this.collabService.connect('interview-room-1');

    const collabSub = this.collabService.updates$.subscribe(event => this.handleCollabEvent(event));
    const codeChangeSub = this.codeChange$.pipe(debounceTime(300)).subscribe(content => {
      this.collabService.sendChange({ type: 'content_change', fileId: this.activeFileId(), content });
      this.highlightCode();
    });

    this.subscriptions.add(collabSub);
    this.subscriptions.add(codeChangeSub);
  }

  ngAfterViewInit(): void {
    this.startTimer();
    this.highlightCode();
    if (this.videoPreview?.nativeElement) {
       this.videoPreview.nativeElement.muted = true;
    }
  }

  ngOnDestroy(): void {
    if (this.timerInterval) clearInterval(this.timerInterval);
    this.stopAudioAnalysis();
    this.stopSpeechRecognition();
    this.currentStream?.getTracks().forEach(track => track.stop());
    this.collabService.disconnect();
    if (this.onOutputResizeEndBound) this.document.removeEventListener('mouseup', this.onOutputResizeEndBound);
    if (this.onFileExplorerResizeEndBound) this.document.removeEventListener('mouseup', this.onFileExplorerResizeEndBound);
    this.subscriptions.unsubscribe();
  }

  onUserActivity() {
    // Placeholder for user activity tracking logic
  }

  private async fetchQuestions(): Promise<void> {
    const role = this.selectedRole();
    if (role) {
      const generatedQuestions = await this.geminiService.generateInterviewProtocol(role, this.level(), 'Core Concepts');
      if (generatedQuestions.length > 0) {
        this.questions.set(generatedQuestions);
      } else {
        this.questions.set([
          `Tell me about a challenging project you worked on as a ${role}.`,
          "What are your strengths and weaknesses in this role?",
          "How do you stay updated with the latest technologies?",
          "Describe your ideal work environment.",
          "Where do you see yourself in 5 years?"
        ]);
      }
    }
  }

  private startTimer(): void {
    this.timerInterval = setInterval(() => {
      this.timeLeft.update(t => {
        if (t > 0) return t - 1;
        this.submitAnswer(); 
        return 0;
      });
    }, 1000);
  }

  submitAnswer(): void {
      if (this.interviewState() !== 'in-progress') return;

      this.stopSpeechRecognition();
      if(this.isRecording()) {
          this.mediaRecorder?.stop();
      } else {
          this.evaluateAnswer(); // Fallback for no media
      }
  }

  private async evaluateAnswer(videoBlob?: Blob): Promise<void> {
      this.interviewState.set('evaluating');
      let videoBase64: string | undefined;

      if (videoBlob) {
          videoBase64 = await this.blobToBase64(videoBlob);
      }

      const result = await this.geminiService.evaluateAnswer(this.currentQuestion(), this.userAnswer(), videoBase64);
      
      if (result) {
          this.allQuestionEvaluations.update(evals => [...evals, result]);
          this.nextQuestion();
      } else {
          this.interviewState.set('error');
      }
  }

  private nextQuestion(): void {
    if (this.currentQuestionIndex() < this.questions().length - 1) {
        this.currentQuestionIndex.update(i => i + 1);
        this.userAnswer.set('');
        this.interimTranscript.set('');
        this.timeLeft.set(120);
        this.interviewState.set('in-progress');
        this.startSpeechRecognition();
    } else {
        this.endSession();
    }
  }

  private endSession(): void {
    this.interviewState.set('completed');
    if (this.timerInterval) clearInterval(this.timerInterval);
    confetti({ particleCount: 150, spread: 90, origin: { y: 0.6 } });
    
    // Create and emit the final history item
    const finalScore = Math.round(this.allQuestionEvaluations().reduce((acc, q) => acc + q.score * 10, 0) / this.allQuestionEvaluations().length);
    const historyItem: InterviewHistoryItem = {
      id: `SES-${Date.now()}`,
      candidateId: this.currentUser()?.id,
      candidateName: this.candidateName(),
      role: this.selectedRole() || 'N/A',
      date: new Date().toISOString().split('T')[0],
      status: 'Pending Review',
      score: finalScore,
      questionEvaluations: this.allQuestionEvaluations()
    };
    this.interviewFinished.emit(historyItem);
  }
  
  exitInterview(): void { this.interviewFinished.emit(null); }
  retryEvaluation(): void { this.submitAnswer(); }
  
  togglePause(): void {
      this.interviewState.update(s => s === 'paused' ? 'in-progress' : 'paused');
  }

  endSessionImmediately(): void {
      if (confirm('Are you sure you want to terminate this session?')) {
          this.endSession();
      }
  }

  sendFeedback(message: string, type: 'success' | 'warning' | 'info'): void {
      const id = this.toastIdCounter++;
      this.feedbackToasts.update(toasts => [...toasts, { id, message, type }]);
      setTimeout(() => {
          this.feedbackToasts.update(toasts => toasts.filter(t => t.id !== id));
      }, 3000);
  }
  
  private blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64 = (reader.result as string).split(',')[1];
            resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
  }

  private async setupMedia(): Promise<void> {
    if (typeof navigator !== 'undefined' && navigator.mediaDevices) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        this.currentStream = stream;
        this.isCameraOk.set(true);
        this.isMicrophoneOk.set(true);
        this.mediaErrorMessage.set(null);
        if (this.videoPreview) {
          this.videoPreview.nativeElement.srcObject = stream;
        }
        this.startAudioAnalysis();
        this.setupMediaRecorder(stream);
        this.startSpeechRecognition();
      } catch (err: any) {
        let message = 'Could not access camera or microphone. Please check your browser permissions.';
        if (err.name === 'NotAllowedError') {
          message = 'Camera and microphone access was denied. Please grant permission in your browser settings to continue.';
        } else if (err.name === 'NotFoundError') {
          message = 'No camera or microphone found. Please connect a device and try again.';
        }
        this.mediaErrorMessage.set(message);
        this.isCameraOk.set(false);
        this.isMicrophoneOk.set(false);
      }
    } else {
      this.mediaErrorMessage.set('Media devices are not supported in this browser.');
    }
  }

  private setupMediaRecorder(stream: MediaStream): void {
    this.mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
    this.mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        this.recordedChunks.push(event.data);
      }
    };
    this.mediaRecorder.onstart = () => {
      this.recordedChunks = [];
      this.isRecording.set(true);
    };
    this.mediaRecorder.onstop = () => {
      this.isRecording.set(false);
      const videoBlob = new Blob(this.recordedChunks, { type: 'video/webm' });
      this.evaluateAnswer(videoBlob);
    };
  }

  toggleCamera(): void {
    if (this.currentStream) {
      const videoTrack = this.currentStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        this.isCameraEnabled.set(videoTrack.enabled);
      }
    }
  }

  toggleMicrophoneMute(): void {
    if (this.currentStream) {
      const audioTrack = this.currentStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        this.isMicrophoneMuted.set(!audioTrack.enabled);
        if (audioTrack.enabled) {
          this.startSpeechRecognition();
        } else {
          this.stopSpeechRecognition();
        }
      }
    }
  }
  
  private startAudioAnalysis(): void {
    if (this.currentStream && !this.audioContext) {
      this.audioContext = new AudioContext();
      this.analyser = this.audioContext.createAnalyser();
      this.microphoneSource = this.audioContext.createMediaStreamSource(this.currentStream);
      this.microphoneSource.connect(this.analyser);
      this.analyser.fftSize = 256;
      const dataArray = new Uint8Array(this.analyser.frequencyBinCount);

      const update = () => {
        if (!this.analyser) return;
        this.analyser.getByteFrequencyData(dataArray);
        const average = dataArray.reduce((sum, value) => sum + value, 0) / dataArray.length;
        this.ngZone.run(() => this.audioLevel.set(Math.min(1, (average / 128))));
        this.audioAnalysisAnimationFrame = requestAnimationFrame(update);
      };
      this.audioAnalysisAnimationFrame = requestAnimationFrame(update);
    }
  }

  private stopAudioAnalysis(): void {
    if (this.audioAnalysisAnimationFrame) {
      cancelAnimationFrame(this.audioAnalysisAnimationFrame);
    }
    this.microphoneSource?.disconnect();
    this.analyser?.disconnect();
    this.audioContext?.close();
    this.audioContext = null;
  }
  
  private setupSpeechRecognition(): void {
    if ('webkitSpeechRecognition' in window) {
      this.recognition = new webkitSpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';

      this.recognition.onstart = () => this.isSpeechRecognitionListening.set(true);
      this.recognition.onend = () => {
        this.isSpeechRecognitionListening.set(false);
        // Automatically restart if not intentionally stopped
        if (this.interviewState() === 'in-progress' && !this.isMicrophoneMuted()) {
          this.restartSpeechRecognition();
        }
      };
      this.recognition.onerror = (event: any) => {
        this.speechRecognitionError.set(event.error === 'no-speech' ? 'No speech detected. Try again.' : 'Speech recognition error.');
      };
      this.recognition.onresult = (event: any) => {
        let finalTranscript = this.userAnswer();
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        this.userAnswer.set(finalTranscript);
        this.interimTranscript.set(interim);
        if (this.transcriptScrollContainer) {
          this.transcriptScrollContainer.nativeElement.scrollTop = this.transcriptScrollContainer.nativeElement.scrollHeight;
        }
      };
    } else {
        this.speechRecognitionError.set('Speech Recognition API not supported.');
    }
  }

  startSpeechRecognition(): void {
    if (this.recognition && !this.isSpeechRecognitionListening() && !this.isMicrophoneMuted()) {
      try {
        this.userAnswer.set('');
        this.interimTranscript.set('');
        this.recognition.start();
        this.mediaRecorder?.start();
      } catch (e) {
        console.error("Speech recognition start error", e);
      }
    }
  }

  stopSpeechRecognition(): void {
    if (this.recognition && this.isSpeechRecognitionListening()) {
      this.recognition.stop();
    }
  }

  restartSpeechRecognition(): void {
    this.stopSpeechRecognition();
    setTimeout(() => this.startSpeechRecognition(), 100);
  }

  onCodeChange(content: string): void { this.codeChange$.next(content); }

  async runCode(): Promise<void> {
    const file = this.activeFile();
    if (!file) return;

    this.isExecutingCode.set(true);
    this.addLog({ type: 'system', message: `Executing ${file.name}...` });

    const result = await this.codeExecService.run(file.content, file.language);
    
    this.addLog({ type: 'info', message: result });
    this.isExecutingCode.set(false);
  }

  private addLog(log: Omit<LogLine, 'id' | 'timestamp'>): void {
      const newLog: LogLine = {
          id: `log-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          ...log
      };
      this.logs.update(logs => [...logs.slice(-100), newLog]); // Keep last 100 logs
  }

  createFile(): void {
    const fileName = prompt("Enter file name (e.g., script.js):");
    if (fileName) {
      const newFile: CodeFile = {
        id: `file-${Date.now()}`,
        name: fileName,
        language: 'javascript', // Default, can be improved
        content: `// ${fileName}`
      };
      this.files.update(f => [...f, newFile]);
      this.setActiveFile(newFile.id);
    }
  }
  
  setActiveFile(id: string): void { this.activeFileId.set(id); this.highlightCode(); }
  toggleFileExplorer(): void { this.isFileExplorerOpen.update(v => !v); }
  toggleOutputPanel(): void { this.isOutputPanelOpen.update(v => !v); }

  onFileExplorerResizeStart(event: MouseEvent): void {
    this.isResizing.set(true);
    const startX = event.clientX;
    const startWidth = this.fileExplorerWidth();

    this.onFileExplorerResizeMoveBound = (moveEvent: MouseEvent) => {
      const dx = moveEvent.clientX - startX;
      const newWidth = Math.max(this.minFileExplorerWidth, Math.min(startWidth + dx, this.maxFileExplorerWidth));
      this.fileExplorerWidth.set(newWidth);
    };

    this.onFileExplorerResizeEndBound = () => {
      this.isResizing.set(false);
      this.document.removeEventListener('mousemove', this.onFileExplorerResizeMoveBound!);
      this.document.removeEventListener('mouseup', this.onFileExplorerResizeEndBound!);
    };

    this.document.addEventListener('mousemove', this.onFileExplorerResizeMoveBound);
    this.document.addEventListener('mouseup', this.onFileExplorerResizeEndBound);
  }

  onOutputResizeStart(event: MouseEvent): void {
    this.isResizing.set(true);
    const startY = event.clientY;
    const startHeight = this.outputPanelHeight();
    const maxHeight = this.renderer2.parentNode(this.outputPanel.nativeElement).offsetHeight * this.maxOutputPanelHeightPercentage;

    this.onOutputResizeMoveBound = (moveEvent: MouseEvent) => {
        const dy = startY - moveEvent.clientY;
        const newHeight = Math.max(this.minOutputPanelHeight, Math.min(startHeight + dy, maxHeight));
        this.outputPanelHeight.set(newHeight);
    };

    this.onOutputResizeEndBound = () => {
        this.isResizing.set(false);
        this.document.removeEventListener('mousemove', this.onOutputResizeMoveBound!);
        this.document.removeEventListener('mouseup', this.onOutputResizeEndBound!);
    };

    this.document.addEventListener('mousemove', this.onOutputResizeMoveBound);
    this.document.addEventListener('mouseup', this.onOutputResizeEndBound);
  }

  private handleCollabEvent(event: CollabEvent): void {
    switch (event.type) {
        case 'content_change':
            if (event.fileId && event.fileId !== this.activeFileId()) {
                this.files.update(files => files.map(f =>
                    f.id === event.fileId ? { ...f, content: event.content || '' } : f
                ));
            }
            break;
    }
  }

  private highlightCode(): void {
    afterNextRender(() => {
        if (this.codeEditor && this.activeFile() && typeof hljs !== 'undefined') {
            const el = this.codeEditor.nativeElement;
            el.innerHTML = this.activeFile()!.content;
            hljs.highlightElement(el);
        }
    });
  }
}
    
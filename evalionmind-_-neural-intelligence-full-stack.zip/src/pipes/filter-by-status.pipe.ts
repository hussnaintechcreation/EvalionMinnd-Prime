
import { Pipe, PipeTransform } from '@angular/core';
import { InterviewHistoryItem } from '../models/interview.model';

@Pipe({
  name: 'filterByStatus',
  standalone: true,
})
export class FilterByStatusPipe implements PipeTransform {
  transform(items: InterviewHistoryItem[], status: string): InterviewHistoryItem[] {
    if (!items || !status) {
      return items;
    }
    return items.filter(item => item.status === status);
  }
}
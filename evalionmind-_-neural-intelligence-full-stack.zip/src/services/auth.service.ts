
import { Injectable } from '@angular/core';
import { of, Observable, BehaviorSubject } from 'rxjs';
import { delay } from 'rxjs/operators';
import { User } from '../models/user.model';

interface MockUser extends User {
  password?: string;
  biometricCredentialId?: string;
}

interface SessionData {
  user: User;
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
}

// Unified Safe Storage Helper
const SafeStorage = {
  getItem: (key: string, useSession = false): string | null => {
    try {
      if (typeof window === 'undefined') return null;
      const storage = useSession ? window.sessionStorage : window.localStorage;
      return storage ? storage.getItem(key) : null;
    } catch (e) {
      console.warn(`[SafeStorage] Read prevented for key: ${key}`, e);
      return null;
    }
  },
  setItem: (key: string, value: string, useSession = false): void => {
    try {
      if (typeof window === 'undefined') return;
      const storage = useSession ? window.sessionStorage : window.localStorage;
      if (storage) storage.setItem(key, value);
    } catch (e) {
      console.warn(`[SafeStorage] Write prevented for key: ${key}`, e);
    }
  },
  removeItem: (key: string): void => {
    try {
      if (typeof window === 'undefined') return;
      window.localStorage?.removeItem(key);
      window.sessionStorage?.removeItem(key);
    } catch (e) { }
  }
};

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private users: MockUser[] = [];
  private readonly SESSION_KEY = 'evalionmind_session_v4';
  private readonly DB_KEY = 'evalionmind_db_v1';
  private refreshTokenTimeout: any;

  private currentUserSession: BehaviorSubject<User | null> = new BehaviorSubject<User | null>(null);
  public currentUser$: Observable<User | null> = this.currentUserSession;
  public get currentUserValue(): User | null { return this.currentUserSession.value; }

  constructor() {
      setTimeout(() => this.initialize(), 0);
  }

  private initialize() {
      try {
          this.loadDatabase();
          const user = this.getSessionUser();
          this.currentUserSession.next(user);
      } catch (e) {
          console.error('[AuthService] Critical initialization failure. Falling back to clean state.', e);
          this.users = [];
          this.initializeDefaultUsers();
          this.currentUserSession.next(null);
          SafeStorage.removeItem(this.SESSION_KEY);
      }
  }

  isPlatformAuthenticatorAvailable(): Promise<boolean> {
    if (typeof window !== 'undefined' && (window as any).PublicKeyCredential) {
      return (window as any).PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    }
    return Promise.resolve(false);
  }

  private loadDatabase() {
      const storedDb = SafeStorage.getItem(this.DB_KEY);
      if (storedDb) {
          try {
              this.users = JSON.parse(storedDb);
          } catch (e) {
              console.warn('[AuthService] Database corrupted, resetting defaults.', e);
              this.initializeDefaultUsers();
          }
      } else {
          this.initializeDefaultUsers();
      }
  }

  private initializeDefaultUsers() {
      this.users = [
        { id: 'CAND-alex-candidate-849', name: 'Alex Candidate', email: 'candidate@evalion.ai', role: 'candidate', password: 'password', organizationId: 'ORG-CLIENT-01', designation: 'Senior Frontend Engineer', avatarUrl: `https://ui-avatars.com/api/?name=Alex+Candidate&background=00F3FF&color=0A0A0A` },
        { id: 'CORP-1029', name: 'Hussnain Tech Creation', email: 'recruiter@htc.com', role: 'company', password: 'password', organizationId: 'ORG-HTC-01', designation: 'Headquarters', ownerName: 'Hussnain', mobile: '+1-555-0199', cnic: '42101-1234567-1', avatarUrl: `https://ui-avatars.com/api/?name=HTC&background=888888&color=0A0A0A` },
        { id: 'INT-3042', name: 'Sarah Interviewer', email: 'interviewer@evalion.ai', role: 'interviewer', password: 'password', organizationId: 'ORG-HTC-01', designation: 'Technical Lead', avatarUrl: `https://ui-avatars.com/api/?name=Sarah+Interviewer&background=00F0FF&color=0A0A0A` }
      ];
      this.saveDatabase();
  }

  private saveDatabase() {
      SafeStorage.setItem(this.DB_KEY, JSON.stringify(this.users));
  }
  
  private saveSession(sessionData: SessionData, rememberMe: boolean): void {
      SafeStorage.removeItem(this.SESSION_KEY);
      SafeStorage.setItem(this.SESSION_KEY, JSON.stringify(sessionData), !rememberMe);
  }

  private getSessionData(): { sessionData: SessionData | null, storageType: 'local' | 'session' | null } {
    let sessionJson = SafeStorage.getItem(this.SESSION_KEY, false);
    if (sessionJson) return { sessionData: this.parseSession(sessionJson), storageType: 'local' };
    
    sessionJson = SafeStorage.getItem(this.SESSION_KEY, true);
    if (sessionJson) return { sessionData: this.parseSession(sessionJson), storageType: 'session' };

    return { sessionData: null, storageType: null };
  }

  private parseSession(json: string): SessionData | null {
      try {
          return JSON.parse(json);
      } catch {
          return null;
      }
  }
  
  private clearSessionData(): void {
    this.clearRefreshTokenTimeout();
    SafeStorage.removeItem(this.SESSION_KEY);
  }

  private getSessionUser(): User | null {
    const { sessionData } = this.getSessionData();
    if (sessionData) {
      if (sessionData.expiresAt > Date.now()) {
        this.scheduleTokenRefresh(sessionData.expiresAt);
        return sessionData.user;
      } else {
        this.clearSessionData();
        return null;
      }
    }
    return null;
  }

  public getAccessToken(): string | null {
    const { sessionData } = this.getSessionData();
    if (sessionData && sessionData.expiresAt > Date.now()) {
      return sessionData.accessToken;
    }
    return null;
  }

  login(email: string, password: string, role: 'candidate' | 'company' | 'interviewer', rememberMe: boolean): Observable<User> {
    return new Observable<User>(observer => {
      setTimeout(() => {
        try {
            this.loadDatabase();
            const user = this.users.find(u => u.email.toLowerCase() === email.toLowerCase());
            
            if (!user) { return observer.error(new Error('Identity not recognized in neural database.')); }
            if (user.password !== password) { return observer.error(new Error('Security key invalid. Access denied.')); }
            if (user.role !== role && !(role === 'company' && user.role === 'interviewer')) {
               if(role === 'candidate' && user.role !== 'candidate') {
                   return observer.error(new Error('Invalid role access.'));
               }
            }

            const { password: _, biometricCredentialId, ...safeUser } = user;
            const expiresIn = 3600 * 1000; // 1 hour
            const sessionData: SessionData = {
                user: safeUser,
                accessToken: `mock_access_token_${Date.now()}`,
                refreshToken: `mock_refresh_token_${Date.now()}`,
                expiresAt: Date.now() + expiresIn
            };

            this.saveSession(sessionData, rememberMe);
            this.currentUserSession.next(safeUser);
            this.scheduleTokenRefresh(sessionData.expiresAt);

            observer.next(safeUser);
            observer.complete();
        } catch (err) {
            observer.error(new Error('System malfunction during handshake.'));
        }
      }, 1500);
    });
  }

  loginBiometric(role: 'candidate' | 'company'): Observable<User> {
    return new Observable<User>(observer => {
      if (typeof window === 'undefined' || !(window as any).PublicKeyCredential) {
        return observer.error(new Error('Biometric authentication is not supported by your browser or device.'));
      }
        
      const publicKey: PublicKeyCredentialRequestOptions = {
        challenge: new Uint8Array(16),
        timeout: 60000,
        userVerification: "preferred"
      };

      navigator.credentials.get({ publicKey })
        .then((credential) => {
           this.loadDatabase();
           const user = this.users.find(u => u.role === role && u.biometricCredentialId); 
           
           if (user) {
             const { password: _, biometricCredentialId, ...safeUser } = user;
             const expiresIn = 3600 * 1000;
             const sessionData: SessionData = {
                 user: safeUser,
                 accessToken: `mock_access_token_${Date.now()}`,
                 refreshToken: `mock_refresh_token_${Date.now()}`,
                 expiresAt: Date.now() + expiresIn
             };
             this.saveSession(sessionData, true);
             this.currentUserSession.next(safeUser);
             this.scheduleTokenRefresh(sessionData.expiresAt);
             observer.next(safeUser);
             observer.complete();
           } else {
             observer.error(new Error('No registered biometric key found for this role. Please register a device in Settings first.'));
           }
        })
        .catch((err) => {
           observer.error(err);
        });
    });
  }

  register(data: any, role: 'candidate' | 'company'): Observable<User> {
    return new Observable<User>(observer => {
      setTimeout(() => {
        try {
          this.loadDatabase();
          if (this.users.some(u => u.email === data.email)) {
              return observer.error(new Error('Identity Key (Email) already registered.'));
          }

          const newUser: MockUser = {
            id: role === 'candidate' ? `CAND-${Date.now()}` : `CORP-${Math.floor(Math.random() * 10000)}`,
            name: data.name,
            email: data.email,
            role,
            password: data.password,
            avatarUrl: data.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(data.name)}&background=00F3FF&color=0A0A0A`,
            ownerName: data.ownerName, 
            cnic: data.cnic, 
            mobile: data.mobile,
            designation: role === 'candidate' ? 'New Applicant' : 'Headquarters',
            organizationId: role === 'company' ? `ORG-${Math.floor(Math.random() * 1000)}` : undefined
          };

          this.users.push(newUser);
          this.saveDatabase();
          const { password: _, ...safeUser } = newUser;
          const expiresIn = 3600 * 1000;
          const sessionData: SessionData = {
              user: safeUser,
              accessToken: `mock_access_token_${Date.now()}`,
              refreshToken: `mock_refresh_token_${Date.now()}`,
              expiresAt: Date.now() + expiresIn
          };

          this.saveSession(sessionData, true);
          this.currentUserSession.next(safeUser);
          this.scheduleTokenRefresh(sessionData.expiresAt);
          observer.next(safeUser);
          observer.complete();
        } catch (e) {
          observer.error(e);
        }
      }, 2000);
    });
  }
  
  isBiometricRegistered(userId: string): Observable<boolean> {
    this.loadDatabase();
    const user = this.users.find(u => u.id === userId);
    return of(!!user?.biometricCredentialId).pipe(delay(100));
  }
  
  registerBiometric(userId: string): Observable<User> {
    return new Observable<User>(observer => {
      if (typeof window === 'undefined' || !(window as any).PublicKeyCredential) {
        return observer.error(new Error('Biometric registration is not supported.'));
      }
      this.loadDatabase();
      const user = this.users.find(u => u.id === userId);
      if (!user) { return observer.error(new Error('User not found.')); }

      const publicKey: PublicKeyCredentialCreationOptions = {
        challenge: new Uint8Array(16),
        rp: { name: 'EvalionMind', id: window.location.hostname },
        user: { id: new TextEncoder().encode(user.id), name: user.email, displayName: user.name },
        pubKeyCredParams: [{ type: 'public-key', alg: -7 }],
        timeout: 60000,
        attestation: 'none',
      };

      navigator.credentials.create({ publicKey })
        .then(credential => {
          if (credential) {
            try {
              const credentialId = btoa(String.fromCharCode(...new Uint8Array((credential as any).rawId)));
              user.biometricCredentialId = credentialId;
              this.saveDatabase();
              const { password: _, ...safeUser } = user;
              this.currentUserSession.next(safeUser);
              observer.next(safeUser);
              observer.complete();
            } catch (e) { observer.error(e); }
          } else { observer.error(new Error('Credential creation failed.')); }
        })
        .catch((err: DOMException) => {
            let friendlyMessage = 'An unknown error occurred during registration.';
            if (err.name === 'NotAllowedError') { friendlyMessage = 'Biometric registration was cancelled by the user.'; }
            observer.error(new Error(friendlyMessage));
        });
    });
  }

  removeBiometric(userId: string): Observable<User> {
    return new Observable<User>(observer => {
      setTimeout(() => {
        try {
          this.loadDatabase();
          const user = this.users.find(u => u.id === userId);
          if (user) {
            delete user.biometricCredentialId;
            this.saveDatabase();
            const { password: _, ...safeUser } = user;
            this.currentUserSession.next(safeUser);
            observer.next(safeUser);
            observer.complete();
          } else { observer.error(new Error('User not found.')); }
        } catch (e) { observer.error(e); }
      }, 500);
    });
  }

  updateProfile(userId: string, updates: Partial<User>): Observable<User> {
      return new Observable<User>(observer => {
          setTimeout(() => {
              try {
                  this.loadDatabase();
                  const index = this.users.findIndex(u => u.id === userId);
                  if (index !== -1) {
                      const { password, ...safeUpdates } = updates as any;
                      this.users[index] = { ...this.users[index], ...safeUpdates };
                      this.saveDatabase();
                      const { password: _, biometricCredentialId, ...safeUser } = this.users[index];
                      this.currentUserSession.next(safeUser);
                      observer.next(safeUser);
                      observer.complete();
                  } else { observer.error(new Error('User not found in database.')); }
              } catch (e) { observer.error(e); }
          }, 800);
      });
  }

  socialLogin(provider: 'Google' | 'GitHub', role: 'candidate' | 'company'): Observable<User> {
    let name: string;
    let email: string;
    let avatarUrl: string;

    switch (provider) {
      case 'Google':
        name = 'Google User';
        email = `user@google.com`;
        avatarUrl = `https://ui-avatars.com/api/?name=Google&background=DB4437&color=FFFFFF`;
        break;
      case 'GitHub':
        name = 'GitHub User';
        email = `user@github.com`;
        avatarUrl = `https://ui-avatars.com/api/?name=GitHub&background=24292E&color=FFFFFF`;
        break;
      default:
        name = 'Social User';
        email = `user@social.com`;
        avatarUrl = `https://ui-avatars.com/api/?name=Social&background=00F3FF&color=0A0A0A`;
    }

    const user: User = {
        id: `SOC-${Math.floor(Math.random() * 10000)}`,
        name: name,
        email: email,
        role: role,
        avatarUrl: avatarUrl
    };
    const expiresIn = 3600 * 1000;
    const sessionData: SessionData = {
        user: user,
        accessToken: `mock_access_token_${Date.now()}`,
        refreshToken: `mock_refresh_token_${Date.now()}`,
        expiresAt: Date.now() + expiresIn
    };
    this.saveSession(sessionData, true);
    this.currentUserSession.next(user);
    this.scheduleTokenRefresh(sessionData.expiresAt);
    return of(user).pipe(delay(1500));
  }
  
  logout(): void {
      this.clearSessionData();
      if (this.currentUserSession.value !== null) {
          this.currentUserSession.next(null);
      }
  }

  private scheduleTokenRefresh(expiresAt: number): void {
      this.clearRefreshTokenTimeout();
      if (!expiresAt || isNaN(expiresAt)) return;
      
      const timeoutDuration = expiresAt - Date.now() - (30 * 1000);
      if (timeoutDuration > 0) {
          this.refreshTokenTimeout = setTimeout(() => this.refreshToken(), timeoutDuration);
      }
  }

  private clearRefreshTokenTimeout(): void {
      if (this.refreshTokenTimeout) {
          clearTimeout(this.refreshTokenTimeout);
          this.refreshTokenTimeout = null;
      }
  }

  public refreshToken(): void {
    console.log('[Auth] Attempting silent token refresh...');
    const { sessionData, storageType } = this.getSessionData();
    if (!sessionData?.refreshToken) {
        console.warn('[Auth] No refresh token found. Logging out.');
        this.logout();
        return;
    }

    setTimeout(() => {
        const isRefreshTokenValid = true; // Mock success
        if (isRefreshTokenValid) {
            console.log('[Auth] Refresh successful.');
            const expiresIn = 3600 * 1000;
            const newSessionData: SessionData = {
                ...sessionData,
                accessToken: `mock_access_token_${Date.now()}`,
                expiresAt: Date.now() + expiresIn
            };
            this.saveSession(newSessionData, storageType === 'local');
            this.currentUserSession.next(newSessionData.user);
            this.scheduleTokenRefresh(newSessionData.expiresAt);
        } else {
            console.error('[Auth] Refresh token expired or invalid. Logging out.');
            this.logout();
        }
    }, 1000);
  }
}


import { Injectable, signal } from '@angular/core';
import { Subject } from 'rxjs';

export interface CollabEvent {
    type: 'content_change' | 'file_select' | 'structure_update' | 'participant_status' | 'cursor_move';
    fileId?: string;
    content?: string;
    files?: any[];
    participant?: {
        id: string;
        name: string;
        role: 'candidate' | 'interviewer';
        status: 'online' | 'typing' | 'idle' | 'offline';
    };
    participantId?: string; // To associate cursor with a user
    cursor?: {
        lineNumber: number;
        column: number;
    };
}

@Injectable({ providedIn: 'root' })
export class CollaborationService {
  // Observable stream for incoming code changes from other users
  private updatesSubject = new Subject<CollabEvent>();
  public updates$ = this.updatesSubject.asObservable();
  
  // Connection status signal for UI feedback
  public status = signal<'connecting' | 'connected' | 'disconnected' | 'reconnecting'>('disconnected');
  
  // We use BroadcastChannel to simulate a WebSocket connection between tabs.
  private socket: BroadcastChannel | null = null;
  private roomId: string | null = null;

  // Reconnection Logic Configuration
  private reconnectAttempts = 0;
  private readonly maxReconnectAttempts = 5;
  private readonly baseRetryDelay = 1000; // 1 second
  private isIntentionalDisconnect = false;

  connect(roomId: string): void {
    // Prevent multiple connections to the same room
    if (this.socket && this.status() === 'connected' && this.roomId === roomId) {
        return;
    }
    
    // Clean up existing connection if switching rooms
    if (this.socket) {
        this.disconnect();
    }

    this.roomId = roomId;
    this.isIntentionalDisconnect = false;
    this.reconnectAttempts = 0;
    
    this.initiateConnectionLoop();
  }

  private initiateConnectionLoop(): void {
      if (this.isIntentionalDisconnect) return;

      // Update status for UI feedback
      if (this.reconnectAttempts === 0) {
          this.status.set('connecting');
      } else {
          this.status.set('reconnecting');
      }

      // Calculate Exponential Backoff with Jitter
      // Formula: Delay = min(Base * 2^attempts, MaxDelay) + Jitter
      const backoff = Math.min(this.baseRetryDelay * Math.pow(2, this.reconnectAttempts), 10000); // Cap at 10s
      const jitter = Math.random() * 500; // 0-500ms random jitter to prevent thundering herd
      const delayMs = this.reconnectAttempts === 0 ? 0 : backoff + jitter;

      setTimeout(() => {
          this.establishConnection();
      }, delayMs);
  }

  private establishConnection(): void {
    if (this.isIntentionalDisconnect) return;

    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        try {
            // Attempt connection
            this.socket = new BroadcastChannel(`evalion_collab_${this.roomId}`);
            
            this.socket.onmessage = (event) => {
                if (event.data) {
                    this.updatesSubject.next(event.data as CollabEvent);
                }
            };
            
            // Simulate handshake latency
            setTimeout(() => {
                if (this.isIntentionalDisconnect) {
                    this.socket?.close();
                    return;
                }
                
                this.status.set('connected');
                this.reconnectAttempts = 0; // Reset attempts on success
                console.log(`[Collab] Connected to room: ${this.roomId}`);
            }, 500);

        } catch (error) {
            console.error('[Collab] Connection attempt failed:', error);
            this.handleConnectionFailure();
        }
    } else {
        console.warn('[Collab] Environment does not support BroadcastChannel.');
        this.status.set('disconnected');
    }
  }

  private handleConnectionFailure(): void {
      if (this.reconnectAttempts < this.maxReconnectAttempts) {
          this.reconnectAttempts++;
          console.warn(`[Collab] Retrying connection... Attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts}`);
          this.initiateConnectionLoop();
      } else {
          this.status.set('disconnected');
          console.error('[Collab] Max reconnection attempts reached. Connection failed.');
      }
  }

  sendChange(event: CollabEvent): void {
      if (this.socket && this.status() === 'connected') {
          this.socket.postMessage(event);
      }
  }

  disconnect(): void {
      this.isIntentionalDisconnect = true;
      if (this.socket) {
          this.socket.close();
          this.socket = null;
      }
      this.roomId = null;
      this.reconnectAttempts = 0;
      this.status.set('disconnected');
  }
}

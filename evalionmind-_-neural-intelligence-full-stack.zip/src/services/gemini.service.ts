
import { Injectable, signal } from '@angular/core';
import { GoogleGenAI, Type, Content, GenerateContentResponse } from '@google/genai';

// Define the structure of the evaluation response we expect from the AI
export interface EvaluationMetrics {
  accuracy: string;
  accuracyScore: number;
  clarity: string;
  clarityScore: number;
  confidence: string;
  confidenceScore: number;
}

export interface EvaluationResult {
  question?: string; // Added field to store the question asked
  score: number;
  feedback: string;
  metrics: EvaluationMetrics;
  actionableTip: string;
  goodExample: string;
  badExample: string;
  nonVerbalFeedback?: string; // Added field for video analysis
}

export type ErrorType = 'network' | 'api_key' | 'quota' | 'generic';

export interface ServiceError {
  type: ErrorType;
  message: string;
}

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI | null = null;
  public error = signal<ServiceError | null>(null);

  // Optimization: In-memory cache for interview questions
  private interviewQuestionsCache = new Map<string, string[]>();

  constructor() {
    this.initializeAI();
  }

  private initializeAI() {
    try {
      let apiKey: string | undefined;
      try {
        if (typeof process !== 'undefined' && process && process.env) {
            apiKey = process.env['API_KEY'];
        }
      } catch (e) {
        console.warn('Environment variable access suppressed in this context.', e);
      }

      if (!apiKey) {
        this.error.set({
          type: 'api_key',
          message: 'AI service is not configured. The API_KEY is missing.'
        });
        this.ai = null;
        console.error('GeminiService: ' + this.error()?.message);
        return;
      }
      
      this.ai = new GoogleGenAI({ apiKey });
      this.error.set(null); // Clear any previous error on success
    } catch (e: unknown) {
      const serviceError = this.handleError(e);
      // Initialization errors are always related to the key or setup.
      serviceError.type = 'api_key';
      this.error.set(serviceError);
      this.ai = null;
    }
  }

  /**
   * Checks if the AI service is initialized and ready for use.
   * If not ready, it ensures an appropriate error is signaled.
   * @returns {boolean} True if the service is ready, false otherwise.
   */
  private isReady(): boolean {
    if (this.ai) {
        return true;
    }
    // If an error is not already set from initialization, set a generic one.
    if (!this.error()) {
        this.error.set({ type: 'api_key', message: 'AI Service is not initialized.' });
    }
    return false;
  }

  private handleError(e: unknown): ServiceError {
    console.error('Gemini API Error:', e);
  
    let errorType: ErrorType = 'generic';
    let userFriendlyMessage = 'An unexpected error occurred with the AI service. Please try again later.';
    
    const errorString = e instanceof Error ? e.message.toLowerCase() : String(e).toLowerCase();
  
    if (errorString.includes('json') || errorString.includes('unexpected token')) {
      errorType = 'generic';
      userFriendlyMessage = 'The AI returned an invalid response. Please try again.';
    } else if (errorString.includes('api key') || errorString.includes('api_key') || errorString.includes('invalid authentication')) {
      errorType = 'api_key';
      userFriendlyMessage = 'The API key is invalid or missing. Please ensure it is configured correctly.';
    } else if (errorString.includes('network') || errorString.includes('fetch failed') || errorString.includes('rpc failed') || errorString.includes('xhr error') || errorString.includes('failed to fetch')) {
      errorType = 'network';
      userFriendlyMessage = 'Connection to the AI service failed. Check your internet connection.';
    } else if (errorString.includes('quota') || errorString.includes('resource exhausted')) {
      errorType = 'quota';
      userFriendlyMessage = 'The AI API usage quota has been exceeded. Please check your plan or contact support.';
    } else if (errorString.includes('content moderation')) {
      errorType = 'generic';
      userFriendlyMessage = 'Your request was blocked for safety reasons. Please revise your input.';
    }
  
    return { type: errorType, message: userFriendlyMessage };
  }

  async generateChatResponseStream(history: Content[], newMessage: string, mode: 'fast' | 'quality', systemInstruction?: string): Promise<AsyncIterable<GenerateContentResponse> | null> {
    if (!this.isReady()) return null;

    try {
      this.error.set(null);
      const model = 'gemini-2.5-flash';
      const config: any = mode === 'quality' ? {} : { thinkingConfig: { thinkingBudget: 0 } };
      if (systemInstruction) {
        config.systemInstruction = systemInstruction;
      }

      const contents: Content[] = [...history, { role: 'user', parts: [{ text: newMessage }] }];

      return this.ai!.models.generateContentStream({
        model,
        contents,
        config
      });
    } catch (e) {
      const serviceError = this.handleError(e);
      this.error.set(serviceError);
      return null;
    }
  }

  async generateImage(prompt: string, aspectRatio: '1:1' | '16:9' | '9:16'): Promise<string | null> {
    if (!this.isReady()) return null;

    try {
      this.error.set(null);
      const response = await this.ai!.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/png',
          aspectRatio: aspectRatio,
        },
      });

      const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
      return base64ImageBytes;
    } catch (e) {
      const serviceError = this.handleError(e);
      this.error.set(serviceError);
      return null;
    }
  }

  async generateSystemArchitecture(projectDesc: string, stack: string, scale: string): Promise<string | null> {
    if (!this.isReady()) return null;

    try {
        this.error.set(null);
        const prompt = `
            ROLE: Expert Software Architect & Systems Designer.
            TASK: Create a detailed Technical Architecture Blueprint.
            
            INPUTS:
            - Project: ${projectDesc}
            - Stack: ${stack}
            - Scale: ${scale}

            OUTPUT REQUIREMENTS:
            Generate a Markdown formatted response that includes:
            1. **High-Level Overview**: Brief summary of the architectural pattern (Monolith, Microservices, Serverless, etc.).
            2. **File & Folder Structure**: A tree view of the recommended project structure.
            3. **Core Components**: List of key modules, services, or databases.
            4. **Data Flow**: Step-by-step description of how data moves through the system.
            5. **Security & Scalability**: Specific recommendations for the given scale.
            
            Use code blocks for the file structure. Be technical, precise, and practical.
        `;

        const response = await this.ai!.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                thinkingConfig: { thinkingBudget: 0 }
            }
        });

        return response.text;
    } catch(e) {
        const serviceError = this.handleError(e);
        this.error.set(serviceError);
        return null;
    }
  }

  async generateMotionDesign(description: string, animationType: string): Promise<string | null> {
    if (!this.isReady()) return null;

    try {
        this.error.set(null);
        const prompt = `
            ROLE: Expert UI/UX Motion Designer.
            TASK: Generate animation rules and suggestions for a web application.
            
            INPUTS:
            - User Request: "${description}"
            - Animation Type: "${animationType}"

            OUTPUT REQUIREMENTS:
            Generate a Markdown formatted response that includes:
            1. **Animation Concept**: A brief description of the proposed animation.
            2. **Tailwind CSS Classes/Config**: Relevant Tailwind CSS classes to achieve the animation.
            3. **Keyframe CSS (if complex)**: Detailed CSS keyframes if Tailwind alone is insufficient.
            4. **Interaction Flow Suggestions**: How this animation enhances user experience.
            
            Focus on modern, smooth, and performant animations. Provide practical, actionable code.
        `;

        const response = await this.ai!.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                thinkingConfig: { thinkingBudget: 0 }
            }
        });

        return response.text;
    } catch(e) {
        const serviceError = this.handleError(e);
        this.error.set(serviceError);
        return null;
    }
  }

  async rewriteDesign(designInput: string): Promise<string | null> {
    if (!this.isReady()) return null;

    try {
        this.error.set(null);
        const prompt = `
            ROLE: Senior UI/UX Design Architect.
            TASK: Rewrite and enhance an existing UI design or code snippet to a premium, enterprise-grade standard.
            
            INPUT:
            \`\`\`
            ${designInput}
            \`\`\`

            OUTPUT REQUIREMENTS:
            Generate a Markdown formatted response that includes:
            1. **Executive Summary**: Overview of the improvements made.
            2. **Enhanced Design Principles**: Explanation of how the rewrite aligns with enterprise UI/UX best practices (consistency, accessibility, scalability).
            3. **Rewritten Code/Description**: The improved design, either as refined HTML/CSS (if input was code) or a detailed textual description with Tailwind CSS suggestions (if input was a design concept).
            4. **Justification**: Explain key changes and why they represent an an upgrade.
            
            Focus on professionalism, modern aesthetics, maintainability, and user experience.
        `;

        const response = await this.ai!.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                thinkingConfig: { thinkingBudget: 0 }
            }
        });

        return response.text;
    } catch(e) {
        const serviceError = this.handleError(e);
        this.error.set(serviceError);
        return null;
    }
  }

  async enhanceFullstack(backendDescription: string): Promise<string | null> {
    if (!this.isReady()) return null;

    try {
        this.error.set(null);
        const prompt = `
            ROLE: Expert Full-Stack Engineer & Solutions Architect.
            TASK: Enhance a backend logic description by suggesting database models, API design, and security improvements.
            
            INPUT:
            "Backend Logic Requirements: ${backendDescription}"

            OUTPUT REQUIREMENTS:
            Generate a Markdown formatted response that includes:
            1. **System Overview**: High-level summary of the proposed backend system.
            2. **Database Schema Design**: SQL or NoSQL (MongoDB/Firestore) schema suggestions, including relationships and indexing advice.
            3. **API Endpoint Suggestions**: RESTful or GraphQL endpoint designs, including HTTP methods, paths, and expected request/response bodies.
            4. **Security Enhancements**: Recommendations for authentication, authorization, input validation, data encryption, and common vulnerability mitigation (OWASP Top 10).
            5. **Performance Optimizations**: Tips for scaling and improving response times.
            
            Be precise, use code blocks for schemas and endpoints, and focus on practical, secure, and scalable solutions.
        `;

        const response = await this.ai!.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                thinkingConfig: { thinkingBudget: 0 }
            }
        });

        return response.text;
    } catch(e) {
        const serviceError = this.handleError(e);
        this.error.set(serviceError);
        return null;
    }
  }
  
  async generateFeatureConcept(idea: string, audience: string, monetization: string): Promise<string | null> {
    if (!this.isReady()) return null;

    try {
        this.error.set(null);
        const prompt = `
            ROLE: Expert Product Manager & SaaS Strategist.
            TASK: Expand a high-level feature idea into a comprehensive, monetizable feature concept for a web application.

            INPUTS:
            - Feature Idea: "${idea}"
            - Target Audience: "${audience}"
            - Monetization Model: "${monetization}"

            OUTPUT REQUIREMENTS (Markdown):
            1.  **Feature Title & Tagline**: A catchy, professional name and a one-sentence value proposition.
            2.  **Executive Summary**: A brief paragraph explaining what the feature is and why it's valuable.
            3.  **Core User Flow**: A step-by-step description of how the target audience would interact with the feature from start to finish.
            4.  **Monetization Strategy**: Detail how the chosen model (${monetization}) applies. How is access granted? What are the limits? How is value communicated to justify the cost?
            5.  **Key UI/UX Elements**: Suggest 3-5 critical UI components or screens needed for this feature (e.g., "A new dashboard widget," "A detailed analytics page," "A settings modal").
            6.  **Technical Considerations**: High-level technical notes (e.g., "Requires new database table for leaderboards," "Needs integration with a payment gateway," "Could use a real-time WebSocket connection").

            Be practical, creative, and business-oriented. The goal is to produce a document that could be handed to a development team for initial planning.
        `;

        const response = await this.ai!.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                thinkingConfig: { thinkingBudget: 0 }
            }
        });

        return response.text;
    } catch(e) {
        const serviceError = this.handleError(e);
        this.error.set(serviceError);
        return null;
    }
  }

  // Updated to accept a `focus` parameter
  async generateInterviewProtocol(role: string, level: string = 'Senior', focus: string = ''): Promise<string[]> {
    const cacheKey = `${role}-${level}-${focus}`;
    if (this.interviewQuestionsCache.has(cacheKey)) {
      console.log(`[Cache] HIT for: ${cacheKey}`);
      return Promise.resolve(this.interviewQuestionsCache.get(cacheKey)!);
    }

    console.log(`[Cache] MISS for: ${cacheKey}. Fetching from API.`);
    if (!this.isReady()) return [];

    try {
      this.error.set(null);
      // Incorporate focus into the prompt for more specific questions
      const prompt = `Generate 5 challenging, role-specific technical interview questions for a "${level}" level "${role}". Focus on "${focus}". Ensure a mix of conceptual and scenario-based questions appropriate for this seniority. Return strictly a JSON array of strings.`;

      const response = await this.ai!.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          thinkingConfig: { thinkingBudget: 0 }
        },
      });

      const jsonString = response.text.trim();
      const questions = JSON.parse(jsonString) as string[];
      this.interviewQuestionsCache.set(cacheKey, questions); // Store in cache with compound key
      return questions;
    } catch (e) {
      const serviceError = this.handleError(e);
      this.error.set(serviceError);
      // Return empty array so the component falls back to hardcoded questions
      return []; 
    }
  }

  async evaluateAnswer(question: string, answer: string, videoBase64?: string): Promise<EvaluationResult | null> {
    if (!this.isReady()) return null;

    const evaluationSchema = {
      type: Type.OBJECT,
      properties: {
        score: {
          type: Type.NUMBER,
          description: 'A precise score from 1.0 to 10.0 based on technical accuracy, clarity, and confidence.',
        },
        feedback: {
          type: Type.STRING,
          description: 'A comprehensive technical and soft-skill review of the candidate\'s answer.',
        },
        metrics: {
          type: Type.OBJECT,
          properties: {
            accuracy: {
              type: Type.STRING,
              description: 'Evaluation of technical correctness and depth.'
            },
            accuracyScore: {
              type: Type.NUMBER,
              description: 'Score from 1-10 for technical accuracy.'
            },
            clarity: {
              type: Type.STRING,
              description: 'Evaluation of communication structure and conciseness.'
            },
            clarityScore: {
                type: Type.NUMBER,
                description: 'Score from 1-10 for clarity.'
            },
            confidence: {
              type: Type.STRING,
              description: 'Evaluation of delivery confidence and tone.'
            },
            confidenceScore: {
                type: Type.NUMBER,
                description: 'Score from 1-10 for confidence.'
            }
          },
          required: ['accuracy', 'accuracyScore', 'clarity', 'clarityScore', 'confidence', 'confidenceScore'],
        },
        actionableTip: {
          type: Type.STRING,
          description: "One high-impact, specific area for improvement."
        },
        goodExample: {
            type: Type.STRING,
            description: "An optimized version of the candidate's answer applying the tip."
        },
        badExample: {
            type: Type.STRING,
            description: "A quote or paraphrase of the weakest part of the candidate's response."
        },
        nonVerbalFeedback: {
            type: Type.STRING,
            description: "Detailed analysis of non-verbal cues (eye contact, posture, micro-expressions) if video is present."
        }
      },
      required: ['score', 'feedback', 'metrics', 'actionableTip', 'goodExample', 'badExample', 'nonVerbalFeedback'],
    };

    try {
      this.error.set(null);
      
      const parts: any[] = [];
      
      if (videoBase64) {
          parts.push({
              inlineData: {
                  mimeType: 'video/webm',
                  data: videoBase64
              }
          });
      }

      const textPrompt = `
        ROLE: Expert Technical Interviewer & Behavioral Analyst.
        TASK: Evaluate the candidate's response to the technical interview question.
        
        CONTEXT:
        Question: "${question}"
        Candidate's Transcript: "${answer}"
        
        INPUT DATA:
        - Transcript of the answer.
        - Video recording of the answer (if provided in video/webm format).

        EVALUATION ALGORITHM:
        1. **Technical Accuracy (40% weight):** Verify facts, depth of understanding, and correctness of terminology.
        2. **Clarity & Structure (30% weight):** Assess logical flow, conciseness, and ability to explain complex concepts simply.
        3. **Confidence & Delivery (30% weight):** 
           - **VIDEO ANALYSIS (HIGH PRIORITY):** You have been provided with a video file of the candidate. You MUST analyze their non-verbal communication. Look for:
             - Eye Contact: Is it maintained? Wandering?
             - Posture: Confident? Slouched? Closed off?
             - Facial Expressions: Stress, confusion, enthusiasm, micro-expressions.
             - Hand Gestures: Distracting or emphatic?
           - **AUDIO/TEXT:** Analyze pacing, tone, and filler words.

        OUTPUT REQUIREMENTS:
        - Provide a strict numerical score (float, e.g., 7.5).
        - Feedback must be constructive but rigorous.
        - "nonVerbalFeedback": Write a specific paragraph detailing the visual analysis. Mentions specific visual cues observed in the video file. If no video is present, analyze tone from text.
      `;
      
      parts.push({ text: textPrompt });

      const response = await this.ai!.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: parts },
        config: {
          systemInstruction: 'You are SmartEvalion, an advanced AI interview evaluation engine. Your goal is to help candidates perfect their skills through rigorous, data-driven analysis. Be precise, professional, and encouraging.',
          responseMimeType: 'application/json',
          responseSchema: evaluationSchema,
          thinkingConfig: { thinkingBudget: 0 } 
        },
      });

      const jsonString = response.text.trim();
      const result = JSON.parse(jsonString);
      return { ...result, question: question } as EvaluationResult;

    } catch (e) {
      const serviceError = this.handleError(e);
      this.error.set(serviceError);
      return null;
    }
  }
}
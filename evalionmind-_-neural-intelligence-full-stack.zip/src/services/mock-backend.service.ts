
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { InterviewHistoryItem } from '../models/interview.model';
import { EvaluationResult } from './gemini.service';

export interface JobPost {
  id: string;
  title: string;
  description: string;
  role: string;
  requiredSkills: string[];
  generatedQuestions: string[]; // AI Generated Questions stored here
  status: 'Active' | 'Closed' | 'Draft' | 'Expired' | 'Archived';
  applicants: number;
  priority?: 'High' | 'Medium' | 'Low';
  createdAt: Date;
  expiresAt: Date;
}

export interface ApiKey {
  id: string;
  key: string;
  name: string;
  created: string;
  status: 'Active' | 'Revoked';
  apiStatus: 'Operational' | 'Degraded' | 'Error';
  lastError: { message: string, timestamp: Date } | null;
  scopes: string[];
  rateLimitPerHour: number;
  lastUsed: Date | null;
  currentHourCalls: number;
  lastRateLimitReset: Date;
}

export interface LiveSession {
    candidateId: string;
    candidateName: string;
    role: string;
    currentQuestion: number;
    totalQuestions: number;
    pulse: number; 
    pulseHistory: number[]; 
    status: 'Analyzing' | 'Speaking' | 'Idle';
}

export interface AuditLog {
  timestamp: Date;
  action: string;
}

export interface UserTask {
  id: string;
  title: string;
  completed: boolean;
  tags: string[];
  createdAt: Date;
}

@Injectable({
  providedIn: 'root'
})
export class MockBackendService {

  private jobs: JobPost[] = [
      { 
        id: 'REQ-2024-001', 
        title: 'Senior Angular Engineer', 
        description: 'Seeking a senior engineer with 5+ years of experience in Angular and enterprise-level applications.',
        role: 'Frontend Developer',
        requiredSkills: ['Angular', 'TypeScript', 'RxJS'],
        generatedQuestions: [
            "Explain the change detection strategy in Angular.",
            "How do you handle state management in large applications?",
            "Describe a complex RxJS chain you implemented."
        ],
        applicants: 12, 
        status: 'Active', 
        priority: 'High', 
        createdAt: new Date(Date.now() - 10 * 60 * 1000), 
        expiresAt: new Date(Date.now() + 50 * 60 * 1000) 
      }
  ];
  
  // Historical/Active Session Data
  private _rawSessions: InterviewHistoryItem[] = [ 
      { id: 'SES-9921', candidateId: 'CAND-9921', role: 'Senior Angular Engineer', date: 'Today', status: 'Pending Review', candidateName: 'John Doe', score: 75, aiAnalysis: { question: "General Interview", score: 7.5, feedback: 'Good technical depth.', metrics: { accuracy: 'High', accuracyScore: 8, clarity: 'Medium', clarityScore: 7, confidence: 'High', confidenceScore: 8 }, actionableTip: 'Improve pacing.', goodExample: '', badExample: '' } },
      // Modified Alex Candidate to be "Approved" for certificate testing with full question evaluations
      { 
          id: 'SES-8492', 
          candidateId: 'CAND-alex-candidate-849', 
          role: 'Frontend Developer', 
          date: '2024-05-20', 
          status: 'Approved', 
          score: 88, 
          candidateName: 'Alex Candidate', 
          aiAnalysis: { 
            question: "Overall Interview Summary",
            score: 8.8, 
            feedback: 'Overall, Alex demonstrated an excellent grasp of concepts and communicated with high clarity and confidence. Pacing can be slightly improved for complex explanations.', 
            metrics: { accuracy: 'High', accuracyScore: 9, clarity: 'High', clarityScore: 9, confidence: 'High', confidenceScore: 8 }, 
            actionableTip: 'Practice advanced architectural patterns and maintain consistent pacing.', 
            goodExample: 'Microservices architecture scales well due to independent deployment.', 
            badExample: 'Monolithic applications are hard to deploy.',
            nonVerbalFeedback: "Consistently good eye contact, strong posture. Occasional rapid speech when excited."
          },
          questionEvaluations: [
            {
              question: "Explain the change detection strategy in Angular.",
              score: 9.0,
              feedback: "Excellent explanation of change detection, including OnPush strategy and immutability. Demonstrated deep understanding.",
              metrics: { accuracy: 'High', accuracyScore: 9, clarity: 'High', clarityScore: 9, confidence: 'High', confidenceScore: 9 },
              actionableTip: "Consider mentioning Zone.js's role and how to opt out of it for finer control.",
              goodExample: "Angular's change detection mechanism works by comparing component state to previous values, with OnPush optimizing performance by only checking when inputs change or events fire.",
              badExample: "Angular checks every component every time, which can be slow.",
              nonVerbalFeedback: "Maintained strong eye contact and clear, steady voice throughout the answer."
            },
            {
              question: "How do you handle state management in large applications?",
              score: 8.5,
              feedback: "Good overview of NGRX and RxJS. Could expand on other patterns like services with BehaviorSubjects or more advanced patterns.",
              metrics: { accuracy: 'High', accuracyScore: 8, clarity: 'Medium', clarityScore: 8, confidence: 'High', confidenceScore: 8 },
              actionableTip: "Explore and compare other state management solutions (e.g., Akita, Signals in Angular 17+) in more detail, highlighting their trade-offs.",
              goodExample: "NGRX provides a predictable state container, centralizing state management and facilitating debugging through a single source of truth and immutability.",
              badExample: "We just use services for everything, and it gets complicated.",
              nonVerbalFeedback: "Slight hesitation at the beginning, indicating a moment of thought, but quickly regained composure. Used appropriate hand gestures to emphasize points."
            },
            {
              question: "Describe a complex RxJS chain you implemented.",
              score: 8.9,
              feedback: "Provided a detailed and practical example of a complex RxJS chain for debouncing and API calls. Demonstrated strong practical experience with observable operators.",
              metrics: { accuracy: 'High', accuracyScore: 9, clarity: 'High', clarityScore: 9, confidence: 'High', confidenceScore: 8 },
              actionableTip: "Focus on explicitly describing error handling strategies (e.g., `catchError`) within such complex chains to demonstrate robust fault tolerance.",
              goodExample: "I used `debounceTime` to prevent excessive API calls during search input, followed by `switchMap` to ensure only the latest search query triggers an actual API request, cancelling previous pending ones.",
              badExample: "It was complicated, many operators were involved, and it worked.",
              nonVerbalFeedback: "Slightly faster speech pace during the explanation of the complex chain, suggesting enthusiasm for the topic, but still clear and articulate."
            }
          ]
      }, 
  ];

  // FIX: Explicitly type BehaviorSubject to aid the TypeScript compiler.
  private _sessionsSubject: BehaviorSubject<InterviewHistoryItem[]> = new BehaviorSubject<InterviewHistoryItem[]>(this._rawSessions);
  // FIX: Removed asObservable() to resolve property access error; BehaviorSubject inherits from Observable.
  public sessions$: Observable<InterviewHistoryItem[]> = this._sessionsSubject;

  private apiKeys: ApiKey[] = [
      { id: 'key-prod-01', key: 'sk_live_51MzAbcdeFGhiJk...9f2a', name: 'Production Backend', created: '2023-11-15', status: 'Active', apiStatus: 'Operational', lastError: null, scopes: ['*'], rateLimitPerHour: 5000, lastUsed: new Date(Date.now() - 5 * 60 * 1000), currentHourCalls: 123, lastRateLimitReset: new Date() },
      { id: 'key-staging-02', key: 'sk_test_42KbLmnopQRstUv...3b1c', name: 'Staging Environment', created: '2024-01-20', status: 'Active', apiStatus: 'Error', lastError: { message: 'Rate limit exceeded. 500/500 calls used for the hour.', timestamp: new Date(Date.now() - 2 * 60 * 1000) }, scopes: ['read:reports'], rateLimitPerHour: 500, lastUsed: new Date(Date.now() - 2 * 60 * 1000), currentHourCalls: 500, lastRateLimitReset: new Date() },
      { id: 'key-ci-04', key: 'sk_test_99LpWxyz1234567...8x4d', name: 'CI/CD Pipeline', created: '2024-04-05', status: 'Active', apiStatus: 'Operational', lastError: null, scopes: ['write:candidates', 'read:status'], rateLimitPerHour: 2000, lastUsed: new Date(Date.now() - 45 * 60 * 1000), currentHourCalls: 45, lastRateLimitReset: new Date() },
      { id: 'key-dev-03', key: 'sk_dev_11Xc890Abcdefg...c4d3', name: 'Developer Sandbox', created: '2024-03-10', status: 'Revoked', apiStatus: 'Operational', lastError: null, scopes: ['read:*'], rateLimitPerHour: 100, lastUsed: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), currentHourCalls: 10, lastRateLimitReset: new Date() }
  ];

  private auditLogs: AuditLog[] = [
      { timestamp: new Date(Date.now() - 2 * 60 * 1000), action: 'User "Admin" logged in.' },
      { timestamp: new Date(Date.now() - 5 * 60 * 1000), action: 'System started successfully.' }
  ];

  // Tasks
  private _tasks: UserTask[] = [
    { id: 'tsk-1', title: 'Review Angular v18 docs', completed: false, tags: ['learning', 'angular'], createdAt: new Date() },
    { id: 'tsk-2', title: 'Update Resume PDF', completed: true, tags: ['career', 'urgent'], createdAt: new Date() }
  ];
  // FIX: Explicitly type BehaviorSubject to aid the TypeScript compiler.
  private _tasksSubject: BehaviorSubject<UserTask[]> = new BehaviorSubject<UserTask[]>(this._tasks);
  // FIX: Removed asObservable() to resolve property access error; BehaviorSubject inherits from Observable.
  public tasks$: Observable<UserTask[]> = this._tasksSubject;

  constructor() { }

  getJobs(): Observable<JobPost[]> {
    return of(this.jobs).pipe(delay(500)); 
  }

  // Used by Candidate to see available interviews
  getAvailableJobs(): Observable<JobPost[]> {
      return of(this.jobs.filter(j => j.status === 'Active')).pipe(delay(500));
  }

  // Modified to return observable
  getCandidates(): Observable<InterviewHistoryItem[]> {
    return this.sessions$.pipe(delay(500)); // Still simulate delay for async behavior
  }
  
  getLinkedCandidates(companyId: string): Observable<InterviewHistoryItem[]> {
      // In a real app, we'd filter sessions by companyId
      return this.sessions$.pipe(delay(500));
  }
  
  // Modified to use _sessionsSubject
  saveSession(session: InterviewHistoryItem): Observable<boolean> {
      const currentSessions = this._sessionsSubject.getValue();
      const existingIndex = currentSessions.findIndex(s => s.id === session.id);
      if (existingIndex > -1) {
          currentSessions[existingIndex] = session;
      } else {
          currentSessions.unshift(session);
      }
      this._sessionsSubject.next([...currentSessions]); // Emit new array reference
      return of(true).pipe(delay(800));
  }

  // Modified to use _sessionsSubject
  updateCandidateStatus(sessionId: string, status: 'Approved' | 'Rejected'): Observable<boolean> {
      const currentSessions = this._sessionsSubject.getValue();
      const session = currentSessions.find(s => s.id === sessionId);
      if (session) {
          session.status = status;
          this._sessionsSubject.next([...currentSessions]); // Emit new array reference
          return of(true).pipe(delay(300));
      }
      return of(false).pipe(delay(300));
  }

  getLiveSessions(): Observable<LiveSession[]> {
      // Simulation of live data
      const liveData: LiveSession[] = [
          { 
              candidateId: 'CAND-5501', 
              candidateName: 'Michael Chen', 
              role: 'Backend Architect', 
              currentQuestion: 3, 
              totalQuestions: 5, 
              pulse: 85, 
              pulseHistory: Array.from({length: 30}, () => Math.floor(Math.random() * 40) + 50),
              status: 'Speaking' 
          }
      ];
      return of(liveData).pipe(delay(300));
  }
  
  getApiKeys(): Observable<ApiKey[]> {
    return of(this.apiKeys).pipe(delay(500));
  }
  
  getAuditLogs(): Observable<AuditLog[]> {
    return of(this.auditLogs).pipe(delay(400));
  }

  createJob(title: string, description: string, role: string, questions: string[]): Observable<JobPost> {
    const newJob: JobPost = {
        id: `REQ-${Date.now()}`,
        title,
        description,
        role,
        requiredSkills: [],
        generatedQuestions: questions,
        applicants: 0,
        status: 'Active',
        priority: 'Medium',
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) 
    };
    this.jobs.unshift(newJob);
    return of(newJob).pipe(delay(600));
  }

  archiveJob(jobId: string): Observable<boolean> {
    const job = this.jobs.find(j => j.id === jobId);
    if (job) {
      job.status = 'Archived';
      this.auditLogs.unshift({ timestamp: new Date(), action: `Job Protocol Archived: '${job.title}'` });
      return of(true).pipe(delay(400));
    }
    return of(false).pipe(delay(300));
  }

  unarchiveJob(jobId: string): Observable<boolean> {
    const job = this.jobs.find(j => j.id === jobId);
    if (job) {
      job.status = 'Active';
      this.auditLogs.unshift({ timestamp: new Date(), action: `Job Protocol Restored: '${job.title}'` });
      return of(true).pipe(delay(400));
    }
    return of(false).pipe(delay(300));
  }

  createApiKey(name: string, scopes: string[], rateLimit: number): Observable<ApiKey> {
      const newKey: ApiKey = {
          id: `key-${Math.random().toString(36).substring(2, 8)}`,
          key: `sk_live_${Math.random().toString(36).substring(2, 12)}...${Math.random().toString(36).substring(2, 6)}`,
          name: name,
          created: new Date().toISOString().split('T')[0],
          status: 'Active',
          apiStatus: 'Operational',
          lastError: null,
          scopes: scopes.length > 0 ? scopes : ['*'],
          rateLimitPerHour: rateLimit || 1000,
          lastUsed: null,
          currentHourCalls: 0,
          lastRateLimitReset: new Date()
      };
      this.apiKeys.unshift(newKey);
      this.auditLogs.unshift({ timestamp: new Date(), action: `API Key Generated: '${name}'` });
      return of(newKey).pipe(delay(400));
  }

  rotateApiKey(id: string): Observable<ApiKey> {
      const index = this.apiKeys.findIndex(k => k.id === id);
      if (index > -1) {
          const oldKey = this.apiKeys[index];
          oldKey.status = 'Revoked'; // Revoke old key

          // Generate new key based on old configuration
          const newKey: ApiKey = {
              id: `key-${Math.random().toString(36).substring(2, 8)}`,
              key: `sk_live_${Math.random().toString(36).substring(2, 12)}...${Math.random().toString(36).substring(2, 6)}`,
              name: oldKey.name, // Keep same name
              created: new Date().toISOString().split('T')[0],
              status: 'Active',
              apiStatus: 'Operational',
              lastError: null,
              scopes: [...oldKey.scopes],
              rateLimitPerHour: oldKey.rateLimitPerHour,
              lastUsed: null,
              currentHourCalls: 0,
              lastRateLimitReset: new Date()
          };

          this.apiKeys.unshift(newKey);
          this.auditLogs.unshift({ timestamp: new Date(), action: `API Key Rotated: '${oldKey.name}' (ID: ${oldKey.id} -> ${newKey.id})` });
          
          return of(newKey).pipe(delay(600));
      }
      return of(null as any).pipe(delay(300));
  }

  revokeApiKey(id: string): Observable<boolean> {
      const keyIndex = this.apiKeys.findIndex(k => k.id === id);
      if (keyIndex > -1) {
          this.apiKeys[keyIndex].status = 'Revoked';
          this.auditLogs.unshift({ timestamp: new Date(), action: `API Key Revoked: '${this.apiKeys[keyIndex].name}'` });
          return of(true).pipe(delay(300));
      }
      return of(false).pipe(delay(300));
  }
  
  retryApiKeyCall(keyId: string): Observable<ApiKey | null> {
    const key = this.apiKeys.find(k => k.id === keyId);
    if (key && key.apiStatus === 'Error') {
      key.apiStatus = 'Operational';
      key.lastError = null;
      key.currentHourCalls = 0; // Reset usage for simulation
      this.auditLogs.unshift({ timestamp: new Date(), action: `API Key '${key.name}' call retry successful.` });
      return of(key).pipe(delay(800));
    }
    return of(null).pipe(delay(300));
  }

  // --- Task Methods ---
  addTask(title: string, tags: string[]): Observable<UserTask> {
    const newTask: UserTask = {
      id: `tsk-${Date.now()}`,
      title,
      completed: false,
      tags,
      createdAt: new Date()
    };
    const current = this._tasksSubject.getValue();
    this._tasksSubject.next([newTask, ...current]);
    return of(newTask);
  }

  toggleTask(id: string): Observable<boolean> {
    const current = this._tasksSubject.getValue();
    const task = current.find(t => t.id === id);
    if (task) {
      task.completed = !task.completed;
      this._tasksSubject.next([...current]);
      return of(true);
    }
    return of(false);
  }

  deleteTask(id: string): Observable<boolean> {
    const current = this._tasksSubject.getValue();
    this._tasksSubject.next(current.filter(t => t.id !== id));
    return of(true);
  }
}

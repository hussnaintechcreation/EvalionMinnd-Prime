
import { Injectable, ErrorHandler, signal, Injector, NgZone } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

export type AppHealthStatus = 'healthy' | 'degraded' | 'critical';

@Injectable({ providedIn: 'root' })
export class GlobalErrorService {
  error = signal<{ title: string; message: string; code?: string; isRecoverable?: boolean } | null>(null);
  appHealth = signal<AppHealthStatus>('healthy');

  showError(title: string, message: string, code: string = 'SYS_ERR', isRecoverable: boolean = false) {
    if (!this.error()) {
      this.error.set({ title, message, code, isRecoverable });
    }
    
    if (!isRecoverable) {
      this.appHealth.set('critical');
    } else if (this.appHealth() !== 'critical') {
      this.appHealth.set('degraded');
    }
  }

  clearError() {
    this.error.set(null);
    if (this.appHealth() === 'degraded') {
        this.appHealth.set('healthy');
    }
  }
}

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  constructor(private injector: Injector, private zone: NgZone) {}

  handleError(error: unknown): void {
    // Critical Infrastructure Check for Lazy Loading Failures
    const chunkFailedMessage = /Loading chunk [\d]+ failed/;
    const dynamicImportFailedMessage = /Failed to fetch dynamically imported module/;
    const isChunkError = error instanceof Error && (
        chunkFailedMessage.test(error.message) || 
        dynamicImportFailedMessage.test(error.message)
    );

    if (isChunkError) {
        console.error('Critical Infrastructure Error: Chunk loading failed. Forcing reload.', error);
        if (typeof window !== 'undefined') {
            window.location.reload();
        }
        return; 
    }

    try {
        // Lazy inject service to avoid cyclic dependency errors during app initialization
        const errorService = this.injector.get(GlobalErrorService);
        const { message, title, code, isRecoverable } = this.extractErrorDetails(error);
        
        console.error('Global Application Error:', error);
        
        this.zone.run(() => {
            errorService.showError(title, message, code, isRecoverable);
        });
    } catch (handlerError) {
        console.error('Critical Error inside GlobalErrorHandler:', handlerError);
    }
  }

  private extractErrorDetails(error: unknown): { message: string, title: string, code: string, isRecoverable: boolean } {
    let message = 'An unexpected anomaly has occurred within the neural interface.';
    let title = 'System Malfunction';
    let code = 'ERR_UNKNOWN';
    let isRecoverable = false;

    // --- HTTP Error Handling (API/Network) ---
    if (error instanceof HttpErrorResponse) {
        const httpError = error as HttpErrorResponse;
        code = `NET_${httpError.status}`;
        
        switch (httpError.status) {
            case 0:
                title = 'Neural Uplink Offline';
                message = 'Connection to the central network has been severed. Please verify your internet connection.';
                isRecoverable = true;
                break;
            case 400:
                title = 'Invalid Directive';
                message = 'The server rejected the request due to malformed syntax. Please check your inputs.';
                code = 'API_BAD_REQUEST';
                isRecoverable = true;
                break;
            case 401:
                title = 'Biometric Signature Invalid';
                message = 'Your session authentication has expired. A secure re-login is required.';
                code = 'AUTH_EXPIRED';
                isRecoverable = false; // Requires login, simple retry won't work
                break;
            case 403:
                title = 'Access Restricted';
                message = 'Clearance level insufficient for this operation. Access denied.';
                code = 'AUTH_FORBIDDEN';
                isRecoverable = true; // User can navigate away
                break;
            case 404:
                title = 'Void Sector';
                message = 'The requested data node or endpoint could not be located.';
                code = 'NET_404';
                isRecoverable = true;
                break;
            case 429:
                title = 'Neural Overload';
                message = 'High volume of requests detected from your node. Rate limit exceeded. Stand by.';
                code = 'API_RATE_LIMIT';
                isRecoverable = true;
                break;
            case 500:
                title = 'Core Malfunction';
                message = 'The AI core encountered an internal error. Diagnostic logs have been sent.';
                code = 'SERVER_INTERNAL';
                isRecoverable = true;
                break;
            case 503:
                title = 'Maintenance Mode';
                message = 'The system is currently undergoing scheduled maintenance. Please try again later.';
                code = 'SERVER_MAINTENANCE';
                isRecoverable = true;
                break;
            default:
                title = `Network Error (${httpError.status})`;
                message = httpError.message || 'A communication error occurred with the remote server.';
                isRecoverable = true;
        }
        
        return { message, title, code, isRecoverable };
    }

    // --- JavaScript/Runtime Error Handling ---
    if (error instanceof Error) {
        code = 'ERR_RUNTIME';
        title = 'Application Error';
        message = error.message;

        if (error instanceof TypeError) {
            title = 'Interface Integrity Error';
            code = 'ERR_TYPE_MISMATCH';
            message = 'A data protocol mismatch occurred within the UI. An interface reload is recommended.';
            isRecoverable = true;
        } else if (error.message.includes('ExpressionChangedAfterItHasBeenCheckedError')) {
            title = 'Rendering Synchronization Glitch';
            code = 'ANG_LIFECYCLE';
            message = 'A visual frame synchronization error occurred. The interface may flicker but remains operational.';
            isRecoverable = true;
        } else if (error.message.includes('API_KEY')) {
            title = 'Configuration Error';
            code = 'CFG_API_KEY_MISSING';
            message = 'AI Service configuration is missing. The system cannot proceed without a valid Neural Key.';
            isRecoverable = false;
        } else if (error.message.includes('QuotaExceededError') || error.message.includes('storage')) {
            title = 'Memory Overflow';
            code = 'ERR_STORAGE_QUOTA';
            message = 'Local storage limit reached. Please clear browser data or remove old sessions.';
            isRecoverable = true;
        } else {
             // General runtime errors are usually recoverable via reload
             isRecoverable = true; 
        }
        
        return { message, title, code, isRecoverable };
    }

    // --- String/Unknown Error Handling ---
    if (typeof error === 'string') {
        return { message: error, title: 'System Notice', code: 'ERR_GENERIC', isRecoverable: true };
    }
    
    return { message, title, code, isRecoverable };
  }
}


import { Injectable, signal, OnDestroy, inject } from '@angular/core';
import { Subject, Subscription, interval } from 'rxjs';
import { AuthService } from './auth.service';

export interface WsMessage {
  type: 'METRIC' | 'COMMAND' | 'SYSTEM' | 'CHAT' | 'HEARTBEAT' | 'HEARTBEAT_ACK';
  payload: any;
  timestamp: number;
  authToken?: string;
}

@Injectable({
  providedIn: 'root'
})
export class WebSocketService implements OnDestroy {
  private socket: WebSocket | null = null;
  private messageSubject = new Subject<WsMessage>();
  public messages$ = this.messageSubject.asObservable();
  
  public status = signal<'connected' | 'disconnected' | 'reconnecting' | 'simulating'>('disconnected');
  public connectionError = signal<string | null>(null); 

  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private simulationSubscription: Subscription | null = null;
  
  private readonly WS_URL = 'wss://echo.websocket.org';
  private readonly ENABLE_SIMULATION_FALLBACK = true;
  private readonly HEARTBEAT_INTERVAL_MS = 5000;
  private readonly HEARTBEAT_TIMEOUT_MS = 10000;
  private heartbeatInterval: any;
  private heartbeatTimeout: any;

  private authService = inject(AuthService);
  private authToken: string | null = null;
  private authSubscription: Subscription;

  constructor() {
    this.authSubscription = this.authService.currentUser$.subscribe(user => {
      this.authToken = this.authService.getAccessToken();
    });
    this.connect();
  }

  private connect(): void {
    if (this.status() === 'connected' || this.status() === 'simulating') return;

    this.status.set('reconnecting');
    this.connectionError.set(null);

    if (typeof WebSocket === 'undefined') {
        console.warn('[Neural Uplink] WebSocket API not available in this environment. Using simulation mode.');
        this.startSimulationMode();
        return;
    }

    try {
      this.socket = new WebSocket(this.WS_URL);

      this.socket.onopen = () => {
        this.status.set('connected');
        this.reconnectAttempts = 0;
        this.stopSimulation();
        this.startHeartbeat();
        this.connectionError.set(null);
        console.log('[Neural Uplink] Connection established.');
        
        this.sendMessage({ type: 'SYSTEM', payload: { action: 'HANDSHAKE', client: 'EVALION_CLIENT_V4' } });
      };

      this.socket.onmessage = (event) => {
        this.resetHeartbeatTimeout();
        try {
          const data = JSON.parse(event.data) as WsMessage;
          
          if (data.authToken !== this.authToken) {
              console.warn('[Neural Uplink] Discarding message with invalid token.', data);
              this.connectionError.set('Received an unauthenticated message from the server.');
              return;
          }

          if (data.type === 'HEARTBEAT') {
              return;
          }

          this.messageSubject.next(data);
        } catch (e) {
          console.warn('[Neural Uplink] Received non-JSON message or parsing error:', event.data, e);
        }
      };

      this.socket.onclose = () => {
        this.handleDisconnection();
      };

      this.socket.onerror = (error) => {
        console.warn('[Neural Uplink] Connection error.', error);
        this.connectionError.set('WebSocket connection encountered an error. Attempting to reconnect...');
      };

    } catch (e) {
      console.error('[Neural Uplink] Failed to initiate WebSocket connection:', e);
      this.connectionError.set('Failed to initiate WebSocket connection. Please check your network or try again.');
      this.handleDisconnection(); 
    }
  }

  private handleDisconnection(): void {
    this.stopHeartbeat(); 

    if (this.status() === 'simulating') return; 

    this.status.set('disconnected');
    this.socket = null;

    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      const delayMs = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 10000);
      console.log(`[Neural Uplink] Reconnecting in ${delayMs}ms... (Attempt ${this.reconnectAttempts})`);
      
      this.connectionError.set(`Connection lost. Reconnecting in ${Math.round(delayMs / 1000)}s (Attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts}).`);
      setTimeout(() => this.connect(), delayMs);
    } else if (this.ENABLE_SIMULATION_FALLBACK) {
      console.warn('[Neural Uplink] Max reconnection attempts reached. Falling back to simulation mode.');
      this.connectionError.set('Max reconnection attempts failed. Operating in simulation mode (limited functionality).');
      this.startSimulationMode();
    } else {
        this.connectionError.set('Connection to neural uplink failed permanently. Please check your internet connection.');
    }
  }

  public sendMessage(msg: Omit<WsMessage, 'timestamp' | 'authToken'>): void {
    const fullMsg: WsMessage = { 
        ...msg, 
        timestamp: Date.now(),
        authToken: this.authToken 
    };
    
    if (this.status() === 'connected' && this.socket?.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(fullMsg));
    } else if (this.status() === 'simulating') {
      console.log('[Neural Uplink] Simulating send:', fullMsg);
      if (fullMsg.type === 'CHAT') {
        setTimeout(() => {
          this.messageSubject.next({
            type: 'CHAT',
            payload: { response: `(Simulated) You said: "${fullMsg.payload.text}"` },
            timestamp: Date.now(),
            authToken: this.authToken
          });
        }, 500);
      }
    }
  }

  private startHeartbeat() {
    this.stopHeartbeat(); 

    this.heartbeatInterval = setInterval(() => {
        if (this.socket?.readyState === WebSocket.OPEN) {
            this.sendMessage({ type: 'HEARTBEAT', payload: {} });
        }
    }, this.HEARTBEAT_INTERVAL_MS);

    this.resetHeartbeatTimeout();
    console.log('[Neural Uplink] Heartbeat started.');
  }

  private resetHeartbeatTimeout() {
      if (this.heartbeatTimeout) {
          clearTimeout(this.heartbeatTimeout);
      }
      
      this.heartbeatTimeout = setTimeout(() => {
          console.warn('[Neural Uplink] Heartbeat timeout. Connection presumed dead, attempting to close socket.');
          this.connectionError.set('Neural uplink timed out. Connection lost, attempting recovery...');
          this.socket?.close(); 
      }, this.HEARTBEAT_TIMEOUT_MS);
  }

  private stopHeartbeat() {
    if (this.heartbeatInterval) {
        clearInterval(this.heartbeatInterval);
        this.heartbeatInterval = null;
    }
    if (this.heartbeatTimeout) {
        clearTimeout(this.heartbeatTimeout);
        this.heartbeatTimeout = null;
    }
  }

  private startSimulationMode(): void {
    if (this.status() === 'simulating') return;
    
    console.warn('[Neural Uplink] Primary link failed. Engaging local simulation protocols.');
    this.status.set('simulating');
    this.connectionError.set('Operating in simulation mode due to persistent connection issues.');
    
    this.simulationSubscription = interval(2000).subscribe(() => {
        const pulse = 70 + Math.floor(Math.random() * 30);
        this.messageSubject.next({
            type: 'METRIC',
            payload: { metric: 'candidate_pulse', value: pulse },
            timestamp: Date.now()
        });

        const confidence = 0.8 + (Math.random() * 0.2);
        this.messageSubject.next({
            type: 'METRIC',
            payload: { metric: 'ai_confidence', value: confidence },
            timestamp: Date.now()
        });

        if (Math.random() > 0.98) {
             this.messageSubject.next({
                 type: 'COMMAND',
                 payload: { action: 'SHOW_TOAST', message: 'Please maintain eye contact.', level: 'warning' },
                 timestamp: Date.now()
             });
        }
    });
  }

  private stopSimulation(): void {
    this.simulationSubscription?.unsubscribe();
    this.simulationSubscription = null;
    if (this.connectionError()?.includes('simulation mode')) {
        this.connectionError.set(null);
    }
  }

  ngOnDestroy(): void {
    this.authSubscription.unsubscribe();
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.close();
    }
    this.stopHeartbeat();
    this.stopSimulation();
    this.messageSubject.complete();
  }
}

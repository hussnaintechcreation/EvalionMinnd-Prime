
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class CodeExecutionService {
  
  /**
   * Executes code in a secure, sandboxed environment based on language.
   * JavaScript is run in a sandboxed iframe.
   * Python and Java are simulated with security and resource checks.
   */
  run(code: string, language: string = 'javascript'): Promise<string> {
    
    // --- Python Simulation ---
    if (language === 'python') {
      return new Promise(resolve => {
        if (code.length > 2048) {
          resolve('> Execution Error: Code size exceeds resource limits (2048 characters).');
          return;
        }
        const forbiddenImports = ['os', 'sys', 'subprocess', 'socket', 'shutil', 'fcntl', 'resource'];
        const importRegex = new RegExp(`^\\s*(?:import\\s+(${forbiddenImports.join('|')})|from\\s+(${forbiddenImports.join('|')})\\s+import)`, 'gm');
        if (importRegex.test(code)) {
          resolve('> Security Error: Use of restricted modules (e.g., os, sys, subprocess) is forbidden.');
          return;
        }
        // Simulate successful execution
        resolve(`> [Simulated Execution] Python code compiled and executed successfully.
> Output: Processed ${code.split('\n').length} lines.
> Result: Data integrity check passed.`);
      });
    }

    // --- Java Simulation ---
    if (language === 'java') {
      return new Promise(resolve => {
        if (code.length > 4096) { // Larger limit for Java
          resolve('> Execution Error: Code size exceeds resource limits (4096 characters).');
          return;
        }
        const forbiddenImports = ['java.io', 'java.net', 'java.lang.reflect', 'java.lang.ProcessBuilder', 'java.security'];
        const importRegex = new RegExp(`^\\s*import\\s+(${forbiddenImports.join('|').replace(/\./g, '\\.')})`, 'gm');
        if (importRegex.test(code)) {
          resolve('> Security Error: Use of restricted packages (e.g., java.io, java.net) is forbidden.');
          return;
        }
        // Simulate successful execution
        resolve(`> [Simulated Execution] Java code compiled and executed successfully in a sandboxed JVM.
> Output: Program exited with code 0.
> Result: Resource allocation nominal.`);
      });
    }

    // --- JavaScript Execution (Iframe Sandbox) ---
    return new Promise((resolve) => {
      // 1. Create a hidden, sandboxed iframe
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.setAttribute('sandbox', 'allow-scripts'); 
      document.body.appendChild(iframe);

      const win = iframe.contentWindow;
      if (!win) {
          document.body.removeChild(iframe);
          resolve('> System Error: Sandbox initialization failed.');
          return;
      }

      // 2. Safety Timeout (3 seconds)
      const timeoutId = setTimeout(() => {
          if (document.body.contains(iframe)) {
              document.body.removeChild(iframe);
              resolve('> Runtime Error: Execution Timed Out (Possible infinite loop detected).');
          }
      }, 3000);

      // 3. Listen for the result message from the iframe
      const onMessage = (e: MessageEvent) => {
          if (e.source !== win) return;
          
          window.removeEventListener('message', onMessage);
          clearTimeout(timeoutId);
          if (document.body.contains(iframe)) {
              document.body.removeChild(iframe);
          }
          
          resolve(e.data);
      };
      window.addEventListener('message', onMessage);

      // 4. Construct the script to inject
      const scriptContent = `
        <script>
          (function() {
            const logs = [];
            const originalLog = console.log;
            const originalError = console.error;
            
            console.log = (...args) => {
                logs.push(args.map(arg => 
                    typeof arg === 'object' ? JSON.stringify(arg) : String(arg)
                ).join(' '));
            };
            
            console.error = (...args) => {
                logs.push('[Error] ' + args.map(arg => String(arg)).join(' '));
            };
            
            try {
              ${code}
            } catch(e) {
              logs.push('[Runtime Exception] ' + e.message);
            }
            
            const output = logs.length > 0 ? logs.join('\\n') : '> Code executed successfully (No output).';
            window.parent.postMessage(output, '*');
          })();
        <\/script>
      `;
      
      // 5. Inject and run
      iframe.srcdoc = scriptContent;
    });
  }
}

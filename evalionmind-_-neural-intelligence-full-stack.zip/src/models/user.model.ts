
export interface User {
  id: string;
  name: string; // Candidate Name OR Company Name
  email: string;
  role: 'candidate' | 'company' | 'interviewer';
  avatarUrl?: string;
  organizationId?: string;
  designation?: string;
  
  // Extended Company Fields
  ownerName?: string;
  cnic?: string;
  mobile?: string;
  location?: string;
}

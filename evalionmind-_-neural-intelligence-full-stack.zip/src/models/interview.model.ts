
import { EvaluationResult } from '../services/gemini.service';

export interface InterviewHistoryItem {
  id: string; // Session ID
  role: string;
  date: string;
  status: 'Completed' | 'Pending Review' | 'In Progress' | 'Approved' | 'Rejected';
  score?: number; // Overall interview score (0-100)
  candidateName?: string;
  candidateId?: string;
  
  // New: Array of individual question evaluations
  questionEvaluations?: EvaluationResult[];

  // This will become an overall summary of the interview, derived from questionEvaluations
  aiAnalysis?: EvaluationResult; 
  feedbackSummary?: string; // Derived from aiAnalysis or overall feedback
  videoUrl?: string; // Placeholder for recording link
}

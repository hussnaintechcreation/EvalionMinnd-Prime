import { bootstrapApplication } from '@angular/platform-browser';
import { provideZonelessChangeDetection, ErrorHandler } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { GlobalErrorHandler } from './src/services/global-error.service';

import { AppComponent } from './src/app.component';

bootstrapApplication(AppComponent, {
  providers: [
    provideZonelessChangeDetection(),
    provideHttpClient(),
    { provide: ErrorHandler, useClass: GlobalErrorHandler }
  ],
}).catch((err) => console.error(err));

// AI Studio always uses an `index.tsx` file for all project types.